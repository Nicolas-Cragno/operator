import React, { useEffect, useState } from 'react';
import { Image, Linking, Platform, Text, View, useWindowDimensions } from 'react-native';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';

export default function PositionMap({lat,lon,height=280}) {
 const theme=useCantappTheme();const viewport=useWindowDimensions();
 const [width,setWidth]=useState(Math.max(240,Math.min(720,viewport.width-56)));
 const [zoom,setZoom]=useState(13);const [error,setError]=useState(false);
 useEffect(()=>setError(false),[lat,lon,zoom]);
 const valid=typeof lat==='number'&&typeof lon==='number'&&Number.isFinite(lat)&&Number.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;
 if(!valid)return <Text style={{color:theme.danger}}>Coordenadas inválidas</Text>;
 const mapUrl=`https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=${zoom}/${lat}/${lon}`;
 const covered=Math.abs(lat)<=85.05112878;const tiles=[];
 if(covered){
  const size=2**zoom;const radians=lat*Math.PI/180;
  const x=(lon+180)/360*size;const y=(1-Math.log(Math.tan(radians)+1/Math.cos(radians))/Math.PI)/2*size;
  const left=x*256-width/2;const top=y*256-height/2;
  for(let row=Math.floor(top/256);row<=Math.floor((top+height-1)/256);row++){
   if(row<0||row>=size)continue;
   for(let col=Math.floor(left/256);col<=Math.floor((left+width-1)/256);col++){
    const wrapped=(col%size+size)%size;
    const template=process.env.EXPO_PUBLIC_MAP_TILE_URL||'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
    const uri=template.replace('{z}',String(zoom)).replace('{x}',String(wrapped)).replace('{y}',String(row));
    tiles.push(<Image key={`${zoom}:${col}:${row}`} accessible={false} onError={()=>setError(true)}
     source={{uri,cache:'default',...(Platform.OS==='web'?{}:{headers:{'User-Agent':'CANTAPP-Operator/1.0'}})}}
     style={{position:'absolute',left:col*256-left,top:row*256-top,width:256,height:256}}/>);
   }
  }
 }
 return <View style={{gap:8,minWidth:0}}>
  <View accessibilityLabel={`Mapa de posición: ${lat}, ${lon}`} onLayout={event=>setWidth(event.nativeEvent.layout.width)}
   style={{height,overflow:'hidden',borderWidth:1,borderColor:theme.border,borderRadius:8,backgroundColor:theme.surface}}>
   {covered?tiles:<Text style={{color:theme.text,padding:12}}>Esta latitud está fuera de la cobertura del mapa.</Text>}
   {covered&&<View pointerEvents="none" style={{position:'absolute',left:width/2-9,top:height/2-9,width:18,height:18,borderRadius:9,backgroundColor:theme.danger,borderWidth:3,borderColor:'#ffffff'}}/>}
   {error&&<View style={{position:'absolute',top:8,left:8,right:8,padding:8,backgroundColor:theme.surface}}><Text style={{color:theme.danger}}>No se pudo cargar el mapa. Podés abrir la ubicación en OpenStreetMap.</Text></View>}
  </View>
  <View style={{flexDirection:'row',flexWrap:'wrap',alignItems:'center',gap:8}}>
   <Button iconOnly icon="minus" variant="outline" accessibilityLabel="Alejar mapa" disabled={zoom<=2} onPress={()=>setZoom(value=>value-1)}/>
   <Button iconOnly icon="plus" variant="outline" accessibilityLabel="Acercar mapa" disabled={zoom>=18} onPress={()=>setZoom(value=>value+1)}/>
   <Button label="Abrir mapa" icon="external" variant="outline" onPress={()=>Linking.openURL(mapUrl)}/>
   <Button label="© OpenStreetMap contributors" variant="ghost" onPress={()=>Linking.openURL('https://www.openstreetmap.org/copyright')}/>
  </View>
 </View>;
}