import { calculateDocumentAmounts } from '../../data/administrationFields';
import { tokens } from '../../theme/tokens';
import React, { useEffect, useMemo, useState, useCallback, useRef } from 'react';
import { View, Text, ScrollView, useWindowDimensions } from 'react-native';
import Input from '../Input/input';
import ArticleLines, { validateArticleLines } from './articleLines';
import Select from '../Input/select';
import MultiSelect from '../Input/multiSelect';
import DateInput from '../Input/dateInput';
import DateTimeInput from '../Input/dateTimeInput';
import Checkbox from '../Input/checkbox';
import CheckPanel from './checkPanel';
import { NumberInput, RadioGroup, Switch } from '../Input/controls';
import Button from '../Button/button';
import BackButton from '../Button/BackButton';
import ConfirmDialog from '../Modal/confirmModal';
import { useModalSurface } from '../Modal/modal';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { toDate } from '../../utils/data';
const EMPTY={};const DEFAULT_FIELDS=[{key:'nombre',label:'Nombre',type:'text',required:true}];
export function validateField(field,value){
 if(field.required&&(value==null||(typeof value==='string'&&!value.trim())||(Array.isArray(value)&&!value.length)))return 'Campo obligatorio';
 if(value!=null&&value!==''){
  if(field.type==='number'&&!Number.isFinite(Number(value)))return 'Número inválido';
  if(['date','datetime'].includes(field.type)&&!toDate(value,true))return 'Fecha inválida';
  if(field.type==='datetime'&&!/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/.test(value))return 'Ingresá fecha y hora';
 }
 if(field.type==='checks'&&(!value||Array.isArray(value)||typeof value!=='object'||Object.entries(value).some(([key,checked])=>!field.items?.some(item=>item.key===key)||typeof checked!=='boolean')))return 'Chequeos inválidos';
 if(field.type==='articleLines')return validateArticleLines(value,field);
 return field.validate?.(value)||'';
}
export default function FormStandard({title='Formulario',fields=DEFAULT_FIELDS,sections,data=EMPTY,onSubmit,onCancel,loading=false,optionsByField=EMPTY,onValuesChange,onFieldBlur}){
 const t=useCantappTheme();const {width,height}=useWindowDimensions();const surface=useModalSurface();
 const all=useMemo(()=>sections?sections.flatMap(section=>section.fields||[]):fields,[sections,fields]);
 const [values,setValues]=useState(data||EMPTY);const [errors,setErrors]=useState({});const [confirm,setConfirm]=useState(false);const [dirty,setDirty]=useState(false);
 const [warnings,setWarnings]=useState({});const latestValues=useRef(values);const blurRequests=useRef({});
 useEffect(()=>{setValues(data||EMPTY);latestValues.current=data||EMPTY;setErrors({});setWarnings({});blurRequests.current={};setDirty(false);return ()=>{blurRequests.current={};};},[data]);
 const update=(key,value)=>{
  const dependents=latestValues.current[key]!==value?all.filter(field=>field.dependsOn===key):[];
  const cleared=Object.fromEntries(dependents.map(field=>[field.key,'']));
  const next={...latestValues.current,[key]:value,...cleared};latestValues.current=next;
  setDirty(true);setValues(next);onValuesChange?.(next);
  const clearedMessages={[key]:'',...cleared};setErrors(old=>({...old,...clearedMessages}));setWarnings(old=>({...old,...clearedMessages}));
  [key,...dependents.map(field=>field.key)].forEach(name=>{delete blurRequests.current[name];});
 };
 const attempt=useCallback(()=>{if(loading)return;const next={};all.forEach(field=>{const error=validateField(field,values[field.key]??field.defaultValue);if(error)next[field.key]=error;});setErrors(next);if(!Object.keys(next).length)setConfirm(true);},[loading,all,values]);
 const save=async()=>{await onSubmit?.({...Object.fromEntries(all.filter(field=>field.defaultValue!==undefined).map(field=>[field.key,field.defaultValue])),...values});setDirty(false);setConfirm(false);};
 const cancel=useCallback(()=>{if(dirty)setConfirm('cancel');else onCancel?.();},[dirty,onCancel]);
 useEffect(()=>{surface?.setDirty?.(dirty);return ()=>surface?.setDirty?.(false);},[dirty,surface]);
 useEffect(()=>{if(!surface?.setFooter)return undefined;surface.setFooter(<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Guardar" loading={loading} onPress={attempt}/><Button label="Cancelar" variant="outline" disabled={loading} onPress={cancel}/></View>);return ()=>surface.setFooter(null);},[surface,attempt,cancel,loading]);
 const FormBody=surface?View:ScrollView;
 const render=field=>{
  const props={label:field.label,value:values[field.key]??field.defaultValue,onChange:value=>update(field.key,value),disabled:field.disabled||loading,required:field.required,error:errors[field.key]||warnings[field.key]};
  const blur=async next=>{
   const value=typeof next==='string'||typeof next==='number'?next:latestValues.current[field.key]??field.defaultValue;
   setErrors(old=>({...old,[field.key]:validateField(field,value)}));
   if(!onFieldBlur||field.disabled)return;
   const request=Symbol(field.key);blurRequests.current[field.key]=request;
   try{
    const message=await onFieldBlur(field.key,value);
    if(blurRequests.current[field.key]===request)setWarnings(old=>({...old,[field.key]:message||''}));
   }catch{
    // A failed advisory lookup never replaces the server's save validation.
    if(blurRequests.current[field.key]===request)setWarnings(old=>({...old,[field.key]:''}));
   }
  };
  if(field.presentation==='vehicles'&&['select','searchSelect'].includes(field.type))return <MultiSelect {...props} presentation="vehicles" multiple={false} options={optionsByField[field.key]||field.options||[]}/>;
  if(['select','searchSelect'].includes(field.type)){
   let options=optionsByField[field.key]||field.options||[];
   if(field.dependsOn){
    const parent=(optionsByField[field.dependsOn]||[]).find(option=>String(option.value)===String(values[field.dependsOn])||option.label===values[field.dependsOn]);
    options=parent?.[field.optionsProperty]||[];
   }
   if(field.preserveExisting&&props.value!=null&&props.value!==''&&!options.some(option=>String(option.value)===String(props.value))){
    options=[...options,{value:props.value,label:String(props.value)}];
   }
   return <Select {...props} onBlur={blur} options={options}/>;
  }
  if(field.type==='articleLines')return <ArticleLines {...props} includeUnit={field.includeUnit} includeMoney={field.includeMoney} currency={values.moneda} options={optionsByField[field.key]||[]}/>;
  if(field.type==='documentTotals'){let text;try{const totals=calculateDocumentAmounts(values.ingresos||[],values.descuento||0);text=`Subtotal: ${totals.importesDecimales.subtotal} · Descuento: ${totals.descuento}% · Total: ${totals.importesDecimales.total} ${values.moneda==='dolares'?'USD':'ARS'}`;}catch{text='Completá cantidades y precios válidos para calcular los importes';}return <Text accessibilityRole="text" style={{color:t.text}}>{text}</Text>;}
  if(field.type==='checks'||field.presentation==='checks')return <CheckPanel {...props} representation={field.type==='checks'?'object':'array'} items={field.items||optionsByField[field.key]||field.options||[]}/>;
  if(field.type==='multiSelect')return <MultiSelect {...props} presentation={field.presentation} maxSelection={field.maxSelection} options={optionsByField[field.key]||field.options||[]}/>;
  if(['radio','buttons'].includes(field.type))return <RadioGroup {...props} variant={field.type==='buttons'?'buttons':'radio'} options={field.options||[]}/>;
  if(field.type==='switch')return <Switch {...props}/>;
  if(field.type==='checkbox')return <Checkbox {...props} value={!!props.value}/>;
  if(field.type==='date')return <DateInput {...props} onBlur={blur}/>;
  if(field.type==='datetime')return <DateTimeInput {...props}/>;
  if(field.type==='number')return <NumberInput {...props} onBlur={blur} steppers={field.steppers}/>;
  return <Input {...props} multiline={field.type==='textarea'} grow={field.grow} value={props.value??''} onBlur={blur}/>;
 };
 return <View style={{backgroundColor:t.surface,borderRadius:tokens.radius,borderWidth:surface?0:1,borderColor:t.border,maxHeight:surface?undefined:Math.max(300,height-180)}}><View style={{flexDirection:'row',alignItems:'center',gap:4,padding:tokens.padding}}>{!surface&&onCancel&&<BackButton disabled={loading} onPress={cancel}/>}<Text accessibilityRole="header" style={{fontFamily,fontSize:20,color:t.text,flexShrink:1}}>{title}</Text></View><FormBody {...(surface?{style:{padding:tokens.padding,gap:24}}:{keyboardShouldPersistTaps:"handled",contentContainerStyle:{padding:tokens.padding,gap:24}})}>{(sections||[{fields:all}]).map((section,index)=><View key={section.key||index} style={{gap:12}}>{section.title&&<Text style={{fontFamily,color:t.text,fontSize:16,fontWeight:'600'}}>{section.title}</Text>}<View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.padding}}>{section.fields.map(field=><View key={field.key} style={{width:width>=768&&!['textarea','multiSelect','articleLines','checks','documentTotals'].includes(field.type)?'47%':'100%',gap:4}}>{render(field)}{errors[field.key]&&!['text','textarea'].includes(field.type)&&<Text accessibilityRole="alert" style={{color:t.danger,fontSize:12}}>{errors[field.key]}</Text>}</View>)}</View></View>)}</FormBody>{!surface&&<View style={{padding:tokens.padding,borderTopWidth:1,borderColor:t.border,flexDirection:'row',gap:tokens.space}}><Button label="Guardar" loading={loading} onPress={attempt}/><Button label="Cancelar" variant="outline" disabled={loading} onPress={cancel}/></View>}<ConfirmDialog visible={!!confirm} title={confirm==='cancel'?'Descartar cambios':'Confirmar guardado'} description={confirm==='cancel'?'Se perderán los cambios sin guardar.':'¿Querés guardar los datos ingresados?'} danger={confirm==='cancel'} confirmLabel={confirm==='cancel'?'Descartar':'Guardar'} onClose={()=>setConfirm(false)} onConfirm={confirm==='cancel'?()=>{setConfirm(false);setDirty(false);onCancel?.();}:save}/></View>;
}
