import React, { useMemo, useState } from 'react';
import { View, Text, FlatList, Pressable, useWindowDimensions } from 'react-native';
import Package from 'lucide-react-native/icons/package';
import Icon from '../Functional/icon';
import { fontFamily } from '../../theme/typography';
import { focusStyle } from '../../theme/controls';
import Input from '../Input/input';
import { NumberInput } from '../Input/controls';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';

export function validateArticleLines(value, { required = false, includeUnit = false, includeMoney = false, quantityRules = {} } = {}) {
  if (!Array.isArray(value) || (required && !value.length)) return 'Seleccioná al menos un artículo';
  if (value.length > 50) return 'Máximo 50 artículos';
  const ids = new Set();
  for (const item of value) {
    if (!item?.id) return 'Seleccioná el artículo de cada fila';
    if (ids.has(item.id)) return 'No repitas artículos';
    ids.add(item.id);
    if (!Number.isFinite(Number(item.cantidad)) || Number(item.cantidad) <= 0) return 'Las cantidades deben ser positivas';
    if (quantityRules.integerUnits?.includes(item.unidad) && !Number.isSafeInteger(Number(item.cantidad))) return `${item.unidad}: ingresá un entero positivo`;
    if (includeMoney && (!Number.isFinite(Number(item.valor ?? 0)) || Number(item.valor ?? 0) < 0)) return 'Precio inválido';
    if (includeUnit && !item.unidad) return 'El artículo debe tener una unidad vigente';
  }
  return '';
}

export default function ArticleLines({label,value=[],onChange,disabled,options=[],includeUnit=false,includeMoney=false,currency='pesos',quantityRules={}}){
 const theme=useCantappTheme();const viewport=useWindowDimensions();
 const [contentWidth,setContentWidth]=useState(viewport.width-48);
 const wide=contentWidth>=680;const compact=contentWidth<560;
 const [query,setQuery]=useState('');const [draft,setDraft]=useState({id:'',cantidad:'1',valor:'0'});const [draftError,setDraftError]=useState('');
 const rows=Array.isArray(value)?value:[];
 const byId=useMemo(()=>new Map(options.map(option=>[String(option.value),option])),[options]);
 const available=options.filter(option=>!rows.some(row=>String(row.id)===String(option.value))
  &&`${option.label} ${option.value}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
 const selected=byId.get(String(draft.id));
 const update=(index,change)=>onChange?.(rows.map((row,position)=>position===index?{...row,...change}:row));
 const add=()=>{
  if(disabled||!selected||rows.length>=50||rows.some(row=>String(row.id)===String(draft.id)))return;
  const line={id:String(selected.value),cantidad:draft.cantidad,unidad:selected.unidad||'',...(includeMoney?{valor:draft.valor}: {})};
  const error=validateArticleLines([line],{required:true,includeUnit,includeMoney,quantityRules});
  setDraftError(error);if(error)return;
  onChange?.([...rows,line]);setDraft({id:'',cantidad:'1',valor:'0'});
 };
 const description=(option,fallback)=>{
  const label=String(option?.label||fallback||'');
  const suffix=` (${option?.value??fallback})`;
  return label.endsWith(suffix)?label.slice(0,-suffix.length):label;
 };
 const choose=item=>{setDraft({id:String(item.value),cantidad:'1',valor:'0'});setDraftError('');};
 const quantityControl=(amount,onAmountChange,inactive,controlLabel)=><View style={{flexDirection:'row',gap:4,alignItems:'flex-end',width:176}}>
  <Button iconOnly icon="minus" variant="outline" accessibilityLabel={`Disminuir ${controlLabel.toLowerCase()}`} disabled={inactive}
   onPress={()=>onAmountChange(String((Number.isFinite(Number(amount))?Number(amount):0)-1))}/>
  <View style={{flex:1,minWidth:0}}><NumberInput label={controlLabel} value={amount} disabled={inactive} inputStyle={{textAlign:'center'}} onChange={onAmountChange}/></View>
  <Button iconOnly icon="plus" variant="outline" accessibilityLabel={`Aumentar ${controlLabel.toLowerCase()}`} disabled={inactive}
   onPress={()=>onAmountChange(String((Number.isFinite(Number(amount))?Number(amount):0)+1))}/>
 </View>;
 return <View onLayout={event=>setContentWidth(event.nativeEvent.layout.width)} style={{gap:16,minWidth:0}}>
  <View style={{flexDirection:'row',alignItems:'center',gap:8}}>
   <Package size={20} color={theme.special} accessible={false}/>
   <Text style={{fontFamily,color:theme.text,fontSize:16,fontWeight:'600',flex:1}}>{label}</Text>
  </View>
  <View style={{flexDirection:wide?'row':'column',gap:12,alignItems:'stretch'}}>
   <View style={{flex:wide?1:undefined,minWidth:0,gap:8}}>
    <Input label="Buscar artículos" value={query} onChange={setQuery} disabled={disabled} placeholder="Código o descripción"/>
    <FlatList style={{height:wide?300:240,flexGrow:0,borderWidth:1,borderColor:theme.border,borderRadius:8,backgroundColor:theme.surface}}
     nestedScrollEnabled keyboardShouldPersistTaps="handled" data={available} keyExtractor={item=>String(item.value)} extraData={{draftId:draft.id,disabled}}
     renderItem={({item})=>{
      const active=String(item.value)===String(draft.id);const inactive=disabled||item.disabled;
      return <Pressable accessibilityRole="button" accessibilityLabel={`Seleccionar ${description(item)} · Código ${item.value}`}
       accessibilityState={{selected:active,disabled:!!inactive}} disabled={inactive} onPress={()=>choose(item)}
       style={({focused})=>[{flexDirection:'row',alignItems:'center',gap:10,padding:8,minHeight:64,borderBottomWidth:1,
        borderBottomColor:theme.border,borderLeftWidth:3,borderLeftColor:active?theme.success:'transparent',
        backgroundColor:active?theme.selection||theme.hover:theme.surface,opacity:inactive?0.5:1},focused&&focusStyle(theme.focus)]}>
       <View style={{width:32,height:32,borderRadius:6,alignItems:'center',justifyContent:'center',backgroundColor:theme.surfaceElevated}}>
        {active?<Icon name="check" size={18} color={theme.success}/>:<Package size={18} color={theme.muted} accessible={false}/>}
       </View>
       <View style={{flex:1,minWidth:0,gap:3}}>
        <Text numberOfLines={2} style={{fontFamily,color:theme.text,fontSize:13,fontWeight:active?'600':'400'}}>{description(item)}</Text>
        <Text numberOfLines={1} style={{fontFamily,color:theme.muted,fontSize:11}}>Código {item.value}{item.unidad?` · ${item.unidad}`:''}</Text>
       </View>
       <Button iconOnly icon="plus" variant={active?'secondary':'outline'} accessibilityLabel={`Seleccionar artículo ${item.value}`} disabled={inactive}
        onPress={event=>{event.stopPropagation?.();choose(item);}}/>
      </Pressable>;
     }}
     ListEmptyComponent={<Text style={{fontFamily,color:theme.muted,padding:16}}>Sin artículos disponibles para esta búsqueda</Text>}/>
   </View>
   <View style={{width:wide?248:undefined,minWidth:0,gap:12,padding:12,borderWidth:1,borderColor:theme.border,borderRadius:8,backgroundColor:theme.surfaceElevated,justifyContent:'space-between'}}>
    <View style={{gap:6}}>
     <Text style={{fontFamily,color:theme.muted,fontSize:12}}>Artículo a agregar</Text>
     <Text numberOfLines={3} style={{fontFamily,color:theme.text,fontSize:14,fontWeight:'600'}}>{selected?description(selected):'Seleccioná un artículo del catálogo'}</Text>
     {selected&&<Text style={{fontFamily,color:theme.muted,fontSize:12}}>Código {selected.value}{selected.unidad?` · ${selected.unidad}`:''}</Text>}
    </View>
    <View style={{gap:10}}>
     {quantityControl(draft.cantidad,cantidad=>{setDraft(old=>({...old,cantidad}));setDraftError('');},disabled||!selected,'Cantidad')}
     {includeMoney&&<NumberInput label={`Precio unitario (${currency==='dolares'?'USD':'ARS'})`} value={draft.valor} disabled={disabled||!selected}
      onChange={valor=>{setDraft(old=>({...old,valor}));setDraftError('');}}/>}
     {draftError&&<Text accessibilityRole="alert" style={{fontFamily,color:theme.danger,fontSize:12}}>{draftError}</Text>}
     <Button label="Agregar artículo" icon="plus" disabled={disabled||!selected||rows.length>=50} onPress={add}/>
    </View>
   </View>
  </View>
  <View style={{gap:8}}>
   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:8}}>
    <Text style={{fontFamily,color:theme.text,fontSize:14,fontWeight:'600',flex:1}}>Artículos seleccionados</Text>
    <View style={{paddingHorizontal:10,paddingVertical:4,borderRadius:12,backgroundColor:theme.selection||theme.hover}}>
     <Text accessibilityLabel={`${rows.length} artículos seleccionados de 50`} style={{fontFamily,color:theme.text,fontSize:12,fontWeight:'600'}}>{rows.length}/50</Text>
    </View>
   </View>
   {rows.map((row,index)=>{
    const option=byId.get(String(row.id));const unit=row.unidad||option?.unidad;
    return <View key={row.id||index} style={{flexDirection:'row',flexWrap:'wrap',alignItems:'center',gap:10,borderWidth:1,borderColor:theme.border,padding:10,borderRadius:8,backgroundColor:theme.surface}}>
     <View style={{flexDirection:'row',alignItems:'center',gap:8,flexGrow:1,flexBasis:compact?'100%':0,minWidth:0}}>
      <Package size={20} color={theme.muted} accessible={false}/>
      <View style={{flex:1,minWidth:0,gap:3}}>
       <Text numberOfLines={2} style={{fontFamily,color:theme.text,fontSize:13,fontWeight:'600'}}>{description(option,String(row.id))}</Text>
       <Text numberOfLines={1} style={{fontFamily,color:theme.muted,fontSize:11}}>Código {row.id}{includeUnit||unit?` · Unidad: ${unit||'Sin unidad'}`:''}</Text>
      </View>
     </View>
     <View style={{flexDirection:'row',flexWrap:'wrap',alignItems:'flex-end',justifyContent:compact?'space-between':'flex-end',gap:8,flexGrow:compact?1:0,minWidth:0}}>
      {quantityControl(row.cantidad,cantidad=>update(index,{cantidad}),disabled,`Cantidad ${index+1}`)}
      <Button iconOnly icon="delete" variant="outline" accessibilityLabel={`Quitar artículo ${index+1}`} disabled={disabled}
       onPress={()=>onChange?.(rows.filter((_,position)=>position!==index))}/>
      {includeMoney&&<View style={{width:compact?'100%':156}}><NumberInput label={`Precio unitario ${index+1} (${currency==='dolares'?'USD':'ARS'})`}
       disabled={disabled} value={row.valor??0} onChange={valor=>update(index,{valor})}/></View>}
     </View>
    </View>;
   })}
   {!rows.length&&<View style={{padding:16,borderWidth:1,borderColor:theme.border,borderRadius:8,backgroundColor:theme.surface}}>
    <Text style={{fontFamily,color:theme.muted,textAlign:'center'}}>Todavía no agregaste artículos</Text>
   </View>}
  </View>
 </View>;
}