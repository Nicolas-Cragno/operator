import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { formatValue } from '../../utils/data';

export default function ExpandableText({ value, label = 'Contenido', numberOfLines = 2 }) {
  const theme = useCantappTheme();
  const text = formatValue(value);
  // Key the local state by content so a recycled cell starts collapsed.
  return <Content key={text} text={text} label={label} numberOfLines={numberOfLines} theme={theme} />;
}

function Content({ text, label, numberOfLines, theme }) {
  const [expanded, setExpanded] = useState(false);
  const [truncated, setTruncated] = useState(text.length > 48 || text.includes('\n'));
  return (
    <View style={{ minWidth: 0, gap: 2 }}>
      <Text numberOfLines={expanded ? undefined : numberOfLines} ellipsizeMode="tail"
        style={{ color: theme.text, fontFamily, fontSize: 14, lineHeight: 20 }}
        onTextLayout={event => {
          if (!expanded) setTruncated(text.length > 48 || text.includes('\n') || event.nativeEvent.lines.length >= numberOfLines);
        }}>{text}</Text>
      {(truncated || expanded) && (
        <Pressable accessibilityRole="button" accessibilityLabel={`${expanded ? 'Contraer' : 'Expandir'} ${label}`}
          accessibilityState={{ expanded }} hitSlop={4}
          onPress={event => { event.stopPropagation?.(); setExpanded(current => !current); }}
          style={{ alignSelf: 'flex-start', minHeight: 44, justifyContent: 'center', paddingHorizontal: 2 }}>
          <Text style={{ color: theme.info, fontFamily, fontSize: 12, textDecorationLine: 'underline' }}>
            {expanded ? 'Ver menos' : 'Ver m\u00e1s'}
          </Text>
        </Pressable>
      )}
    </View>
  );
}