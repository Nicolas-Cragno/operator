import React, { useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import CardIcon from './cardIcon';
import { useCantappTheme } from '../../theme/themeContext';

export default function ResourceGrid({ items = [], onPress }) {
  const theme = useCantappTheme();
  const viewport = useWindowDimensions();
  const [width, setWidth] = useState(0);
  const available = width || Math.max(0, viewport.width - 32);
  const columns = available >= 1024 ? 4 : available >= 600 ? 3 : 2;
  const gap = 10;
  const itemWidth = Math.max(0, (available - gap * (columns - 1)) / columns);
  return (
    <ScrollView style={{ flex: 1, minHeight: 0 }} contentContainerStyle={{ paddingBottom: 12 }}
      onLayout={event => setWidth(event.nativeEvent.layout.width)}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap }}>
        {items.map(item => (
          <CardIcon key={item.id} text={item.label} icon={item.icon}
            onPress={() => onPress?.(item)}
            style={{ width: itemWidth, minHeight: 80, padding: 12, marginVertical: 0,
              backgroundColor: theme.surface, borderColor: theme.border, borderRadius: 8 }} />
        ))}
      </View>
    </ScrollView>
  );
}