import { tokens } from '../../theme/tokens';
import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, FlatList, useWindowDimensions } from 'react-native';
import Input from './input';
import { Popover } from '../Modal/notifications';
import Checkbox from './checkbox';
import Button from '../Button/button';
import { RadioGroup } from './controls';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';

export default function MultiSelect({label='Opciones',value=[],onChange,options=[],disabled=false,required=false,error,presentation='popover',multiple=true,maxSelection=Infinity}){
 const t=useCantappTheme();const {height}=useWindowDimensions();
 const [open,setOpen]=useState(false);const [query,setQuery]=useState('');const [vehicleClass,setVehicleClass]=useState('');
 const items=useMemo(()=>options.map(option=>typeof option==='string'?{label:option,value:option}:option),[options]);
 const selected=[].concat(value??[]).filter(key=>key!==''&&key!=null).map(String);
 const toggle=key=>{
  const id=String(key);const active=selected.includes(id);
  if(disabled||(!active&&multiple&&selected.length>=maxSelection))return;
  onChange?.(multiple?(active?selected.filter(item=>item!==id):[...selected,id]):active?'':id);
 };
 const isDisabled=item=>disabled||item.disabled||(multiple&&selected.length>=maxSelection&&!selected.includes(String(item.value)));
 const rows=items.filter(item=>`${item.label} ${item.value} ${item.interno||''} ${item.dominio||''}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())
  &&(presentation!=='vehicles'||!vehicleClass||item.vehicleClass===vehicleClass));
 const selectedItems=<View style={{flexDirection:'row',flexWrap:'wrap',gap:4}}>{selected.map(key=>{
  const text=String(items.find(item=>String(item.value)===key)?.label||key);
  return <Button key={key} label={text} icon="close" variant="secondary" accessibilityLabel={`Quitar ${text}`} disabled={disabled} onPress={()=>toggle(key)}/>;
 })}</View>;
 const title=<Text style={{fontFamily,color:t.text,fontSize:12}}>{label}{required?' \u00b7 Obligatorio':''}</Text>;
 if(presentation==='vehicles'){
  const classifications=[{value:'',label:'Todos'},...[
   {value:'normal',label:'Normal'},{value:'bitren',label:'Bitr\u00e9n'},
  ].filter(option=>items.some(item=>item.vehicleClass===option.value))];
  const listHeight=Math.max(180,Math.min(320,height*0.38));
  return <View style={{gap:8,borderWidth:1,borderColor:error?t.danger:t.border,borderRadius:tokens.radius,padding:8,minWidth:0}}>
   {title}
   <Input label="Buscar por interno o dominio" value={query} onChange={setQuery} disabled={disabled}/>
   {classifications.length>1&&<RadioGroup label="Tipo de unidad" variant="buttons" options={classifications} value={vehicleClass} onChange={setVehicleClass} disabled={disabled}/>}
   <FlatList style={{height:listHeight,flexGrow:0}} nestedScrollEnabled keyboardShouldPersistTaps="handled"
    data={rows} keyExtractor={item=>String(item.value)} extraData={{selected,disabled,maxSelection}}
    renderItem={({item})=><Checkbox label={item.label} value={selected.includes(String(item.value))} disabled={isDisabled(item)} onChange={()=>toggle(item.value)}/>}
    ListEmptyComponent={<Text style={{fontFamily,color:t.muted,padding:8}}>Sin coincidencias</Text>}/>
   <View style={{gap:4,borderTopWidth:1,borderColor:t.border,paddingTop:8,backgroundColor:t.surface}}>
    <Text style={{fontFamily,color:t.text,fontWeight:'600'}}>Seleccionados ({selected.length}{Number.isFinite(maxSelection)?`/${maxSelection}`:''})</Text>
    {selected.length?<ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" style={{maxHeight:160}}>{selectedItems}</ScrollView>:<Text style={{fontFamily,color:t.muted}}>Sin unidades seleccionadas</Text>}
   </View>
   {error&&<Text accessibilityRole="alert" style={{color:t.danger}}>{error}</Text>}
  </View>;
 }
 return <View style={{gap:tokens.space}}>{title}{selectedItems}<Popover open={open&&!disabled} onOpenChange={setOpen} label={label} trigger={<Button label={selected.length?`${selected.length} seleccionados`:'Seleccionar...'} icon="down" variant="outline" disabled={disabled} accessibilityState={{expanded:open&&!disabled}} onPress={()=>setOpen(old=>!old)}/>}><Input label={`Buscar ${label}`} value={query} onChange={setQuery}/><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" style={{maxHeight:240}}>{rows.map(item=><Checkbox key={item.value} label={item.label} value={selected.includes(String(item.value))} onChange={()=>toggle(item.value)} disabled={isDisabled(item)}/>)}</ScrollView></Popover>{error&&<Text accessibilityRole="alert" style={{color:t.danger}}>{error}</Text>}</View>;
}