import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import Select from './select';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';

export default function AsyncSelect({loadOptions,params={},preserveExisting=true,...props}){
 const t=useCantappTheme();const [state,setState]=useState({loading:false,options:[]});const [retry,setRetry]=useState(0);
 const request=JSON.stringify(params);
 useEffect(()=>{
  let active=true;setState({loading:true,options:[]});
  Promise.resolve().then(()=>loadOptions?.(JSON.parse(request))||[]).then(options=>{
   if(active)setState({loading:false,options});
  }).catch(error=>{if(active)setState({loading:false,options:[],error:error.message||'No se pudieron cargar las opciones'});});
  return ()=>{active=false;};
 },[loadOptions,request,retry]);
 let options=state.options;
 if(preserveExisting&&props.value!=null&&props.value!==''&&!options.some(option=>String(option.value)===String(props.value))){
  options=[...options,{value:props.value,label:String(props.value)}];
 }
 return <View style={{gap:4}}>
  <Select {...props} options={[{value:'',label:'Sin asignar'},...options]} disabled={props.disabled||state.loading}
   placeholder={state.loading?'Cargando documentos…':props.placeholder}/>
  {state.error&&<><Text accessibilityRole="alert" style={{color:t.danger}}>{state.error}</Text><Button label="Volver a cargar documentos" variant="outline" disabled={props.disabled} onPress={()=>setRetry(value=>value+1)}/></>}
 </View>;
}