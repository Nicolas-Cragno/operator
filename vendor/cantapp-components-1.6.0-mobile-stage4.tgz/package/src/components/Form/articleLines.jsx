import React, { useMemo, useState } from 'react';
import { View, Text, FlatList } from 'react-native';
import Input from '../Input/input';
import { NumberInput } from '../Input/controls';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';

export function validateArticleLines(value, { required = false, includeUnit = false, includeMoney = false, quantityRules = {} } = {}) {
  if (!Array.isArray(value) || (required && !value.length)) return 'Seleccioná al menos un artículo';
  if (value.length > 50) return 'Máximo 50 artículos';
  const ids = new Set();
  for (const item of value) {
    if (!item?.id) return 'Seleccioná el artículo de cada fila';
    if (ids.has(item.id)) return 'No repitas artículos';
    ids.add(item.id);
    if (!Number.isFinite(Number(item.cantidad)) || Number(item.cantidad) <= 0) return 'Las cantidades deben ser positivas';
    if (quantityRules.integerUnits?.includes(item.unidad) && !Number.isSafeInteger(Number(item.cantidad))) return `${item.unidad}: ingresá un entero positivo`;
    if (includeMoney && (!Number.isFinite(Number(item.valor ?? 0)) || Number(item.valor ?? 0) < 0)) return 'Precio inválido';
    if (includeUnit && !item.unidad) return 'El artículo debe tener una unidad vigente';
  }
  return '';
}

export default function ArticleLines({label,value=[],onChange,disabled,options=[],includeUnit=false,includeMoney=false,currency='pesos',quantityRules={}}){
 const theme=useCantappTheme();
 const [query,setQuery]=useState('');const [draft,setDraft]=useState({id:'',cantidad:'1',valor:'0'});const [draftError,setDraftError]=useState('');
 const rows=Array.isArray(value)?value:[];
 const byId=useMemo(()=>new Map(options.map(option=>[String(option.value),option])),[options]);
 const available=options.filter(option=>!rows.some(row=>String(row.id)===String(option.value))
  &&`${option.label} ${option.value}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
 const selected=byId.get(String(draft.id));
 const update=(index,change)=>onChange?.(rows.map((row,position)=>position===index?{...row,...change}:row));
 const add=()=>{
  if(disabled||!selected||rows.length>=50||rows.some(row=>String(row.id)===String(draft.id)))return;
  const line={id:String(selected.value),cantidad:draft.cantidad,unidad:selected.unidad||'',...(includeMoney?{valor:draft.valor}: {})};
  const error=validateArticleLines([line],{required:true,includeUnit,includeMoney,quantityRules});
  setDraftError(error);if(error)return;
  onChange?.([...rows,line]);setDraft({id:'',cantidad:'1',valor:'0'});
 };
 return <View style={{gap:12}}>
  <Text style={{color:theme.text,fontWeight:'600'}}>{label}</Text>
  <Input label="Buscar artículos" value={query} onChange={setQuery} disabled={disabled} placeholder="Código o descripción"/>
  <FlatList style={{height:180,flexGrow:0,borderWidth:1,borderColor:theme.border,borderRadius:8}}
   nestedScrollEnabled keyboardShouldPersistTaps="handled" data={available} keyExtractor={item=>String(item.value)} extraData={draft.id}
   renderItem={({item})=><Button label={String(item.label)} variant={String(item.value)===String(draft.id)?'secondary':'ghost'}
    disabled={disabled||item.disabled} accessibilityState={{selected:String(item.value)===String(draft.id)}} style={{alignItems:'flex-start'}}
    onPress={()=>{setDraft({id:String(item.value),cantidad:'1',valor:'0'});setDraftError('');}}/>}
   ListEmptyComponent={<Text style={{color:theme.muted,padding:12}}>Sin artículos disponibles para esta búsqueda</Text>}/>
  <Text style={{color:theme.text}}>{selected?`${selected.label}${selected.unidad?` · ${selected.unidad}`:''}`:'Seleccioná un artículo del listado'}</Text>
  <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,alignItems:'flex-end'}}>
   <View style={{flexGrow:1,minWidth:140}}><NumberInput label="Cantidad a agregar" value={draft.cantidad} disabled={disabled||!selected}
    onChange={cantidad=>{setDraft(old=>({...old,cantidad}));setDraftError('');}}/></View>
   {includeMoney&&<View style={{flexGrow:1,minWidth:140}}><NumberInput label={`Precio unitario (${currency==='dolares'?'USD':'ARS'})`}
    value={draft.valor} disabled={disabled||!selected} onChange={valor=>{setDraft(old=>({...old,valor}));setDraftError('');}}/></View>}
   <Button label="Agregar artículo" icon="plus" variant="outline" disabled={disabled||!selected||rows.length>=50} onPress={add}/>
  </View>
  {draftError&&<Text accessibilityRole="alert" style={{color:theme.danger}}>{draftError}</Text>}
  <Text style={{color:theme.text,fontWeight:'600'}}>Artículos seleccionados ({rows.length}/50)</Text>
  {rows.map((row,index)=><View key={row.id||index} style={{gap:8,borderWidth:1,borderColor:theme.border,padding:12,borderRadius:8}}>
   <Text style={{color:theme.text,fontWeight:'600'}}>{byId.get(String(row.id))?.label||String(row.id)}</Text>
   <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,alignItems:'flex-end'}}>
    <View style={{flexGrow:1,minWidth:140}}><NumberInput label={`Cantidad ${index+1}`} required disabled={disabled} value={row.cantidad} onChange={cantidad=>update(index,{cantidad})}/></View>
    {includeMoney&&<View style={{flexGrow:1,minWidth:140}}><NumberInput label={`Precio unitario ${index+1} (${currency==='dolares'?'USD':'ARS'})`}
     disabled={disabled} value={row.valor??0} onChange={valor=>update(index,{valor})}/></View>}
    <Button label={`Quitar artículo ${index+1}`} icon="close" variant="outline" disabled={disabled} onPress={()=>onChange?.(rows.filter((_,position)=>position!==index))}/>
   </View>
   {includeUnit&&<Text style={{color:theme.text}}>Unidad: {row.unidad||'Sin unidad'}</Text>}
  </View>)}
  {!rows.length&&<Text style={{color:theme.muted}}>Sin artículos seleccionados</Text>}
 </View>;
}