import React from 'react';
import { View, Text } from 'react-native';
import Checkbox from '../Input/checkbox';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { tokens } from '../../theme/tokens';

export default function CheckPanel({label='Chequeos',value,onChange,items=[],representation='object',disabled=false,required=false,error}){
 const t=useCantappTheme();const array=representation==='array';
 const selected=array?(Array.isArray(value)?value:[]):null;
 const checked=key=>array?selected.includes(key):!!value?.[key];
 const toggle=key=>{
  if(disabled)return;
  onChange?.(array?(checked(key)?selected.filter(item=>item!==key):[...selected,key]):{...value,[key]:!checked(key)});
 };
 return <View style={{gap:8,padding:12,borderWidth:1,borderColor:error?t.danger:t.border,borderRadius:tokens.radius,backgroundColor:t.surface}}>
  <Text style={{fontFamily,color:t.text,fontWeight:'600'}}>{label}{required?' \u00b7 Obligatorio':''}</Text>
  <View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>
   {items.map(item=>{const key=item.key??item.value;return <Checkbox key={key} label={item.label} variant="button" value={checked(key)} disabled={disabled||item.disabled} onChange={()=>toggle(key)}/>;})}
  </View>
  {!items.length&&<Text style={{fontFamily,color:t.muted}}>Sin chequeos disponibles</Text>}
  {error&&<Text accessibilityRole="alert" style={{fontFamily,color:t.danger,fontSize:12}}>{error}</Text>}
 </View>;
}