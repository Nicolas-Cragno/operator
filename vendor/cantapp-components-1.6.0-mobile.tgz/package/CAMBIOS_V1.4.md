# CANTAPP COMPONENTS V1.4

Se eliminaron del catálogo, exportaciones y archivos las familias descartadas por el usuario. Se incorporaron controles booleanos con estado, búsqueda por campos, select filtrable, fecha editable y calendario simple, modales blancos con CloseButton, tabla de viajes ordenable, fichas 50/50, navegación y loading.

Los formularios específicos siguen requiriendo una correspondencia exhaustiva de campos con BESS y los PDFs necesitan una estrategia nativa para generar/imprimir. La plantilla de ReporteAveria se conserva como recurso; no se afirma que jsPDF de BESS funcione en Android.

Nexar utiliza jsPDF en src/functions/docFunctions.js (web). La migración Android requiere otra implementación.

FormStandard ahora interpreta tipos y optionsByField, con dropdowns locales de ejemplo en los formularios existentes. Los catálogos de ejemplo no equivalen a los documentos reales de Firestore.
