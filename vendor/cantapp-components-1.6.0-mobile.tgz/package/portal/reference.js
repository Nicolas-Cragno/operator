export const reference = {
  FormEventoPorteria: {
    description: 'Registra entradas y salidas de choferes, tractores y cargas con chequeos. Permite precargar un viaje programado. El ejemplo valida y muestra el envío en memoria.',
    props: 'data: object = {} (valores iniciales; prevalecen sobre viajeProgramado) · viajeProgramado: object | null = null · optionsByField: object = {} (opciones locales {value,label} por operador, persona, tractor, furgon, cliente y destino) · onSubmit: función sin valor predeterminado (recibe los valores, area="porteria" y formulario="movPorteria") · onCancel: función sin valor predeterminado · loading: boolean = false. Valores iniciales: tipo="SALIDA" si hay viaje programado, de lo contrario sin definir; furgon=[]; chequeos=[]; area="porteria".',
    code: `import React, { useState } from 'react';
import { Text, View } from 'react-native';

const opciones = {
  operador: [{ value: 'op-1', label: 'Operador de ejemplo' }],
  persona: [{ value: 'p-1', label: 'Ana Pérez' }],
  tractor: [{ value: 't-1', label: 'Tractor 745' }],
  furgon: [{ value: 'f-1', label: 'Furgón 101' }],
  cliente: [{ value: 'c-1', label: 'Cliente de ejemplo' }],
  destino: [{ value: 'd-1', label: 'Depósito' }],
};
const viaje = { operador: 'op-1', persona: 'p-1', tractor: 't-1', furgon: ['f-1'] };
export default function Ejemplo() {
  const [resultado, setResultado] = useState('');
  return <View>
    <FormEventoPorteria viajeProgramado={viaje} optionsByField={opciones}
      onSubmit={datos => setResultado(JSON.stringify(datos, null, 2))}
      onCancel={() => setResultado('Cancelado')} />
    <Text>{resultado}</Text>
  </View>;
}`,
  },
  FormEventoPorteriaParticular: {
    description: 'Formulario para entradas y salidas de particulares, con persona, vehículo y detalle. El ejemplo usa opciones locales y muestra el envío simulado.',
    props: 'data: object = {} (tipo, operador, persona, vehiculo, detalle) · optionsByField: object = {} (opciones {value,label} por operador, persona y vehiculo) · onSubmit: función sin valor predeterminado (recibe valores, area="porteria" y formulario="movPorteriaParticular") · onCancel: función sin valor predeterminado · loading: boolean = false. area se fija en "porteria"; los otros campos no tienen valor predeterminado. tipo, operador y persona son obligatorios.',
    code: `import React, { useState } from 'react';
import { Text, View } from 'react-native';

const datos = { tipo: 'ENTRADA', operador: 'op-1', persona: 'p-1', vehiculo: 'v-1' };
const opciones = {
  operador: [{ value: 'op-1', label: 'Operador de ejemplo' }],
  persona: [{ value: 'p-1', label: 'Ana Pérez' }],
  vehiculo: [{ value: 'v-1', label: 'Utilitario · AD789GH' }],
};
export default function Ejemplo() {
  const [resultado, setResultado] = useState('');
  return <View>
    <FormEventoPorteriaParticular data={datos} optionsByField={opciones}
      onSubmit={valores => setResultado(JSON.stringify(valores, null, 2))}
      onCancel={() => setResultado('Cancelado')} />
    <Text>{resultado}</Text>
  </View>;
}`,
  },
  FormEventoPorteriaProveedor: {
    description: 'Registra movimientos de proveedores con destino o sector, empresa, persona, vehículo y remito. La vista previa trabaja exclusivamente en memoria.',
    props: 'data: object = {} (tipo, operador, destino, empresa, persona, vehiculo, remito, detalle) · optionsByField: object = {} (opciones {value,label} por operador, destino, empresa, persona y vehiculo) · onSubmit: función sin valor predeterminado (recibe valores, area="porteria" y formulario="movPorteriaProveedor") · onCancel: función sin valor predeterminado · loading: boolean = false. area se fija en "porteria"; los otros campos no tienen valor predeterminado. tipo, operador y destino son obligatorios.',
    code: `import React, { useState } from 'react';
import { Text, View } from 'react-native';

const datos = { tipo: 'ENTRADA', operador: 'op-1', destino: 'd-1', empresa: 'e-1', remito: 'R-0001' };
const opciones = {
  operador: [{ value: 'op-1', label: 'Operador de ejemplo' }],
  destino: [{ value: 'd-1', label: 'Depósito' }],
  empresa: [{ value: 'e-1', label: 'Suministros del Sur' }],
  persona: [{ value: 'p-1', label: 'Ana Pérez' }],
  vehiculo: [{ value: 'v-1', label: 'Utilitario · AD789GH' }],
};
export default function Ejemplo() {
  const [resultado, setResultado] = useState('');
  return <View>
    <FormEventoPorteriaProveedor data={datos} optionsByField={opciones}
      onSubmit={valores => setResultado(JSON.stringify(valores, null, 2))}
      onCancel={() => setResultado('Cancelado')} />
    <Text>{resultado}</Text>
  </View>;
}`,
  },
  FloatButton: {
    description: 'Botón circular flotante con icono. Probá las distancias inferior y derecha dentro del contenedor de la vista previa.',
    props: 'onPress: función sin valor predeterminado · icon: string = "qr" · disabled: boolean = false · bottom: number = 24 · right: number = 20 · accessibilityLabel: string = "Escanear QR". Posición absoluta respecto de su contenedor; tamaño 56 × 56.',
    code: `import React, { useState } from 'react';
import { Button, Text, View } from 'react-native';

export default function Ejemplo() {
  const [bottom, setBottom] = useState(24);
  const [right, setRight] = useState(20);
  const [resultado, setResultado] = useState('');
  return <View>
    <Button title="Cambiar distancia inferior" onPress={() => setBottom(bottom === 24 ? 100 : 24)} />
    <Button title="Cambiar distancia derecha" onPress={() => setRight(right === 20 ? 100 : 20)} />
    <View style={{ position: 'relative', height: 240 }}>
      <FloatButton bottom={bottom} right={right} onPress={() => setResultado('Botón pulsado')} />
    </View>
    <Text>{resultado}</Text>
  </View>;
}`,
  },
  QROptionsModal: {
    description: 'Modal de acciones de un recurso leído por QR. Al elegir una opción, llama primero a onClose y después a onSelect con el objeto completo.',
    props: 'visible: boolean = false · onClose: función sin valor predeterminado · opciones: array = [] ({id, title, label, disabled}; title prevalece sobre label y, si faltan ambos, muestra "Abrir"; id usa el índice si falta) · onSelect: función sin valor predeterminado · title: string = "Acciones del recurso". Sin opciones muestra "No hay opciones disponibles.".',
    code: `import React, { useState } from 'react';
import { Button, Text, View } from 'react-native';

const opciones = [{ id: 'ficha', title: 'VER FICHA' }, { id: 'movimiento', title: 'ENTRADA/SALIDA' }];
export default function Ejemplo() {
  const [visible, setVisible] = useState(false);
  const [seleccion, setSeleccion] = useState('Ninguna');
  return <View>
    <Button title="Abrir opciones del QR" onPress={() => setVisible(true)} />
    <QROptionsModal visible={visible} opciones={opciones}
      onClose={() => setVisible(false)} onSelect={opcion => setSeleccion(opcion.title)} />
    <Text>Opción seleccionada: {seleccion}</Text>
  </View>;
}`,
  },
  Tabla: { description: 'Listado paginado: tarjetas con etiquetas en celular y columnas en escritorio. serverSide conserva los registros recibidos sin filtrar, ordenar ni volver a paginar.', props: 'data · columns [{key,label,type,width,render,sortable}] · rowKey · searchable · search/onSearchChange · sort/onSortChange · serverSide · page/pageSize/total/hasMore · onChangePage · selectedKeys/onSelectionChange (claves string) · filters · renderActions · loading/error/onRetry · onRowPress', code: `<Tabla data={registros} columns={columnas} serverSide page={page}
  pageSize={25} total={total} onChangePage={setPage}
  loading={loading} error={error} onRowPress={setRegistro} />
<Ficha visible={!!registro} data={registro || {}} onClose={() => setRegistro(null)} />` },
  Ficha: { description: 'Ficha configurable por campos y secciones. Usá visible para abrirla como modal por encima de toda la aplicación; cerrar no desmonta el listado.', props: 'visible · title · data · fields [{key,label,type,render}] · sections [{title,fields,render}] · relations · onOpenRelation · onEdit · onClose', code: '<Ficha visible={!!registro} data={registro || {}} fields={campos}\n  onClose={() => setRegistro(null)} />' },
  DataValue: { description: 'Conserva texto y números; reconoce Date y timestamps estructurados. Los strings de fecha necesitan type="date" o "datetime".', props: 'value · type (date, datetime, url, file, reference) · onOpenReference', code: '<DataValue value={{ seconds: 1790000000, nanoseconds: 0 }} />\n<DataValue value="30123456" />\n<DataValue value={{ contacto: { telefono: "011 4000 0000" } }} />' },
  DateInput: { description: 'Fecha dd/mm/aaaa con calendario. Sin fecha ficticia inicial. La validación final corresponde al formulario o filtro.', props: 'label · value · onChange · disabled · required · error · placeholder', code: '<DateInput label="Fecha" value={fecha} onChange={setFecha} />' },
  DateRangeFilter: { description: 'Rango inclusivo de fechas de calendario. Devuelve strings dd/mm/aaaa o vacíos; la aplicación define zona horaria y límites de consulta.', props: 'value {from,to} · onChange · onApply · onClear · disabled · loading', code: '<DateRangeFilter value={rango} onChange={setRango}\n  onApply={aplicarFiltro} onClear={limpiarFiltro} />' },
  FileInput: { description: 'Adjuntos, vista previa, progreso y errores. Los adaptadores onPick/onCapture se inyectan desde la app y gestionan permisos; el componente no sube archivos.', props: 'files [{id,name,uri,mimeType,progress,error}] · onPick · onCapture · onChange · onRemove · onError · disabled · loading', code: '<FileInput files={files} onChange={setFiles}\n  onPick={seleccionarArchivos} onCapture={capturarFoto} />' },
  Modal: { description: 'Modal nativo con fondo bloqueado, scroll independiente y cierre por X, Escape en Web o Atrás en Android.', props: 'visible · onClose · title · data · fields · children · footer · onEdit · onOpenForm · formType', code: '<Modal visible={abierto} title="Registro" onClose={cerrar}>\n  <DataValue value={registro} />\n</Modal>' },
  FormStandard: { description: 'Formulario declarativo con validación visual. Mantiene los tipos existentes al enviar; la aplicación normaliza y valida las reglas de negocio.', props: 'title · fields [{key,label,type,required,disabled,defaultValue,options}] · data · optionsByField · onSubmit · onCancel · loading', code: '<FormStandard fields={campos} data={registro}\n  onSubmit={guardar} onCancel={cerrar} loading={guardando} />' },
  Button: { description: 'Acción táctil con variantes, foco, carga y estado deshabilitado.', props: 'label/text/children · onPress · variant (primary, secondary, outline, danger) · disabled · loading · style · accessibilityLabel', code: '<Button label="Guardar" onPress={guardar} loading={guardando} />\n<Button label="Cancelar" variant="outline" onPress={cerrar} />' },
  StatusBadge: { props: 'label · tone (success, warning, danger, info)', code: '<StatusBadge label="En curso" tone="info" />' },
  KpiCard: { props: 'title · value · change · changeLabel · tone · children', code: '<KpiCard title="Viajes activos" value={32} change={8} />' },
};
