import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { Button, useCantappTheme } from '../src';

const optionsByField = {
  operador: [{ value: 'op-1', label: 'Operador de ejemplo' }, { value: 'op-2', label: 'Operador del turno tarde' }],
  persona: [{ value: 'persona-1', label: 'Ana Pérez' }, { value: 'persona-2', label: 'Juan Gómez' }],
  tractor: [{ value: 'tractor-1', label: 'Tractor 745 · AB123CD' }, { value: 'tractor-2', label: 'Tractor 746 · AC456EF' }],
  furgon: [{ value: 'furgon-1', label: 'Furgón 101' }, { value: 'furgon-2', label: 'Furgón 102' }],
  cliente: [{ value: 'cliente-1', label: 'Cliente de ejemplo' }],
  destino: [{ value: 'sector-1', label: 'Depósito' }, { value: 'sector-2', label: 'Administración' }],
  empresa: [{ value: 'empresa-1', label: 'Suministros del Sur' }],
  vehiculo: [{ value: 'vehiculo-1', label: 'Utilitario · AD789GH' }],
};
const data = {
  tipo: 'ENTRADA', operador: 'op-1', persona: 'persona-1', tractor: 'tractor-1',
  furgon: ['furgon-1'], cliente: 'cliente-1', destino: 'sector-1', cargado: true,
  empresa: 'empresa-1', vehiculo: 'vehiculo-1', remito: 'R-0001',
  detalle: 'Movimiento local de demostración.', chequeos: ['ckReporte'],
};
const formData = {
  FormEventoPorteria: Object.fromEntries(['tipo','operador','persona','tractor','furgon','cliente','destino','cargado','detalle','chequeos'].map(key => [key, data[key]])),
  FormEventoPorteriaParticular: Object.fromEntries(['tipo','operador','persona','vehiculo','detalle'].map(key => [key, data[key]])),
  FormEventoPorteriaProveedor: Object.fromEntries(['tipo','operador','destino','empresa','persona','vehiculo','remito','detalle'].map(key => [key, data[key]])),
};
const opciones = [{ id: 'ficha', title: 'VER FICHA' }, { id: 'movimiento', title: 'ENTRADA/SALIDA' }];
const scheduledData = { ...formData.FormEventoPorteria, tipo: 'SALIDA' };
const emptyData = {};

export default function PorteriaExamples({ name, Component }) {
  const theme = useCantappTheme();
  const [message, setMessage] = useState('');
  const [open, setOpen] = useState(false);
  const [bottom, setBottom] = useState(24);
  const [right, setRight] = useState(20);
  const [scheduled, setScheduled] = useState(false);
  const result = <Text selectable accessibilityLiveRegion="polite" style={{ color: theme.text }}>{message || 'Todavía no se ejecutó ninguna acción.'}</Text>;

  if (name === 'FloatButton') return <View style={{ gap: 12 }}>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {[24, 80, 140].map(value => <Button key={value} label={`bottom: ${value}`} variant={bottom === value ? 'primary' : 'outline'} onPress={() => setBottom(value)} />)}
      {[20, 80, 140].map(value => <Button key={value} label={`right: ${value}`} variant={right === value ? 'primary' : 'outline'} onPress={() => setRight(value)} />)}
    </View>
    <View style={{ position: 'relative', height: 240, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.surface, padding: 12 }}>
      <Text style={{ color: theme.muted }}>Posición dentro de esta vista previa: bottom={bottom}, right={right}</Text>
      <Component bottom={bottom} right={right} onPress={() => setMessage(`Botón pulsado en bottom=${bottom}, right=${right}`)} />
    </View>
    {result}
  </View>;

  if (name === 'QROptionsModal') return <View style={{ gap: 12 }}>
    <Button label="Abrir opciones del QR" onPress={() => setOpen(true)} />
    <Component visible={open} opciones={opciones} onClose={() => setOpen(false)} onSelect={option => setMessage(`Opción seleccionada: ${option.title} (${option.id})`)} />
    {result}
  </View>;

  return <View style={{ gap: 12 }}>
    {name === 'FormEventoPorteria' && <Button label={scheduled ? 'Probar entrada sin viaje' : 'Probar salida con viaje programado'} variant="outline" onPress={() => { setScheduled(!scheduled); setMessage(''); }} />}
    <Component key={String(scheduled)} data={scheduled ? emptyData : formData[name]} optionsByField={optionsByField}
      {...(name === 'FormEventoPorteria' ? { viajeProgramado: scheduled ? scheduledData : null } : {})}
      onSubmit={values => setMessage(`Envío simulado:\n${JSON.stringify(values, null, 2)}`)} onCancel={() => setMessage('Formulario cancelado.')} />
    {result}
  </View>;
}
