import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { Tabla, Ficha, DateRangeFilter, FormStandard, FileInput, Dashboard, KpiCard, StatusBadge, useCantappTheme } from '../src';
const people = [{ id: '30123456', nombre: 'Claudia Medina', estado: 'Activo', fecha: { seconds: 1790000000, nanoseconds: 0 }, contacto: { telefono: '011 4000 0000' } }, { id: '27876543', nombre: 'Martín Suárez', estado: 'Inactivo', fecha: null }];
const tractors = [{ id: 'T-745', dominio: 'AB123CD', estado: 'Disponible', ubicacion: 'Don Torcuato' }, { id: 'T-744', dominio: 'AC456EF', estado: 'En viaje', ubicacion: 'Ruta 3' }];
export default function Scenarios() {
  const t = useCantappTheme(); const [selected, setSelected] = useState(null); const [keys, setKeys] = useState([]); const [range, setRange] = useState({ from: '', to: '' }); const [message, setMessage] = useState(''); const [files, setFiles] = useState([]);
  return <View style={{ gap: 24 }}><Dashboard><KpiCard title="Viajes activos" value={32} change={8} /><KpiCard title="Comprobantes pendientes" value={7} tone="warning" /></Dashboard>
    <DateRangeFilter value={range} onChange={setRange} onApply={r => setMessage(`Filtro aplicado: ${r.from || 'sin inicio'} / ${r.to || 'sin fin'}`)} onClear={() => setMessage('Filtros limpiados')} />
    <Text style={{ color: t.special }}>Personas</Text><Tabla data={people} searchable selectedKeys={keys} onSelectionChange={setKeys} onRowPress={setSelected} columns={[{ key: 'id', label: 'DNI' }, { key: 'nombre', label: 'Nombre' }, { key: 'estado', label: 'Estado', render: value => <StatusBadge label={value} /> }]} />
    <Text style={{ color: t.special }}>Tractores</Text><Tabla data={tractors} onRowPress={setSelected} columns={[{ key: 'id', label: 'Interno' }, { key: 'dominio', label: 'Dominio' }, { key: 'ubicacion', label: 'Ubicación' }]} />
    <Ficha visible={!!selected} title="Ficha del registro" data={selected || {}} onClose={() => setSelected(null)} />
    <FormStandard title="Movimiento de stock (demo)" fields={[{ key: 'producto', label: 'Producto', required: true }, { key: 'cantidad', label: 'Cantidad', type: 'number', required: true }, { key: 'fecha', label: 'Fecha', type: 'date', required: true }, { key: 'observaciones', label: 'Observaciones', type: 'textarea' }]} onSubmit={() => setMessage('Movimiento validado localmente')} />
    <FileInput files={files} onChange={setFiles} onPick={async () => [{ id: `demo-${files.length}`, name: 'Remito de ejemplo.pdf', mimeType: 'application/pdf', progress: 100 }]} />
    {message ? <Text accessibilityLiveRegion="polite" style={{ color: t.success }}>{message}</Text> : null}
  </View>;
}
