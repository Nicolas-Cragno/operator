export const catalog = {
  recursos: [
    { id: "personas", label: "Personas", variants: [{id:"todos",label:"Todas",path:"/personas"},{id:"activas",label:"Activas",path:"/personas/activas"},{id:"inactivas",label:"Inactivas",path:"/personas/inactivas"},{id:"choferes",label:"Choferes",path:"/personas/choferes"},{id:"larga",label:"Larga distancia",path:"/personas/choferes/larga"},{id:"movimiento",label:"Movimiento",path:"/personas/choferes/movimiento"},{id:"fleteros",label:"Fleteros",path:"/personas/choferes/fleteros"},{id:"mecanicos",label:"Mecánicos",path:"/personas/mecanicos"},{id:"administrativos",label:"Administrativos",path:"/personas/administrativos"},{id:"serenos",label:"Serenos",path:"/personas/serenos"}] },
    { id: "tractores", label: "Tractores", variants: [{id:"todos",label:"Todos",path:"/tractores"},{id:"activos",label:"Activos",path:"/tractores/activos"},{id:"inactivos",label:"Inactivos",path:"/tractores/inactivos"},{id:"bitrenes",label:"Bitrenes",path:"/tractores/bitrenes"},{id:"simples",label:"Simples",path:"/tractores/simples"}] },
    { id: "furgones", label: "Furgones", variants: [{id:"todos",label:"Todos",path:"/furgones"},{id:"activos",label:"Activos",path:"/furgones/activos"},{id:"inactivos",label:"Inactivos",path:"/furgones/inactivos"},{id:"bitrenes",label:"Bitrenes",path:"/furgones/bitrenes"},{id:"simples",label:"Simples",path:"/furgones/simples"}] },
    { id: "vehiculos", label: "Vehículos", variants: [{id:"todos",label:"Todos",path:"/vehiculos"},{id:"activos",label:"Activos",path:"/vehiculos/activos"},{id:"inactivos",label:"Inactivos",path:"/vehiculos/inactivos"}] },
    { id: "empresas", label: "Empresas", variants: [{id:"todos",label:"Todas",path:"/empresas"},{id:"propias",label:"Propias",path:"/empresas/propias"},{id:"proveedores",label:"Proveedores",path:"/empresas/proveedores"},{id:"clientes",label:"Clientes",path:"/empresas/clientes"}] },
    { id: "stock", label: "Stock", variants: [{id:"todos",label:"Todos",path:"/stock"},{id:"herramientas",label:"Herramientas",path:"/stock/herramientas"},{id:"positivo",label:"Positivo",path:"/stock/positivo"},{id:"cero",label:"En cero",path:"/stock/cero"},{id:"negativo",label:"Negativo",path:"/stock/negativo"}] },
    { id: "depositos", label: "Depósitos", variants: [{id:"todos",label:"Todos",path:"/depositos"}] },
    { id: "estaciones", label: "Estaciones", variants: [{id:"todos",label:"Todas",path:"/estaciones"}] },
    { id: "ubicaciones", label: "Ubicaciones", variants: [{id:"todos",label:"Todas",path:"/ubicaciones"}] },
  ],
  sucesos: [
    {id:"eventos",label:"Eventos",variants:[{id:"porteria",label:"Portería",path:"/eventos/porteria"},{id:"administracion",label:"Administración",path:"/eventos/administracion"},{id:"tractores",label:"Taller tractores",path:"/eventos/tractores"},{id:"furgones",label:"Taller furgones",path:"/eventos/furgones"},{id:"trafico",label:"Tráfico",path:"/eventos/trafico"},{id:"satelital",label:"Satelital",path:"/eventos/satelital"}]},
    {id:"asignaciones",label:"Asignaciones",variants:[{id:"todos",label:"Todas",path:"/asignaciones"}]},
    {id:"cargas",label:"Cargas",variants:[{id:"todos",label:"Todas",path:"/cargas"},{id:"ypf",label:"YPF",path:"/cargas/ypf"},{id:"base",label:"BASE",path:"/cargas/base"}]},
    {id:"movimientos",label:"Movimientos",variants:[{id:"todos",label:"Todos",path:"/movimientos"}]},
    {id:"viajes",label:"Viajes",variants:[{id:"activos",label:"Activos",path:"/viajes/activos"},{id:"cerrados",label:"Cerrados",path:"/viajes/cerrados"}]},
  ]
};
export const findCatalog = (group, id) => catalog[group]?.find(x => x.id === id);
