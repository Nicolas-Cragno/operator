import navigationConfig from "./navigation.config";
export const visibleModules = (ids = []) => navigationConfig.filter((m) => ids.includes(m.id));
export const findModule = (id, ids = []) => visibleModules(ids).find((m) => m.id === id);
export const findChild = (module, childId) => module?.children?.find((child) => child.id === childId);
