// CANTAPP BASE es una plantilla, no Operator ni otra aplicación productiva.
// template: Home y módulos de demostración sin bootstrap remoto.
// app: requiere un appId registrado y endpoint /api/v1/apps/:appId/bootstrap.
const appConfig = {
  mode: "template",
  appId: "cantapp-base",
  environment: "development",
  version: "1.0.0",
  MANTENER_SESION: true,
  TIEMPO_INACTIVIDAD: 180,
  CERRAR_AL_CERRAR_VENTANA: false,
};
export default appConfig;
