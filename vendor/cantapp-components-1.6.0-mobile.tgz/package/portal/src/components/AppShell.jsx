import React, {useState} from "react";
import {Pressable, ScrollView, Text, View, useWindowDimensions} from "react-native";
import {useRouter, usePathname} from "expo-router";
import {useCantappTheme, Icon, Button} from "cantapp-components";
import {useApp} from "../contexts/AppContext";
import {useAuth} from "../contexts/AuthContext";
import AppLogo from "./AppLogo";
import ModuleIcon from "./ModuleIcon";

export default function AppShell({children}) {
  const t=useCantappTheme(); const {width}=useWindowDimensions(); const desktop=width>=768;
  const router=useRouter(); const pathname=usePathname();
  const {app,user,modules}=useApp(); const {signOut,markActivity}=useAuth();
  const [collapsed,setCollapsed]=useState(false); const [drawer,setDrawer]=useState(false);
  const navigate=route=>{markActivity();router.push(route);setDrawer(false);};
  const nav=[{id:"inicio",label:"Inicio",icon:"house",route:"/"},...modules.filter(m=>m.showIn?.includes("sidebar")||m.showIn?.includes("lowbar"))];
  const item=(m,compact=false)=>{
    const active=m.route==="/"?pathname==="/":pathname.startsWith(m.route);
    return <View key={m.id}><Pressable accessibilityRole="button" accessibilityLabel={m.label} onPress={()=>navigate(m.route)}
      style={{minHeight:44,paddingHorizontal:12,paddingVertical:10,flexDirection:"row",gap:12,alignItems:"center",borderRadius:4,backgroundColor:active?t.selection:"transparent"}}>
      <ModuleIcon name={m.icon} color={active?t.primary:t.muted} size={19}/>
      {!compact&&<Text style={{fontSize:14,color:active?t.primary:t.text,fontWeight:active?"700":"400",flex:1}}>{m.label}</Text>}
    </Pressable>{!compact&&m.children?.length>0&&pathname.startsWith(m.route)&&m.children.map(c=><Pressable key={c.id} onPress={()=>navigate(c.route)} style={{paddingVertical:10,paddingLeft:43,backgroundColor:pathname===c.route?t.selection:"transparent",borderRadius:4}}><Text style={{color:pathname===c.route?t.primary:t.text,fontSize:13}}>{c.label}</Text></Pressable>)}</View>;
  };
  const side=<ScrollView style={{flex:1}} contentContainerStyle={{padding:8,gap:4}}>{nav.map(m=>item(m,desktop&&collapsed))}</ScrollView>;
  const bottom=[{id:"inicio",label:"Inicio",icon:"house",route:"/"},...modules.filter(m=>m.showIn?.includes("lowbar"))].slice(0,4);
  return <View style={{flex:1,backgroundColor:t.background}}>
    <View style={{height:48,backgroundColor:t.primary,flexDirection:"row",alignItems:"center",paddingHorizontal:16,gap:12}}>
      {!desktop&&<Pressable accessibilityLabel="Abrir menú" onPress={()=>setDrawer(v=>!v)} style={{minWidth:44,minHeight:44,justifyContent:"center"}}><Icon name="menu" color="#fff" size={20}/></Pressable>}
      <AppLogo uri={app?.logo} name={app?.nombre} color="#fff" size={30}/>
      <Text numberOfLines={1} style={{fontSize:14,color:"#fff",fontWeight:"700",flex:1}}>{app?.nombre?.toUpperCase()||"CANTAPP BASE"}</Text>
      {desktop&&<Text numberOfLines={1} style={{fontSize:12,color:"#fff"}}>{user?.nombres||""}</Text>}
      <Pressable accessibilityRole="button" onPress={signOut} style={{minHeight:44,justifyContent:"center",paddingHorizontal:8}}><Text style={{color:"#fff",fontSize:13,fontWeight:"600"}}>Salir</Text></Pressable>
    </View>
    <View style={{flex:1,flexDirection:"row"}}>
      {desktop&&<View style={{width:collapsed?64:240,backgroundColor:t.surface,borderRightWidth:1,borderColor:t.border}}>
        <Pressable accessibilityRole="button" accessibilityLabel={collapsed?"Expandir menú":"Contraer menú" onPress={()=>setCollapsed(v=>!v)} style={{height:48,alignItems:"flex-end",justifyContent:"center",paddingHorizontal:16}}><Icon name={collapsed?"menu":"menu"} size={20} color={t.primary}/></Pressable>
        {side}
      </View>}
      <View style={{flex:1}}>{children}</View>
    </View>
    {!desktop&&<View style={{minHeight:60,backgroundColor:t.surface,borderTopWidth:1,borderColor:t.border,flexDirection:"row",justifyContent:"space-around",alignItems:"center"}}>
      {bottom.map(m=><Pressable key={m.id} accessibilityRole="button" onPress={()=>navigate(m.route)} style={{minWidth:56,minHeight:50,justifyContent:"center",alignItems:"center",gap:3}}><ModuleIcon name={m.icon} color={pathname===m.route?t.primary:t.muted} size={20}/><Text style={{fontSize:11,color:pathname===m.route?t.primary:t.muted}}>{m.label}</Text></Pressable>)}
      <Pressable accessibilityRole="button" onPress={()=>setDrawer(true)} style={{minWidth:56,minHeight:50,justifyContent:"center",alignItems:"center",gap:3}}><Icon name="menu" color={t.muted} size={20}/><Text style={{fontSize:11,color:t.muted}}>Más</Text></Pressable>
    </View>}
    {!desktop&&drawer&&<View style={{position:"absolute",top:48,bottom:60,left:0,right:0,flexDirection:"row",backgroundColor:"rgba(15,23,42,.35)"}}>
      <View style={{width:Math.min(width-48,300),backgroundColor:t.surface}}><View style={{padding:16,flexDirection:"row",justifyContent:"space-between",alignItems:"center"}}><Text style={{color:t.text,fontWeight:"700"}}>Navegación</Text><Pressable onPress={()=>setDrawer(false)}><Icon name="close" color={t.text}/></Pressable></View>{side}</View>
      <Pressable accessibilityLabel="Cerrar menú" onPress={()=>setDrawer(false)} style={{flex:1}}/>
    </View>}
  </View>;
}
