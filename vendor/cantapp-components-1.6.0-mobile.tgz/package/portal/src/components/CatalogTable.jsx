import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { DataTable, Modal, DateRangePicker, SearchInput, Button, useCantappTheme } from "cantapp-components";
import { apiGet, extractRows } from "../services/api.service";
import { recordDate, dateToIso } from "../utils/formatRecord";

const PAGE_SIZE = 50;
const dateKeys = new Set(["fecha", "fechaInicio", "fechaFin", "fechaSalida", "fechaEntrada", "fechaCreacion", "createdAt", "updatedAt"]);
const tableKeys = ["id", "interno", "nombre", "apellido", "nombres", "descripcion", "dominio", "patente", "estado", "tipo", "fecha", "cantidad", "unidad"];

export default function CatalogTable({ entry, group }) {
  const theme = useCantappTheme();
  const [variant, setVariant] = useState(entry.variants[0]);
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [search, setSearch] = useState("");
  const [draftSearch, setDraftSearch] = useState("");
  const [draftRange, setDraftRange] = useState({ from: "", to: "" });
  const [range, setRange] = useState({ from: "", to: "" });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    setRows([]);
    setPage(1);
    const path = group === "sucesos" && ["cargas", "movimientos"].includes(entry.id)
      ? `/${entry.id}/consulta` : variant.path;
    const limit = entry.id === "cargas" ? 25 : entry.id === "movimientos" ? 100 : 100;
    apiGet(path, { limit })
      .then(result => {
        if (!active) return;
        const items = extractRows(result);
        setRows(entry.id === "cargas" && variant.id !== "todos"
          ? items.filter(item => String(item.origen ?? item.tipo ?? item.fuente ?? "").toLowerCase() === variant.id)
          : items);
      })
      .catch(err => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [entry.id, group, variant, refresh]);

  const filtered = useMemo(() => rows.filter(row => {
    if (search && !JSON.stringify(row).toLowerCase().includes(search.toLowerCase())) return false;
    if (group !== "sucesos" || (!range.from && !range.to)) return true;
    const date = recordDate(row);
    if (!date) return false;
    const day = [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");
    const first = dateToIso(range.from), last = dateToIso(range.to);
    return (!first || day >= first) && (!last || day <= last);
  }), [rows, search, range, group]);

  const columns = useMemo(() => {
    const keys = [...new Set(filtered.slice(0, 25).flatMap(row => Object.keys(row || {})))];
    return [...tableKeys.filter(key => keys.includes(key)), ...keys.filter(key => !tableKeys.includes(key))]
      .slice(0, 7).map(key => ({ key, label: key, type: dateKeys.has(key) ? "datetime" : undefined }));
  }, [filtered]);

  const filters = group === "sucesos" ? <View style={{gap:6}}>
    <Text style={{color:theme.muted,fontSize:12}}>El rango se aplica a los registros recibidos; para consultar todo el historial se requieren filtros de fecha en la API.</Text>
    <DateRangePicker value={draftRange} onChange={setDraftRange}
      onApply={next=>{setRange(next);setPage(1);}}
      onClear={()=>{setDraftRange({from:"",to:""});setRange({from:"",to:""});setPage(1);}}/>
  </View>:null;

  return <View style={{ gap: 12 }}>
    <ScrollView horizontal contentContainerStyle={{ gap: 8 }}>
      {entry.variants.map(item => <Pressable key={item.id} accessibilityRole="button" accessibilityState={{ selected: variant.id === item.id }}
        onPress={() => { setVariant(item); setPage(1); }}
        style={{ padding: 11, borderRadius: 4, borderWidth: 1, borderColor: theme.border || theme.colorE, backgroundColor: variant.id === item.id ? theme.colorA : theme.surface }}>
        <Text style={{ color: variant.id === item.id ? "#fff" : theme.text }}>{item.label}</Text>
      </Pressable>)}
    </ScrollView>
    <View style={{flexDirection:"row",flexWrap:"wrap",alignItems:"flex-end",gap:8}}>
      <View style={{flex:1,minWidth:240}}><SearchInput label="Buscar en los resultados" value={draftSearch} onChange={setDraftSearch} onSearch={value=>{setSearch(value);setPage(1);}}/></View>
      <Button label="Actualizar" variant="outline" onPress={() => setRefresh(value => value + 1)} />
    </View>
    {filters}
    {!loading && !error && <Text style={{ color: theme.muted }}>{filtered.length} registros en la respuesta{group === "sucesos" ? " (la API puede limitar el total)" : ""}</Text>}
    <DataTable data={filtered} columns={columns} onRowPress={setSelected} loading={loading} error={error}
      onRetry={() => setRefresh(value => value + 1)} page={page} pageSize={PAGE_SIZE} onChangePage={setPage}
      emptyMessage="No hay registros para mostrar" />
    <Modal visible={selected !== null} onClose={() => setSelected(null)}
      title={`${entry.label || entry.id || "Ficha"}${selected?.id != null ? ` · ${selected.id}` : ""}`}
      data={selected || undefined} />
  </View>;
}
