const stamp = (value) => {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return undefined;
  const seconds = value.seconds ?? value._seconds;
  if (typeof seconds !== "number" || !Number.isFinite(seconds)) return undefined;
  // A Firestore timestamp is an object, never a string, number or boolean.
  return seconds;
};
export function formatRecordValue(value, depth = 0) {
 if (value == null) return "—";
 if (typeof value === "boolean") return value ? "Sí" : "No";
 const seconds = stamp(value);
 if (seconds !== undefined) return new Date(Number(seconds)*1000).toLocaleString("es-AR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"});
 if (Array.isArray(value)) return value.length ? value.map((v,i)=>`${i+1}. ${formatRecordValue(v,depth+1)}`).join("\n") : "Sin elementos";
 if (typeof value === "object") return Object.entries(value).map(([k,v])=>`${k}: ${formatRecordValue(v,depth+1)}`).join(depth ? " · " : "\n");
 return String(value);
}
export function recordDate(item) {
 for(const key of ["fecha","fechaHora","fechaEvento","createdAt","fechaCreacion","fechaInicio","fechaSalida","fechaEntrada"]){
  const value=item?.[key];if(!value)continue;
  const sec=stamp(value);if(sec!==undefined)return new Date(Number(sec)*1000);
  if(typeof value==="string") { const d=new Date(value);if(!isNaN(d.getTime()))return d; }
 }
 return null;
}
export function dateToIso(value) {
 if (!value) return "";
 const m=/^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value);
 if(!m)return "";
 const iso=`${m[3]}-${m[2]}-${m[1]}`;
 const d=new Date(`${iso}T12:00:00`);
 return !isNaN(d.getTime()) && d.getDate()===Number(m[1]) && d.getMonth()+1===Number(m[2]) ? iso : "";
}
