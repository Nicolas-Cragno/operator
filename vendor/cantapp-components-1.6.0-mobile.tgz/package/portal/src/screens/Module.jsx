import React from "react";
import {Pressable,ScrollView,Text,View} from "react-native";
import {useRouter} from "expo-router";
import {useCantappTheme, PageHeader} from "cantapp-components";
import {useApp} from "../contexts/AppContext";
import {useAuth} from "../contexts/AuthContext";
import {findChild} from "../config/modules";
import {findCatalog} from "../config/catalog";
import CatalogTable from "../components/CatalogTable";
export default function ModuleScreen({moduleId,childId}){
 const t=useCantappTheme();const {modules}=useApp();const {markActivity}=useAuth();const router=useRouter();const module=modules.find(x=>x.id===moduleId);
 if(!module)return <View style={{padding:25}}><Text style={{color:t.text}}>Módulo no habilitado.</Text></View>;
 const child=childId?findChild(module,childId):null;
 if(childId&&!child)return <Text style={{color:t.text}}>Sección no disponible.</Text>;
 const entry=child?findCatalog(moduleId,childId):null;
 return <ScrollView contentContainerStyle={{padding:24,gap:16}}><PageHeader title={child?.label||module.label} description={child ? `Recursos / ${module.label}` : "Seleccioná una sección"}/>{entry?<CatalogTable entry={entry} group={moduleId}/>:module.children?.map(c=><Pressable key={c.id} onPress={()=>{markActivity();router.push(c.route)}} style={{padding:18,borderWidth:1,borderColor:t.colorE,borderRadius:4,backgroundColor:t.colorD}}><Text style={{color:t.text,fontWeight:"bold"}}>{c.label}</Text></Pressable>)}</ScrollView>;
}
