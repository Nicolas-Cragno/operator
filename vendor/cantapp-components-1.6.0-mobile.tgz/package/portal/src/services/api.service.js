import { auth } from "../firebase/client";
const API_BASE = (process.env.EXPO_PUBLIC_API_URL || "").replace(/\/$/, "");
export async function apiGet(path, params = {}) {
 if (!API_BASE) throw new Error("Configurá EXPO_PUBLIC_API_URL en .env");
 const user = auth.currentUser;
 if (!user) throw new Error("Debés iniciar sesión para consultar datos");
 const token = await user.getIdToken();
 const qs = Object.entries(params).filter(([,v]) => v !== undefined && v !== null && v !== "").map(([k,v])=>`${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
 const url = `${API_BASE}${path}${qs ? `?${qs}` : ""}`;
 const response = await fetch(url, { headers: {Authorization:`Bearer ${token}`,Accept:"application/json"} });
 const body = await response.json().catch(()=>null);
 if (!response.ok) throw new Error(body?.error || body?.message || `HTTP ${response.status}`);
 return body;
}
export function extractRows(body) {
 if (Array.isArray(body)) return body;
 for (const key of ["data","items","resultados","registros","personas","tractores","furgones","vehiculos","empresas","stock","depositos","estaciones","ubicaciones","eventos","asignaciones","cargas","movimientos","viajes"]) {
  if (Array.isArray(body?.[key])) return body[key];
  if (body?.[key] && typeof body[key] === "object") for(const nested of ["items","data","resultados","registros"]) if(Array.isArray(body[key][nested])) return body[key][nested];
 }
 throw new Error("La API respondió, pero el formato del listado no fue reconocido");
}
