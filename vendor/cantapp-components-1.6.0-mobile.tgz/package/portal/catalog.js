import * as UI from '../src';
import Scenarios from './Scenarios';
import { v2Families, v2Names } from './v2Manifest';
const groups = {
 Botones: ['Button','BooleanButton','DoubleBooleanButton','CloseButton','DeleteButton','ImgButton','AlertButton','AccessButton','FullButton','TextButton','LogoButton','FloatButton'],
 Tarjetas: ['Card','BigCard','CardIcon','CardLogo','CardLogoButton','CardLabel','TripCard','OilCard','KpiCard'],
 Entradas: ['Input','InputBusqueda','Select','MultiSelect','Checkbox','TextArea','DateInput','DateTimeInput','DateRangeFilter','FileInput'],
 Ventanas: ['Modal','ModalColeccion','ModalOptions','ConfirmDialog','QROptionsModal'],
 Listados: ['Tabla','TablaFicha','TablaViajes','Pagination'],
 Formularios: ['FormStandard','FormPersona','FormTractor','FormFurgon','FormVehiculo','FormStock','FormAsignacion','FormProveedor','FormCliente','FormEventoPorteria','FormEventoPorteriaParticular','FormEventoPorteriaProveedor','FormField','FormSection','FormActions','ValidationMessage'],
 Fichas: ['Ficha','FichaChofer','FichaMovimiento','FichaRelaciones','DataValue','DateValue','DetailField','DetailSection'],
 Navegación: ['Header','Sidebar','LowBar','Dashboard','ChartPanel'],
 Funcionales: ['Banner','Clock','Loading','StatusBadge','Alert','EmptyState','ErrorState','LoadingState','ProgressIndicator','Skeleton'],
 Documentos: ['PDFViewer','PDFDocument','PDFViaje','ReporteAveria'],
};
// The names above are the explicit public component registry.
// eslint-disable-next-line import/namespace
export const catalog = [...Object.entries(v2Families),...Object.entries(groups).map(([group,names])=>['Compatibilidad / '+group,names.filter(name=>!v2Names.includes(name))]).filter(([,names])=>names.length)].map(([group, names]) => ({ group, items: names.map(name => ({ name, Component: UI[name] })) }));

catalog.unshift({group:'Ejemplos CANTAPP',items:[{name:'Escenarios',Component:Scenarios}]});
