import { fontFamily } from '../src/theme/typography';
import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable, useWindowDimensions, TextInput, Image, Platform } from 'react-native';
import { ThemeProvider, useCantappTheme, Button, Banner, Pagination, PDFDocument, createPDFViaje } from '../src';
import { catalog } from './catalog';
import { reference } from './reference';
import contracts from './contracts.json';
import V2Examples from './V2Examples';
import PorteriaExamples from './PorteriaExamples';
import { v2Names, v2Usage } from './v2Manifest';
const logo = require('../assets/logos/logo.png');
const hideScroll = Platform.OS === 'web' ? { scrollbarWidth: 'none', msOverflowStyle: 'none' } : {};
function IconAction({ symbol, onPress, color, label }) { return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: color, borderRadius: 4 }}><Text style={{ color, fontSize: 23, lineHeight: 28 }}>{symbol}</Text></Pressable>; }
function PreviewGrid({ t, name, children }) {
 const document = v2Names.includes(name) || name.startsWith('Form') || name.startsWith('Ficha') || name === 'Escenarios';
 const maxWidth = document ? 1200 : ['Tabla', 'TablaFicha', 'TablaViajes'].includes(name) ? 1200 : 480;
 return <View style={{ borderWidth: 1, borderColor: t.colorE, borderRadius: 4, overflow: 'hidden', position: 'relative' }}>
  <View style={{ padding: document ? 10 : 20, gap: 22, minHeight: document ? 540 : 220, justifyContent: 'center' }}>
   <Text style={{ color: t.colorA, fontWeight: '700', fontFamily }}>VISTA PREVIA INTERACTIVA</Text>
   <View style={{ width: document ? '90%' : '100%', maxWidth, alignSelf: 'center', minHeight: document ? 480 : undefined, justifyContent: 'center' }}><Playground key={name} name={name} Component={children} /></View>
  </View>
 </View>;
}
const descriptions = { CardLogo: 'Logo, título y acción de navegación.', BigCard: 'Logo y tres indicadores: empleados, tractores y furgones.', CardIcon: 'Acción con icono destacado y texto.', CardLogoButton: 'Logo con acciones Listado y Agregar.', TripCard: 'Tramo editable con fechas y ubicaciones.', OilCard: 'Carga de combustible con fecha, ubicación y litros.', LogoButton: 'Botón con logo configurable.', ImgButton: 'Botón con imagen y etiqueta.', Banner: 'Banner con imagen de fondo y superposición.', Button: 'Botón configurable con variantes, carga y deshabilitado.', CardLabel: 'Etiqueta de relación enriquecida; el backend proporciona label.', FormStandard: 'Formulario declarativo sin conexión a datos.', FichaRelaciones: 'Relaciones paginadas por la aplicación; recibe total y hasMore.', PDFViewer: 'Visor de páginas en imágenes. La generación de PDF está en PDFDocument.' };
function Playground({ name, Component }) {
 if(['FormEventoPorteria','FormEventoPorteriaParticular','FormEventoPorteriaProveedor','FloatButton','QROptionsModal'].includes(name))return <PorteriaExamples name={name} Component={Component}/>;
 if(v2Names.includes(name))return <V2Examples name={name} Component={Component}/>;
 return <LegacyPlayground name={name} Component={Component}/>;
}
function LegacyPlayground({ name, Component }) {
 const [demoFiles,setDemoFiles]=useState([]); const [demoState,setDemoState]=useState('normal'); const [date,setDate]=useState(''); const [value, setValue] = useState(false); const [doubleValue, setDoubleValue] = useState('A'); const [text, setText] = useState('Ejemplo de texto'); const [selected, setSelected] = useState('01'); const [page, setPage] = useState(1); const [open, setOpen] = useState(false); const [message, setMessage] = useState('');
 const isModal = ['Modal','ModalColeccion','ModalOptions','ConfirmDialog'].includes(name);
 const props = { onPress: () => setMessage('Acción de ejemplo ejecutada'), onChange: v => { if (typeof v === 'boolean' || Array.isArray(v)) setValue(v); else if (name === 'Select') setSelected(v); else setText(v); }, onSubmit: v => setMessage('Formulario validado: ' + Object.keys(v).length + ' campos'), onCancel: () => setMessage('Cancelado'), onEdit: () => setMessage('Editar ficha'), onClose: () => setOpen(false), onOpenRelation: r => setMessage('Abrir ' + r.id), onRowPress: r => setMessage('Registro ' + r.id), onChangePage: setPage, onLoadMore: () => setMessage('Solicitar siguiente página'), value: ['BooleanButton','DoubleBooleanButton','Checkbox'].includes(name) ? !!value : name === 'Select' ? selected : name === 'MultiSelect' ? (Array.isArray(value) ? value : []) : text };
 if (name === 'DateInput' || name === 'DateTimeInput') return <Component value={date} onChange={setDate}/>;
 if (name === 'DataValue') return <Component value={{nombre:'Claudia Medina',dni:'30123456',fecha:{seconds:1790000000,nanoseconds:0},permisos:['Ingreso','Egreso']}} />;
 if (name === 'DateValue') return <Component value={{seconds:1790000000,nanoseconds:0}} />;
 if (name === 'DateRangeFilter') return <View style={{gap:8}}><Component onApply={v=>setMessage(`Desde: ${v.from || '-'} / Hasta: ${v.to || '-'}`)} onClear={()=>setMessage('Filtro limpiado')}/><Text>{message}</Text></View>;
 if (name === 'FileInput') return <Component files={demoFiles} onChange={setDemoFiles} onPick={async()=>[{id:String(demoFiles.length),name:'Remito de ejemplo.pdf',mimeType:'application/pdf',progress:100}]} />;
 if (name === 'Ficha') return <><Button label="Abrir ficha" onPress={()=>setOpen(true)}/><Component visible={open} onClose={()=>setOpen(false)}/></>;
 if (name === 'DoubleBooleanButton') return <Component value={doubleValue} onChange={setDoubleValue} />;
 if (name === 'InputBusqueda') return <Component value={text} onChange={setText} onFieldsChange={fields => setMessage('Filtros: ' + (fields.length ? fields.join(', ') : 'todos'))} />;
 if (name === 'PDFViaje') { const data = {viaje:'001-00001412',chofer:'ARASCO, WALTER OMAR',tractor:'745',estado:'ACTIVO'}; return <View style={{gap:12}}><Component data={data} header="CANTAPP · EJEMPLO DE ENCABEZADO" /><PDFDocument document={createPDFViaje({data,header:'CANTAPP · EJEMPLO DE ENCABEZADO'})} title="Generar hoja de ruta" onError={error => setMessage(error.message)} />{message ? <Text style={{color:'#5c0624'}}>{message}</Text> : null}</View>; }
 if (name === 'PDFViewer') return <><Button label="Abrir visor" onPress={() => setOpen(true)} /><Component visible={open} onClose={() => setOpen(false)} pages={[require('../src/assets/images/reporteAveriaPlantilla.jpg')]} /></>;
 if (name === 'Pagination') return <Pagination page={page} totalPages={5} onChange={setPage} />;
 if (isModal) return <><Button label="Abrir modal" onPress={() => setOpen(true)} /><Component visible={open} title="Registro de ejemplo" data={name === "Modal" ? { id: "001-00001412", nombre: "ROSAS MEDINA, CLAUDIO HECTOR", estado: "ACTIVO" } : undefined} onClose={() => setOpen(false)} onConfirm={()=>{setOpen(false);setMessage("Acción confirmada");}} onOpenFicha={r => setMessage("Ficha " + r.id)} onOpenForm={type => setMessage("Formulario " + type)} /></>;
 if (['Header','Sidebar','LowBar'].includes(name)) return <View style={{ minHeight: name === 'Sidebar' ? 340 : 90 }}><Component onLogout={() => setMessage('Salir (demo)')} onSelect={item => setMessage('Navegación: ' + item.label)} onToggle={() => {}} /></View>;
 if (name === '__unused_layout__') return <Banner title="Layout" description="El portal usa Layout como base de navegación; se evita anidarlo en la vista previa." />;
 return <View style={{ gap: 12 }}>{['Button','Input','Select','MultiSelect','Checkbox','TextArea'].includes(name)&&<View style={{flexDirection:'row',flexWrap:'wrap',gap:6}}>{['normal','disabled','loading','error'].map(state=><Button key={state} label={state} variant={demoState===state?'primary':'outline'} onPress={()=>setDemoState(state)}/>)}</View>}<Component {...props} disabled={demoState==='disabled'} loading={demoState==='loading'} error={demoState==='error'?'Revisá el valor ingresado':undefined} />{message ? <Text style={{ color: '#1c9c75', fontSize: 12 }}>{message}</Text> : null}</View>;
}
function Content({ mode, setMode }) {
 const t = useCantappTheme(); const { width } = useWindowDimensions(); const compact = width < 768;
 const [chosen, setChosen] = useState('Button'); const [search, setSearch] = useState(''); const [showMenu, setShowMenu] = useState(false);
 const [expanded, setExpanded] = useState({'Ejemplos CANTAPP':true});
 const [copied,setCopied]=useState('');
 const item = catalog.flatMap(g => g.items).find(x => x.name === chosen) || catalog[0].items[0];
 const copyCode=async()=>{try{const code=`import { ${item.name} } from 'cantapp-components';\n\n${v2Usage[item.name] || reference[item.name]?.code || `<${item.name} />`}`;if(Platform.OS==='web'&&globalThis.navigator?.clipboard){await globalThis.navigator.clipboard.writeText(code);setCopied('Copiado');}else setCopied('Seleccioná el texto para copiarlo.');}catch{setCopied('Seleccioná el texto para copiarlo.');}};
 const filtered = useMemo(() => catalog.map(g => ({ ...g, items: g.items.filter(i => i.name.toLowerCase().includes(search.toLowerCase())) })).filter(g => g.items.length), [search]);
 const isExpanded = group => search.trim() ? true : expanded[group] === true;
 const sidebar = <ScrollView showsVerticalScrollIndicator={false} style={[hideScroll, { flex: 1, backgroundColor: t.colorD }]} contentContainerStyle={{ padding: 12, paddingBottom: 40, gap: 5 }}>
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 12 }}><Image source={logo} resizeMode="contain" style={{ width: 44, height: 44 }} /><Text style={{ color: t.colorA, fontWeight: 'bold', fontFamily, flex: 1 }}>COMPONENTS</Text>{compact && <IconAction symbol="×" label="Cerrar menú" color={t.colorA} onPress={() => setShowMenu(false)} />}</View>
  <TextInput value={search} onChangeText={setSearch} placeholder="Buscar componente" placeholderTextColor={t.muted} style={{ color: t.text, padding: 9, borderWidth: 1, borderColor: t.colorE, borderRadius: 4, marginBottom: 8 }} />
  {filtered.map(g => <View key={g.group} style={{ gap: 3 }}><Pressable accessibilityRole="button" onPress={() => setExpanded(v => ({ ...v, [g.group]: !isExpanded(g.group) }))} style={{ paddingVertical: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text style={{ color: t.colorA, fontWeight: '700', fontFamily }}>{g.group}</Text><Text style={{ color: t.colorA, fontSize: 16 }}>{isExpanded(g.group) ? '▾' : '▸'}</Text></Pressable>{isExpanded(g.group) && g.items.map(i => <Pressable key={i.name} onPress={() => { setChosen(i.name); setShowMenu(false); }} style={{ padding: 9, borderRadius: 4, backgroundColor: chosen === i.name ? t.colorE : 'transparent' }}><Text style={{ color: chosen === i.name ? t.colorA : t.text, fontFamily, fontSize: 12 }}>{i.name}</Text></Pressable>)}</View>)}
 </ScrollView>;
 return <View style={{ flex: 1, backgroundColor: t.background }}>
  <View style={{ backgroundColor: t.primary, borderBottomWidth: 1, borderColor: t.colorE, height:48, paddingHorizontal: 16, paddingVertical: 0, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
   <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, gap: 9 }}><Image source={logo} resizeMode="contain" style={{ width: 32, height: 32 }} /><View style={{ flexShrink: 1 }}><Text numberOfLines={1} style={{ color: '#ffffff', fontSize: compact ? 14 : 20, fontWeight: '800', fontFamily }}>CANTAPP / COMPONENTS</Text><Text style={{ color: '#e8edff', fontFamily, fontSize: 10 }}>Portal Expo · React Native · Web</Text></View></View>
   <View style={{ flexDirection: 'row', gap: 8 }}>{compact && <IconAction symbol="☰" label="Abrir menú" color="#ffffff" onPress={() => setShowMenu(true)} />}<IconAction symbol={mode === 'oscuro' ? '☀' : '☾'} label={mode === 'oscuro' ? 'Cambiar a tema claro' : 'Ver tema oscuro legado (pendiente de aprobación V2)'} color="#ffffff" onPress={() => setMode(mode === 'oscuro' ? 'claro' : 'oscuro')} /></View>
  </View>
  <View style={{ flex: 1, flexDirection: 'row' }}>
   {!compact && <View style={{ width: 240, borderRightWidth: 1, borderColor: t.colorE }}>{sidebar}</View>}
   <ScrollView showsVerticalScrollIndicator={false} style={[hideScroll, { flex: 1 }]} contentContainerStyle={{ padding: compact ? 16 : 30, gap: 22, maxWidth: 1000, width: '100%', alignSelf: 'center' }}>
    <View style={{ backgroundColor: t.colorD, borderWidth: 1, borderColor: t.colorE, borderLeftWidth: 4, borderLeftColor: t.colorA, padding: 20, borderRadius: 4, gap: 6 }}><Text style={{ color: t.colorA, fontFamily, fontWeight: '800', fontSize: 19 }}>{item.name}</Text><Text style={{ color: t.text, fontFamily, fontSize: 12 }}>{reference[item.name]?.description || descriptions[item.name] || 'Componente reutilizable. La aplicación proporciona datos y callbacks; la vista previa utiliza valores locales.'}</Text></View>
    <PreviewGrid t={{ ...t, mode }} name={item.name}>{item.Component}</PreviewGrid>
    <View style={{ gap: 8 }}><Text style={{ color: t.colorA, fontWeight: '700', fontFamily }}>IMPORTACIÓN</Text><Button label="Copiar ejemplo" variant="outline" onPress={copyCode}/>{copied?<Text accessibilityLiveRegion="polite" style={{color:t.muted}}>{copied}</Text>:null}<Text selectable style={{ color: t.text, backgroundColor: t.colorD, padding: 14, borderRadius: 4, fontFamily }}>{`import { ${item.name} } from 'cantapp-components';\n\n${v2Usage[item.name] || reference[item.name]?.code || `<${item.name} />`}`}</Text></View>
    <View style={{ gap: 8 }}><Text style={{ color: t.colorA, fontWeight: '700', fontFamily }}>CONTRATO GENERAL</Text><Text style={{ color: t.text, lineHeight: 23, fontFamily, fontSize: 12 }}>{reference[item.name]?.props || contracts[item.name] || 'Datos: data, fields, value, options. Acciones: onPress, onChange, onSubmit, onClose. Presentación: title, label, disabled, loading, variant, style. Cada componente usa solamente las propiedades correspondientes. No realiza consultas, autenticación ni persistencia.'}</Text></View>
    <Text style={{ color: t.muted, fontFamily, fontSize: 11 }}>CANTAPP DESIGN SYSTEM V2 · Catálogo local · React Native / Web</Text>
   </ScrollView>
   {compact && showMenu && <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, backgroundColor: t.colorD, zIndex: 10 }}>{sidebar}</View>}
  </View>
 </View>;
}
export default function Portal() { const [mode, setMode] = useState('claro'); return <ThemeProvider mode={mode}><Content mode={mode} setMode={setMode} /></ThemeProvider>; }
