import fs from 'node:fs';
import path from 'node:path';
import { parseSync } from '@babel/core';
const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
const rows = [];
const contracts = {};
for (const file of walk('src/components').filter(file => file.endsWith('.jsx'))) {
  const ast = parseSync(fs.readFileSync(file, 'utf8'), { filename: file, babelrc: false, configFile: false, parserOpts: { plugins: ['jsx'] } });
  const functions = ast.program.body.flatMap(node => node.type.startsWith('Export') ? [node.declaration].filter(Boolean) : [node]).filter(node => node.type === 'FunctionDeclaration');
  const props = functions.flatMap(node => node.params.filter(param => param.type === 'ObjectPattern').flatMap(param => param.properties.map(prop => prop.key?.name || `...${prop.argument?.name}`)));
  const imports = ast.program.body.filter(node => node.type === 'ImportDeclaration').map(node => node.source.value);
  for (const node of functions) if (node.id?.name) contracts[node.id.name] = node.params.filter(param => param.type === 'ObjectPattern').flatMap(param => param.properties.map(prop => prop.key?.name || `...${prop.argument?.name}`)).join(' · ');
  rows.push(`| ${path.basename(file, '.jsx')} | ${file.replaceAll('\\', '/')} | ${[...new Set(props)].join(', ')} | ${imports.some(value => value === 'react-native') ? 'React Native' : 'Composición'} |`);
}
fs.mkdirSync('docs', { recursive: true });
fs.writeFileSync('docs/COMPONENTES.md', `# Inventario completo de componentes\n\nGenerado con \`npm run audit:components\`. Enumera todos los archivos JSX, incluidos wrappers internos y no exportados. La plataforma indica las primitivas usadas, no una certificación de ejecución en dispositivo.\n\n| Componente | Archivo | Propiedades declaradas | Implementación |\n| --- | --- | --- | --- |\n${rows.join('\n')}\n`);
console.log(`Auditados ${rows.length} archivos de componentes.`);
const index = parseSync(fs.readFileSync('src/index.js', 'utf8'), { babelrc: false, configFile: false }).program.body;
for (const node of index.filter(node => node.type === 'ExportNamedDeclaration' && node.source)) {
  for (const specifier of node.specifiers) {
    if (specifier.local?.name !== 'default') continue;
    const file = path.resolve('src', `${node.source.value}.jsx`);
    if (!fs.existsSync(file)) continue;
    const component = parseSync(fs.readFileSync(file, 'utf8'), { filename: file, babelrc: false, configFile: false, parserOpts: { plugins: ['jsx'] } }).program.body.find(node => node.type === 'ExportDefaultDeclaration')?.declaration;
    const name = component?.id?.name || component?.name;
    if (contracts[name]) contracts[specifier.exported.name] = contracts[name];
  }
}
fs.writeFileSync('portal/contracts.json', JSON.stringify(contracts, null, 2) + '\n');
