import fs from 'node:fs';
import path from 'node:path';
const source = fs.readFileSync('src/index.js','utf8');
const matches = [...source.matchAll(/from '\.\/components\/([^']+)'/g)];
for (const match of matches) { const base = path.join('src/components', match[1]); if (!fs.existsSync(base + '.jsx') && !fs.existsSync(base + '.js')) throw Error('Missing component: ' + base); }
console.log(`Verificadas ${matches.length} exportaciones de componentes.`);
const roots = ['src', 'portal'];
const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
let checked = 0;
for (const file of roots.flatMap(walk).filter(file => /\.[jt]sx?$/.test(file))) {
  for (const match of fs.readFileSync(file, 'utf8').matchAll(/(?:from\s*|require\()\s*['"](\.[^'"]+)['"]/g)) {
    const base = path.resolve(path.dirname(file), match[1]);
    if (![base, ...['.js', '.jsx', '.web.js', '/index.js', '/index.jsx'].map(ext => base + ext)].some(candidate => fs.existsSync(candidate))) throw Error(`Missing import: ${file} -> ${match[1]}`);
    checked++;
  }
}
console.log(`Verificadas ${checked} referencias locales de librería y portal.`);
