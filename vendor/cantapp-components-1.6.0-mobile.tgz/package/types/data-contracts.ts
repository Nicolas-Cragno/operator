// Compile-time contracts for the pure formatting API, alongside runtime tests.
import { formatDate, formatValue, toDate, validateDateRange } from '../src/utils/data';
const text: string = formatValue({ id: '30123456', enabled: true });
const date: Date | null = toDate({ seconds: 1790000000, nanoseconds: 0 });
const label: string = formatDate(date, { withTime: true, timeZone: 'America/Argentina/Buenos_Aires' });
const error: string = validateDateRange('01/10/2026', '29/10/2026');
export { text, date, label, error };
