# V1.5 — correcciones del portal

- Categorías del catálogo colapsadas inicialmente.
- DoubleBooleanButton en el portal con valor controlado A/B.
- InputBusqueda sin filtros seleccionados se interpreta como búsqueda sobre todos los campos.
- Tablas con superficie blanca y texto oscuro.
- Vista previa de formularios y fichas ampliada al 90% del ancho del contenedor, con altura mínima de 480 px; en la app consumidora su tamaño depende del contenedor padre.
- Componentes de navegación reciben callbacks de demostración para evitar acciones no conectadas.
- Banner muestra imagen de ejemplo con mayor opacidad.
- Plantillas gráficas de Nexar incluidas como recursos locales para futuras composiciones PDF. No hay impresión nativa implementada.
- PDFViaje acepta header y template; por defecto muestra documento blanco.

No se han ejecutado pruebas de compilación Android. La impresión PDF nativa/web requiere un servicio específico de plataforma.
