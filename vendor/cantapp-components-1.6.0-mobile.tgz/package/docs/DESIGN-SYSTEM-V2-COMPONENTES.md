# Componentes V2: matriz, propiedades y ejemplos

Generado con `npm run docs:v2`. Son los 63 nombres efectivamente enumerados en el pedido. Todos se exportan desde src/index.js y tienen ejemplo interactivo en el portal. Los archivos web/native de un mismo control son adaptaciones de plataforma, no componentes duplicados.

| Familia | Componente | Implementación |
| --- | --- | --- |
| 01 · Botones y acciones | Button | Implementado |
| 01 · Botones y acciones | IconButton | Reutiliza Button |
| 01 · Botones y acciones | BooleanButton | Reutiliza Button |
| 01 · Botones y acciones | DeleteButton | Implementado |
| 01 · Botones y acciones | CloseButton | Implementado |
| 01 · Botones y acciones | AccessButton | Reutiliza Button |
| 01 · Botones y acciones | SplitButton | Implementado |
| 01 · Botones y acciones | FloatingActionButton | Reutiliza Button |
| 02 · Campos y formularios | TextInput | Reutiliza Input |
| 02 · Campos y formularios | NumberInput | Implementado |
| 02 · Campos y formularios | Select | Implementado |
| 02 · Campos y formularios | MultiSelect | Implementado |
| 02 · Campos y formularios | DatePicker | Reutiliza DateInput |
| 02 · Campos y formularios | DateRangePicker | Reutiliza DateRangeFilter |
| 02 · Campos y formularios | Checkbox | Implementado |
| 02 · Campos y formularios | RadioGroup | Implementado |
| 02 · Campos y formularios | Switch | Implementado |
| 02 · Campos y formularios | Textarea | Reutiliza Input |
| 02 · Campos y formularios | FileUpload | Reutiliza FileInput |
| 02 · Campos y formularios | ImageUpload | Reutiliza FileInput |
| 02 · Campos y formularios | SearchInput | Implementado |
| 03 · Datos y listados | DataTable | Reutiliza Tabla |
| 03 · Datos y listados | DataCard | Implementado |
| 03 · Datos y listados | Pagination | Implementado |
| 03 · Datos y listados | StatusBadge | Implementado |
| 03 · Datos y listados | SortControl | Implementado |
| 03 · Datos y listados | FilterPanel | Implementado |
| 03 · Datos y listados | EmptyState | Implementado |
| 03 · Datos y listados | Skeleton | Implementado |
| 03 · Datos y listados | KeyValueList | Implementado |
| 04 · Modales y notificaciones | Modal | Implementado |
| 04 · Modales y notificaciones | ConfirmDialog | Implementado |
| 04 · Modales y notificaciones | AlertDialog | Implementado |
| 04 · Modales y notificaciones | Toast | Implementado |
| 04 · Modales y notificaciones | Tooltip | Implementado |
| 04 · Modales y notificaciones | Popover | Implementado |
| 04 · Modales y notificaciones | LoadingOverlay | Implementado |
| 04 · Modales y notificaciones | ProgressBar | Reutiliza ProgressIndicator |
| 05 · Navegación y estructura | Header | Implementado |
| 05 · Navegación y estructura | Sidebar | Implementado |
| 05 · Navegación y estructura | BottomNavigation | Reutiliza LowBar |
| 05 · Navegación y estructura | Breadcrumbs | Implementado |
| 05 · Navegación y estructura | Tabs | Implementado |
| 05 · Navegación y estructura | Accordion | Implementado |
| 05 · Navegación y estructura | PageHeader | Implementado |
| 05 · Navegación y estructura | SectionHeader | Implementado |
| 05 · Navegación y estructura | Divider | Implementado |
| 06 · Componentes operativos | QRViewer | Implementado |
| 06 · Componentes operativos | QRScanner | Implementado |
| 06 · Componentes operativos | AttachmentViewer | Implementado |
| 06 · Componentes operativos | DocumentPreview | Implementado |
| 06 · Componentes operativos | PhotoCapture | Implementado |
| 06 · Componentes operativos | Timeline | Implementado |
| 06 · Componentes operativos | AuditHistory | Implementado |
| 06 · Componentes operativos | VehicleSelector | Reutiliza ResourceSelector |
| 06 · Componentes operativos | PersonSelector | Reutiliza ResourceSelector |
| 06 · Componentes operativos | StockSelector | Reutiliza ResourceSelector |
| 07 · Indicadores y estadísticas | StatCard | Implementado |
| 07 · Indicadores y estadísticas | KpiCard | Implementado |
| 07 · Indicadores y estadísticas | ChartContainer | Implementado |
| 07 · Indicadores y estadísticas | ProgressIndicator | Implementado |
| 07 · Indicadores y estadísticas | StatusIndicator | Implementado |
| 07 · Indicadores y estadísticas | SummaryPanel | Implementado |

## 01 · Botones y acciones

### Button

Props: label · text · onPress · disabled · loading · variant · icon · iconOnly · style · children · accessibilityLabel · accessibilityState · accessibilityRole · onError · ...props

```jsx
import { Button } from 'cantapp-components';
<Button label="Guardar" icon="check" onPress={guardar} loading={guardando} />
```

### IconButton

Props: label · icon · ...props · label · text · onPress · disabled · loading · variant · icon · iconOnly · style · children · accessibilityLabel · accessibilityState · accessibilityRole · onError · ...props

```jsx
import { IconButton } from 'cantapp-components';
<IconButton label="Agregar registro" icon="plus" onPress={agregar} />
```

### BooleanButton

Props: value · onChange · trueLabel · falseLabel · ...props · label · text · onPress · disabled · loading · variant · icon · iconOnly · style · children · accessibilityLabel · accessibilityState · accessibilityRole · onError · ...props

```jsx
import { BooleanButton } from 'cantapp-components';
<BooleanButton value={activo} onChange={setActivo} />
```

### DeleteButton

Props: onPress · disabled · size · color · confirmationTitle · confirmationDescription · ...props

```jsx
import { DeleteButton } from 'cantapp-components';
<DeleteButton onPress={eliminar} /> // Solicita confirmación antes de ejecutar
```

### CloseButton

Props: onPress · disabled · size · color

```jsx
import { CloseButton } from 'cantapp-components';
<CloseButton onPress={cerrar} />
```

### AccessButton

Props: label · onPress · allowed · disabled · icon · ...props · label · text · onPress · disabled · loading · variant · icon · iconOnly · style · children · accessibilityLabel · accessibilityState · accessibilityRole · onError · ...props

```jsx
import { AccessButton } from 'cantapp-components';
<AccessButton label="Abrir recurso" allowed={puedeAcceder} onPress={abrir} />
```

### SplitButton

Props: label · onPress · options · disabled · loading

```jsx
import { SplitButton } from 'cantapp-components';
<SplitButton label="Guardar" onPress={guardar} options={[{label:"Guardar copia",onPress:guardarCopia}]} />
```

### FloatingActionButton

Props: label · icon · onPress · showOnWeb · ...props · label · text · onPress · disabled · loading · variant · icon · iconOnly · style · children · accessibilityLabel · accessibilityState · accessibilityRole · onError · ...props

```jsx
import { FloatingActionButton } from 'cantapp-components';
<FloatingActionButton label="Agregar" icon="plus" onPress={agregar} />
```

## 02 · Campos y formularios

### TextInput

Props: label · value · onChange · onChangeText · placeholder · disabled · multiline · error · style · inputStyle · keyboardType · required · onBlur · onFocus · validate · grow · ...props · label · value · onChange · onChangeText · placeholder · disabled · multiline · error · style · inputStyle · keyboardType · required · onBlur · onFocus · validate · grow · ...props

```jsx
import { TextInput } from 'cantapp-components';
<TextInput label="Nombre" value={nombre} onChange={setNombre} required />
```

### NumberInput

Props: value · onChange · step · min · max · steppers · disabled · ...props

```jsx
import { NumberInput } from 'cantapp-components';
<NumberInput label="Cantidad" value={cantidad} onChange={setCantidad} steppers />
```

### Select

Props: label · value · onChange · options · disabled · searchable · placeholder · required · error · onBlur

```jsx
import { Select } from 'cantapp-components';
<Select label="Recurso" options={opciones} value={id} onChange={setId} searchable />
```

### MultiSelect

Props: label · value · onChange · options · disabled · required · error

```jsx
import { MultiSelect } from 'cantapp-components';
<MultiSelect label="Opciones" options={opciones} value={ids} onChange={setIds} />
```

### DatePicker

Props: label · value · onChange · placeholder · disabled · required · error · manual · onBlur · label · value · onChange · placeholder · disabled · required · error · manual · onBlur

```jsx
import { DatePicker } from 'cantapp-components';
<DatePicker label="Fecha" value={fecha} onChange={setFecha} />
```

### DateRangePicker

Props: value · onChange · onApply · onClear · disabled · loading · value · onChange · onApply · onClear · disabled · loading

```jsx
import { DateRangePicker } from 'cantapp-components';
<DateRangePicker value={rango} onChange={setRango} onApply={aplicar} />
```

### Checkbox

Props: label · value · onChange · disabled · required

```jsx
import { Checkbox } from 'cantapp-components';
<Checkbox label="Confirmado" value={confirmado} onChange={setConfirmado} />
```

### RadioGroup

Props: label · value · onChange · options · disabled · required

```jsx
import { RadioGroup } from 'cantapp-components';
<RadioGroup label="Tipo" options={opciones} value={tipo} onChange={setTipo} />
```

### Switch

Props: label · value · onChange · disabled

```jsx
import { Switch } from 'cantapp-components';
<Switch label="Activo" value={activo} onChange={setActivo} />
```

### Textarea

Props: label · value · onChange · onChangeText · placeholder · disabled · multiline · error · style · inputStyle · keyboardType · required · onBlur · onFocus · validate · grow · ...props

```jsx
import { Textarea } from 'cantapp-components';
<Textarea label="Observaciones" value={texto} onChange={setTexto} grow />
```

### FileUpload

Props: files · onChange · onPick · disabled · loading · ...props · label · files · onPick · onCapture · onChange · onRemove · onError · disabled · loading · required · error

```jsx
import { FileUpload } from 'cantapp-components';
<FileUpload files={archivos} onChange={setArchivos} onError={mostrarError} />
```

### ImageUpload

Props: onPick · onCapture · ...props · label · files · onPick · onCapture · onChange · onRemove · onError · disabled · loading · required · error

```jsx
import { ImageUpload } from 'cantapp-components';
<ImageUpload files={imagenes} onChange={setImagenes} />
```

### SearchInput

Props: value · onChange · onSearch · label · placeholder · disabled · loading

```jsx
import { SearchInput } from 'cantapp-components';
<SearchInput value={busqueda} onChange={setBusqueda} onSearch={buscar} />
```

## 03 · Datos y listados

### DataTable

Props: data · pageSize · ...props · data · columns · onRowPress · loading · error · onRetry · emptyMessage · searchable · search · onSearchChange · filters · sort · onSortChange · page · pageSize · total · hasMore · onChangePage · serverSide · selectedKeys · onSelectionChange · rowKey · renderActions · cellStyle · height · v2

```jsx
import { DataTable } from 'cantapp-components';
<DataTable data={pagina} columns={columnas} serverSide page={page} total={total} onChangePage={setPage} onRowPress={setRegistro} />
```

### DataCard

Props: title · identifier · status · details · onPress

```jsx
import { DataCard } from 'cantapp-components';
<DataCard title={registro.nombre} identifier={registro.id} status={registro.estado} onPress={abrir} />
```

### Pagination

Props: page · totalPages · hasMore · loading · onChange

```jsx
import { Pagination } from 'cantapp-components';
<Pagination page={page} totalPages={totalPages} onChange={setPage} />
```

### StatusBadge

Props: label · tone

```jsx
import { StatusBadge } from 'cantapp-components';
<StatusBadge label="Activo" tone="success" />
```

### SortControl

Props: label · value · onChange · options

```jsx
import { SortControl } from 'cantapp-components';
<SortControl value={sort} options={columnas} onChange={setSort} />
```

### FilterPanel

Props: fields · value · onChange · onApply · onClear · activeFilters · onRemoveFilter · children · dates · loading

```jsx
import { FilterPanel } from 'cantapp-components';
<FilterPanel value={filtros} onChange={setFiltros} onApply={aplicar} onClear={limpiar} />
```

### EmptyState

Props: title · description · children · style

```jsx
import { EmptyState } from 'cantapp-components';
<EmptyState title="No hay registros" description="Modificá los filtros." />
```

### Skeleton

Props: height · width

```jsx
import { Skeleton } from 'cantapp-components';
<Skeleton height={180} />
```

### KeyValueList

Props: data · fields

```jsx
import { KeyValueList } from 'cantapp-components';
<KeyValueList data={registro} fields={campos} />
```

## 04 · Modales y notificaciones

### Modal

Props: visible · onClose · title · children · ...props

```jsx
import { Modal } from 'cantapp-components';
<Modal visible={abierto} title="Detalle" onClose={cerrar} dirty={hayCambios}>{contenido}</Modal>
```

### ConfirmDialog

Props: title · description · onConfirm · onClose · loading · danger · confirmLabel · children · ...props

```jsx
import { ConfirmDialog } from 'cantapp-components';
<ConfirmDialog visible={confirmando} title="Eliminar" onConfirm={eliminar} onClose={cerrar} danger />
```

### AlertDialog

Props: visible · title · description · onClose · children

```jsx
import { AlertDialog } from 'cantapp-components';
<AlertDialog visible={abierto} title="Información" description={mensaje} onClose={cerrar} />
```

### Toast

Props: visible · title · description · tone · onClose · duration

```jsx
import { Toast, useToast } from 'cantapp-components';
const toast = useToast(); // Dentro de DesignSystemProvider
toast.show({title:"Operación completada",tone:"success"});
```

### Tooltip

Props: text · children

```jsx
import { Tooltip } from 'cantapp-components';
<Tooltip text="Información contextual"><Icon name="info" /></Tooltip>
```

### Popover

Props: open · onOpenChange · trigger · children · label

```jsx
import { Popover } from 'cantapp-components';
<Popover open={abierto} onOpenChange={setAbierto} trigger={boton}>{opciones}</Popover>
```

### LoadingOverlay

Props: visible · label · children

```jsx
import { LoadingOverlay } from 'cantapp-components';
<LoadingOverlay visible={cargando}>{contenido}</LoadingOverlay>
```

### ProgressBar

Props: value · label · indeterminate

```jsx
import { ProgressBar } from 'cantapp-components';
<ProgressBar value={progreso} label="Carga" />
```

## 05 · Navegación y estructura

### Header

Props: title · moduleName · user · onLogout · onUser · onNotifications · onMenu · appLogo

```jsx
import { Header } from 'cantapp-components';
<Header moduleName="Operator" appLogo={logoOficial} onUser={abrirUsuario} />
```

### Sidebar

Props: items · groups · selected · onSelect · appLogo · expanded · onToggle · preferences · preferenceKey · onPreferenceError

```jsx
import { Sidebar } from 'cantapp-components';
<Sidebar groups={grupos} selected={modulo} onSelect={navegar} preferences={preferencias} appLogo={logoOficial} />
```

### BottomNavigation

Props: items · selected · onSelect · appLogo · mobileOnly

```jsx
import { BottomNavigation } from 'cantapp-components';
<BottomNavigation items={accesos} selected={modulo} onSelect={navegar} />
```

### Breadcrumbs

Props: items · onSelect

```jsx
import { Breadcrumbs } from 'cantapp-components';
<Breadcrumbs items={ruta} onSelect={navegar} />
```

### Tabs

Props: items · value · selected · onChange · onSelect

```jsx
import { Tabs } from 'cantapp-components';
<Tabs items={pestanas} value={pestana} onChange={setPestana} />
```

### Accordion

Props: items · openKeys · onChange

```jsx
import { Accordion } from 'cantapp-components';
<Accordion items={secciones} />
```

### PageHeader

Props: title · description · actions

```jsx
import { PageHeader } from 'cantapp-components';
<PageHeader title="Recursos" description="Administración" actions={acciones} />
```

### SectionHeader

Props: title · actions

```jsx
import { SectionHeader } from 'cantapp-components';
<SectionHeader title="Datos generales" />
```

### Divider

Props: Sin propiedades obligatorias; ver ejemplo y API compartida.

```jsx
import { Divider } from 'cantapp-components';
<Divider />
```

## 06 · Componentes operativos

### QRViewer

Props: value · identifier · onShare · size

```jsx
import { QRViewer } from 'cantapp-components';
<QRViewer value={identificador} identifier={identificador} onShare={compartirQR} />
```

### QRScanner

Props: onScan · onError · disabled

```jsx
import { QRScanner } from 'cantapp-components';
<QRScanner onScan={procesarResultado} onError={mostrarError} />
```

### AttachmentViewer

Props: attachments · selected · onSelect · onShare

```jsx
import { AttachmentViewer } from 'cantapp-components';
<AttachmentViewer attachments={archivos} selected={indice} onSelect={setIndice} />
```

### DocumentPreview

Props: file · onOpen · onShare

```jsx
import { DocumentPreview } from 'cantapp-components';
<DocumentPreview file={archivo} onShare={compartir} />
```

### PhotoCapture

Props: onUse · onError · onCapture · onGallery · disabled

```jsx
import { PhotoCapture } from 'cantapp-components';
<PhotoCapture onUse={usarFoto} onError={mostrarError} />
```

### Timeline

Props: items · dateKey · renderItem

```jsx
import { Timeline } from 'cantapp-components';
<Timeline items={eventos} dateKey="date" />
```

### AuditHistory

Props: items

```jsx
import { AuditHistory } from 'cantapp-components';
<AuditHistory items={auditoria} />
```

### VehicleSelector

Props: visible · onClose · title · items · data · multiple · value · onSelectionChange · onSelect · onSearch · loading · error · stock · hasMore · onLoadMore

```jsx
import { VehicleSelector } from 'cantapp-components';
<VehicleSelector visible={abierto} data={vehiculos} onSearch={buscar} onSelect={seleccionar} onClose={cerrar} />
```

### PersonSelector

Props: visible · onClose · title · items · data · multiple · value · onSelectionChange · onSelect · onSearch · loading · error · stock · hasMore · onLoadMore

```jsx
import { PersonSelector } from 'cantapp-components';
<PersonSelector visible={abierto} data={personas} onSelect={seleccionar} onClose={cerrar} />
```

### StockSelector

Props: visible · onClose · title · items · data · multiple · value · onSelectionChange · onSelect · onSearch · loading · error · stock · hasMore · onLoadMore

```jsx
import { StockSelector } from 'cantapp-components';
<StockSelector visible={abierto} data={stock} onSelect={seleccionar} onClose={cerrar} />
```

## 07 · Indicadores y estadísticas

### StatCard

Props: title · value · icon · ...props

```jsx
import { StatCard } from 'cantapp-components';
<StatCard title="Recursos" value={total} icon="info" />
```

### KpiCard

Props: title · value · change · changeLabel · children · ...props

```jsx
import { KpiCard } from 'cantapp-components';
<KpiCard title="Viajes" value={total} change={variacion} />
```

### ChartContainer

Props: title · type · data · legend · onSelect · height

```jsx
import { ChartContainer } from 'cantapp-components';
<ChartContainer title="Viajes por período" type="bar" data={serie} />
```

### ProgressIndicator

Props: value · label · indeterminate

```jsx
import { ProgressIndicator } from 'cantapp-components';
<ProgressIndicator value={progreso} label="Completado" />
```

### StatusIndicator

Props: label · tone · icon

```jsx
import { StatusIndicator } from 'cantapp-components';
<StatusIndicator label="Confirmado" tone="success" icon="check" />
```

### SummaryPanel

Props: items · children

```jsx
import { SummaryPanel } from 'cantapp-components';
<SummaryPanel items={metricas} />
```

## Contratos comunes

Los callbacks no acceden al backend desde la librería. Las operaciones asíncronas de Button se bloquean hasta resolver y presentan errores accesibles. Selección, búsqueda, ordenamiento y páginas controladas pertenecen a la aplicación.

Modal: visible/onClose, dirty para cambios sin guardar y footer para acciones fijas. Los modales anidados reemplazan temporalmente el contenido conservando el formulario montado.

FileUpload/ImageUpload: files es controlado; onChange recibe la lista propuesta. Seleccionar, capturar o quitar no sube ni elimina archivos del servidor. Se pueden inyectar onPick y onCapture para usar adaptadores de la app.

ResourceSelector: value/onSelectionChange contienen claves string; multiple=false por defecto. onSearch solicita resultados a la app solo al confirmar la búsqueda. onSelect recibe un registro o un array si multiple=true. StockSelector agrega quantity numérico, existencia y unidad; no descuenta inventario.

ChartContainer: type admite line/bar/area/pie/donut. data=[{label,value,color?}], legend opcional, onSelect(item,index). Tooltips de la biblioteca y leyenda interactiva. La variación de KpiCard indica dirección matemática; no evalúa conveniencia empresarial.

Sidebar: preferences es opcional y tiene get(key)/set(key,value), síncronos o asíncronos. La app adapta su persistencia existente; sin adaptador el estado es local.
