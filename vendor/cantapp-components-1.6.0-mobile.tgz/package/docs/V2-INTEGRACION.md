# Integración de Design System V2

## Raíz de cada aplicación Expo 54

Conservar Expo Router, autenticación y permisos actuales de CANTAPP BASE. Envolver el contenido de su layout existente, sin crear otra navegación:

```jsx
import { Stack, router } from 'expo-router';
import { DesignSystemProvider } from 'cantapp-components';

export default function RootLayout() {
  return <DesignSystemProvider mode="claro">
    <Stack />
  </DesignSystemProvider>;
}
```

`DesignSystemProvider` compone ThemeProvider, áreas seguras y ToastProvider. `ThemeProvider` anterior continúa disponible y ahora carga Inter y agrega un proveedor de áreas seguras si no existe. No elimina los proveedores de autenticación, preferencias o datos de la aplicación.

El default es Light V2. `mode="oscuro"` mantiene la paleta previa como compatibilidad, pendiente de aprobación visual V2. No usarla como especificación oscura definitiva.

## Branding oficial

Los recursos permanecen en BASE. No hay imports a rutas externas dentro de esta librería:

```jsx
const logo = require('../assets/branding/cantapp-logo.png'); // ajustar a la ruta del consumidor
<Header moduleName="Operator" appLogo={logo} onUser={abrirUsuario} />
<Sidebar appLogo={logo} groups={gruposAutorizados} onSelect={item => router.push(item.href)} />
```

Header y Sidebar admiten source de imagen, URI SVG o un elemento React SVG ya configurado por la app. Los PNG de instalación permanecen donde los declara app.json. Para SVG local que requiera transformación, usar la configuración existente del consumidor o pasar un elemento; no hace falta cambiar el empaquetado de sus assets PNG.

## Navegación y preferencias

Los grupos y accesos se construyen **después** de aplicar los permisos existentes de la aplicación. La librería no consulta permisos. Los callbacks de Header, Sidebar, BottomNavigation, Breadcrumbs y Tabs no navegan por su cuenta.

```jsx
const preferencias = {
  get: async key => {
    const raw = await almacenamientoActual.getItem(key);
    return raw === null ? undefined : JSON.parse(raw);
  },
  set: (key, value) => almacenamientoActual.setItem(key, JSON.stringify(value)),
};
<Sidebar preferences={preferencias} preferenceKey="operator.sidebar.expanded"
  groups={gruposAutorizados} selected={moduloActual} onSelect={seleccionarModulo} />
```

Memoizar el adaptador para que no se vuelva a leer en cada render. Sin adaptador, Sidebar funciona con estado local. BottomNavigation aparece debajo de 768 px y en Mobile: toma cuatro accesos principales y presenta «Más» para los restantes en un drawer. Pasar todas las opciones autorizadas, no solamente las cuatro primeras.

## Listados y fichas

```jsx
<DataTable data={pagina} columns={columnas} serverSide
  page={page} pageSize={50} total={total}
  search={busquedaAplicada} onSearchChange={buscar}
  sort={sort} onSortChange={ordenar}
  onChangePage={setPage} loading={loading} error={error}
  onRowPress={setRegistro} />
<Ficha visible={!!registro} data={registro || {}} onClose={() => setRegistro(null)} />
```

Si el servidor usa cursores sin total, proporcionar hasMore. Cambiar búsqueda, filtros u ordenamiento debe reiniciar la consulta a su primera página en el controlador de la app. No hacer dos consultas desde callbacks redundantes. DataTable no vuelve a filtrar, ordenar ni cortar una página recibida con serverSide.

El formulario/ficha se muestra sobre el listado sin desmontarlo. El motor mantiene el estado local; cuando la app controla filtros, búsqueda, sort y page, conservarlos al cerrar. `Tabla` conserva su contrato y su tamaño de página anterior de 25; `DataTable` usa defaults V2 de 50, fila pulsable, sin acciones secundarias y tarjetas limitadas en Mobile.

## Formularios y un único diálogo

```jsx
<Modal visible={editando} title="Editar registro" onClose={cerrar}>
  <FormStandard data={registro} sections={secciones}
    onSubmit={guardarConLaAPIExistente} onCancel={cerrar} loading={guardando} />
</Modal>
```

FormStandard valida al perder foco y al intentar guardar. Guardar solicita confirmación y entrega onSubmit una vez confirmado. El footer se registra en el modal, fuera del scroll central. FormActions también confirma; no envolver su callback en otra ConfirmDialog de la app salvo que tenga una necesidad distinta. Un Button genérico no infiere operaciones por su etiqueta: si la app guarda fuera de formularios, debe usar ConfirmDialog/FormActions.

DeleteButton conserva `onPress`, pero lo ejecuta después de confirmar. No volver a eliminar el registro en el callback que abre el diálogo. Los callbacks asíncronos deben devolver su Promise para bloquear pulsaciones repetidas y presentar errores. Si falla el guardado, no limpiar el formulario desde la aplicación hasta resolver el error.

Los selectores y confirmaciones anidados reemplazan temporalmente el contenido del mismo contenedor; el formulario permanece montado. Usar `dirty` en Modal cuando los cambios se administran fuera de FormStandard. Backdrop no cierra si hay cambios; X/Atrás/Escape ofrecen descartarlos. Los diálogos independientes se coordinan para tener un solo modal nativo visible.

## Cámara, QR y archivos

Los módulos se instalaron con expo install para SDK 54. En el consumidor, verificar las dependencias y configurar los plugins necesarios para su build:

```json
{
  "expo": {
    "plugins": [
      "expo-font",
      ["expo-camera", {"cameraPermission":"Escanear códigos QR", "recordAudioAndroid":false, "microphonePermission":false}],
      ["expo-image-picker", {"photosPermission":"Adjuntar imágenes", "cameraPermission":"Capturar comprobantes", "microphonePermission":false}]
    ]
  }
}
```

No alterar reglas de acceso empresarial. Estos son permisos del dispositivo para funcionalidades solicitadas. No se solicita micrófono. Los cambios de configuración nativa necesitan una nueva build de desarrollo/EAS; no se envían mediante un update JS. Este trabajo no generó builds firmadas ni modificó app.json de BASE.

QRScanner solicita cámara al pulsar «Escanear QR», deduplica lecturas y emite `onScan(data, resultado)`, sin navegación. PhotoCapture ofrece cámara/galería, vista previa, Usar foto y Repetir. Web requiere HTTPS o localhost y disponibilidad del navegador.

FileUpload integra selector y dropzone Web; ImageUpload muestra miniaturas. Ambas reutilizan FileInput. `files` es controlado: onChange propone la lista; la app sube y actualiza progreso/error. Quitar un adjunto no borra archivos remotos. Puede inyectarse onPick/onCapture para adaptar políticas de archivos o permisos existentes.

DocumentPreview integra imágenes y PDF en Web cuando el navegador permite iframe; en nativo los PDF se abren en el visor del sistema. No se añadió un motor PDF nativo pesado. Para un visor PDF embebido en Android/iOS será necesaria una decisión específica y prueba de su dependencia. Los documentos privados deben tener URLs/permisos resueltos por la app.

## Gráficos y notificaciones

ChartContainer usa únicamente react-native-gifted-charts para line/bar/area/pie/donut; SVG y expo-linear-gradient son sus dependencias de representación. Las versiones comprobadas están en package-lock. El gráfico no obtiene ni actualiza datos. Para cada serie proporcionar también etiquetas legibles; la leyenda permite seleccionar con teclado.

```jsx
const toast = useToast();
toast.show({ title: 'Operación completada', tone: 'success' });
```

El proveedor conserva tres notificaciones como máximo, con duración de 4000 ms por defecto. No usar Toast para errores de formulario que necesitan permanecer visibles; usar ValidationMessage/Alert. Las ventanas nativas del sistema tienen prioridad de representación sobre overlays de la raíz de la aplicación.

## Aplicaciones

| Aplicación | Composición sugerida sin lógica de negocio en la librería |
| --- | --- |
| Operator | Header, Sidebar/BottomNavigation, DataTable, Ficha, QRScanner, PersonSelector/VehicleSelector, ConfirmDialog. |
| Admin | DataTable, FilterPanel, FormStandard por secciones, StockSelector, FileUpload, AuditHistory. |
| Trafic | DataTable, DateRangePicker, VehicleSelector/PersonSelector, Timeline, ProgressIndicator. |
| Route | BottomNavigation, DataCard, PhotoCapture, ImageUpload, FileUpload y estados de envío proporcionados por la app. |
| Boss | SummaryPanel, StatCard, KpiCard, ChartContainer, FilterPanel y DateRangePicker. |

Todas comparten provider/tokens. Los endpoints, datos reales, permisos, mapeo de recursos y operaciones permanecen en cada aplicación y en el backend existente.
