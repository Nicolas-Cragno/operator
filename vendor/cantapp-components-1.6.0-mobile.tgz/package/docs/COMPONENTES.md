# Inventario completo de componentes

Generado con `npm run audit:components`. Enumera todos los archivos JSX, incluidos wrappers internos y no exportados. La plataforma indica las primitivas usadas, no una certificación de ejecución en dispositivo.

| Componente | Archivo | Propiedades declaradas | Implementación |
| --- | --- | --- | --- |
| accessButton | src/components/Button/accessButton.jsx | label, onPress, allowed, disabled, icon, ...props | Composición |
| actions | src/components/Button/actions.jsx | label, icon, ...props, onPress, options, disabled, loading, showOnWeb | React Native |
| alertButton | src/components/Button/alertButton.jsx | label, onPress, ...props | Composición |
| booleanButton | src/components/Button/booleanButton.jsx | value, onChange, trueLabel, falseLabel, ...props | Composición |
| button | src/components/Button/button.jsx | label, text, onPress, disabled, loading, variant, icon, iconOnly, style, children, accessibilityLabel, accessibilityState, accessibilityRole, onError, ...props | React Native |
| closeButton | src/components/Button/closeButton.jsx | onPress, disabled, size, color | Composición |
| deleteButton | src/components/Button/deleteButton.jsx | onPress, disabled, size, color, confirmationTitle, confirmationDescription, ...props | Composición |
| doubleBooleanButton | src/components/Button/doubleBooleanButton.jsx | value, onChange, options, trueLabel, falseLabel, disabled | React Native |
| fullButton | src/components/Button/fullButton.jsx | label, onPress, ...props | Composición |
| imgButton | src/components/Button/imgButton.jsx | image, logo, label, onPress, onClick, disabled, style | React Native |
| logoButton | src/components/Button/logoButton.jsx | logo, image, label, onPress, onClick, disabled, style | React Native |
| textButton | src/components/Button/textButton.jsx | label, onPress, ...props | Composición |
| bigCard | src/components/Card/bigCard.jsx | title, value1, value2, value3, logo, onPress, style | React Native |
| card | src/components/Card/card.jsx | title, subtitle, children, onPress, style | React Native |
| cardButton | src/components/Card/cardButton.jsx | title, subtitle, ...props | Composición |
| cardFooter | src/components/Card/cardFooter.jsx | title, subtitle, ...props | Composición |
| cardIcon | src/components/Card/cardIcon.jsx | icon, text, onPress, onClick, style | React Native |
| cardInfo | src/components/Card/cardInfo.jsx | title, subtitle, ...props | Composición |
| cardLabel | src/components/Card/cardLabel.jsx | relation, onPress, style | React Native |
| cardLogo | src/components/Card/cardLogo.jsx | title, logo, onPress, onClick, style | React Native |
| cardLogoButton | src/components/Card/cardLogoButton.jsx | title, logo, onClick, onClickButton, onList, onAdd, addOn, style | React Native |
| chartContainer | src/components/Card/chartContainer.jsx | title, type, data, legend, onSelect, height | React Native |
| itemCard | src/components/Card/itemCard.jsx | title, subtitle, ...props | Composición |
| kpiCard | src/components/Card/kpiCard.jsx | title, value, change, changeLabel, children, ...props, icon | React Native |
| miniCard | src/components/Card/miniCard.jsx | title, subtitle, ...props | Composición |
| oilCard | src/components/Card/oilCard.jsx | date, place, lts, onClick, onDelete, style | React Native |
| tripCard | src/components/Card/tripCard.jsx | order, dateInit, placeInit, dateEnd, placeEnd, onClick, onDelete, onChange, style | React Native |
| dataValue | src/components/Data/dataValue.jsx | value, withTime, timeZone, type, depth, ancestors, onOpenReference, label, render, title, children | React Native |
| ficha | src/components/Ficha/ficha.jsx | title, data, fields, sections, relations, onEdit, onClose, onOpenRelation, visible | React Native |
| fichaChofer | src/components/Ficha/fichaChofer.jsx | data, estadisticas, viajes, movimientos, onOpenRelation, visible, onClose, ...props | React Native |
| fichaMovimiento | src/components/Ficha/fichaMovimiento.jsx | data, eventos, onOpenEvento, visible, onClose, ...props | React Native |
| fichaRelaciones | src/components/Ficha/fichaRelaciones.jsx | data, total, onOpenRelation, onLoadMore, hasMore | React Native |
| formAsignacion | src/components/Form/formAsignacion.jsx | data, fields, ...props | Composición |
| formCliente | src/components/Form/formCliente.jsx | data, fields, ...props | Composición |
| formField | src/components/Form/formField.jsx | children, label, required, error, hint, onSubmit, onCancel, loading, disabled, submitLabel | React Native |
| formFurgon | src/components/Form/formFurgon.jsx | data, fields, ...props | Composición |
| formPersona | src/components/Form/formPersona.jsx | data, fields, ...props | Composición |
| formProveedor | src/components/Form/formProveedor.jsx | data, fields, ...props | Composición |
| formStandard | src/components/Form/formStandard.jsx | title, fields, sections, data, onSubmit, onCancel, loading, optionsByField | React Native |
| formStock | src/components/Form/formStock.jsx | data, fields, ...props | Composición |
| formTractor | src/components/Form/formTractor.jsx | data, fields, ...props | Composición |
| formVehiculo | src/components/Form/formVehiculo.jsx | data, fields, ...props | Composición |
| banner | src/components/Functional/banner.jsx | title, subtitle, description, image, backgroundImage, style | React Native |
| clock | src/components/Functional/clock.jsx |  | React Native |
| emptyState | src/components/Functional/emptyState.jsx | title, description, children, style | React Native |
| formHeader | src/components/Functional/formHeader.jsx | title, description, ...props | Composición |
| formList | src/components/Functional/formList.jsx | title, description, ...props | Composición |
| formSection | src/components/Functional/formSection.jsx | title, description, children | React Native |
| formSelector | src/components/Functional/formSelector.jsx | title, description, ...props | Composición |
| icon | src/components/Functional/icon.jsx | name, size, color, ...props | Composición |
| indeterminateTrack | src/components/Functional/indeterminateTrack.jsx |  | React Native |
| loading | src/components/Functional/loading.jsx | appLogo, label | React Native |
| states | src/components/Functional/states.jsx | label, tone, title, description, children, onRetry, value, indeterminate, height, width, icon | React Native |
| checkbox | src/components/Input/checkbox.jsx | label, value, onChange, disabled, required | React Native |
| controls | src/components/Input/controls.jsx | value, onChange, step, min, max, steppers, disabled, ...props, label, options, required, onSearch, placeholder, loading | React Native |
| dateInput | src/components/Input/dateInput.jsx | label, value, onChange, placeholder, disabled, required, error, manual, onBlur | React Native |
| dateRangeFilter | src/components/Input/dateRangeFilter.jsx | value, onChange, onApply, onClear, disabled, loading | React Native |
| dateTimeInput | src/components/Input/dateTimeInput.jsx | value, onChange, label, disabled, required | React Native |
| fileInput | src/components/Input/fileInput.jsx | label, files, onPick, onCapture, onChange, onRemove, onError, disabled, loading, required, error | React Native |
| fileUpload | src/components/Input/fileUpload.jsx | onPick, ...props | Composición |
| fileUpload.web | src/components/Input/fileUpload.web.jsx | files, onChange, onPick, disabled, loading, ...props | Composición |
| input | src/components/Input/input.jsx | label, value, onChange, onChangeText, placeholder, disabled, multiline, error, style, inputStyle, keyboardType, required, onBlur, onFocus, validate, grow, ...props | React Native |
| inputBusqueda | src/components/Input/inputBusqueda.jsx | value, onChange, fields, selectedFields, onFieldsChange, ...props | React Native |
| inputForm | src/components/Input/inputForm.jsx |  | Composición |
| multiSelect | src/components/Input/multiSelect.jsx | label, value, onChange, options, disabled, required, error | React Native |
| select | src/components/Input/select.jsx | label, value, onChange, options, disabled, searchable, placeholder, required, error, onBlur | React Native |
| textArea | src/components/Input/textArea.jsx |  | Composición |
| brandLogo | src/components/Layout/brandLogo.jsx | source, width, height, label | React Native |
| dashboard | src/components/Layout/dashboard.jsx | children, title, description, legend | React Native |
| header | src/components/Layout/header.jsx | title, moduleName, user, onLogout, onUser, onNotifications, onMenu, appLogo | React Native |
| layout | src/components/Layout/layout.jsx | children, title, header | React Native |
| lowBar | src/components/Layout/lowBar.jsx | items, selected, onSelect, appLogo, mobileOnly | React Native |
| sidebar | src/components/Layout/sidebar.jsx | items, groups, selected, onSelect, appLogo, expanded, onToggle, preferences, preferenceKey, onPreferenceError | React Native |
| structure | src/components/Layout/structure.jsx | title, description, actions, items, onSelect, openKeys, onChange | React Native |
| summaryPanel | src/components/Layout/summaryPanel.jsx | items, children | React Native |
| tabs | src/components/Layout/tabs.jsx | items, value, selected, onChange, onSelect | React Native |
| confirmModal | src/components/Modal/confirmModal.jsx | title, description, onConfirm, onClose, loading, danger, confirmLabel, children, ...props | React Native |
| floatingLayer | src/components/Modal/floatingLayer.jsx | children | React Native |
| floatingLayer.web | src/components/Modal/floatingLayer.web.jsx | children | Composición |
| modal | src/components/Modal/modal.jsx | title, children, footer, data, fields, onClose, onEdit, onOpenForm, formType, dirty, closeOnBackdrop, requestRef, presentation, visible, ...props | React Native |
| modalColeccion | src/components/Modal/modalColeccion.jsx | visible, onClose, title, items, onOpenFicha, onSelect, fields | React Native |
| modalOptions | src/components/Modal/modalOptions.jsx | visible, onClose, title, options, onOpenForm | React Native |
| notifications | src/components/Modal/notifications.jsx | visible, title, description, tone, onClose, duration, children, open, onOpenChange, trigger, label, text | React Native |
| documentPreview | src/components/Operational/documentPreview.jsx | file, onOpen, onShare | React Native |
| documentPreview.web | src/components/Operational/documentPreview.web.jsx | file, onOpen, onShare | React Native |
| mediaViews | src/components/Operational/mediaViews.jsx | onPick, onCapture, ...props, value, identifier, onShare, size, onUse, onError, onGallery, disabled, attachments, selected, onSelect | React Native |
| qrScanner | src/components/Operational/qrScanner.jsx | onScan, onError, disabled | React Native |
| resourceSelector | src/components/Operational/resourceSelector.jsx | visible, onClose, title, items, data, multiple, value, onSelectionChange, onSelect, onSearch, loading, error, stock, hasMore, onLoadMore | React Native |
| timeline | src/components/Operational/timeline.jsx | items, dateKey, renderItem | React Native |
| pDFDocument | src/components/PDF/pDFDocument.jsx | document, data, title, header, template, fields, onGenerated, onError | React Native |
| pDFViaje | src/components/PDF/pDFViaje.jsx | data, header, template, style | React Native |
| pDFViewer | src/components/PDF/pDFViewer.jsx | visible, onClose, title, pages, images | React Native |
| reporteAveria | src/components/PDF/reporteAveria.jsx | data, header, template, fields, onGenerated, onError | Composición |
| dataTable | src/components/Table/dataTable.jsx | data, pageSize, ...props | Composición |
| dataViews | src/components/Table/dataViews.jsx | title, identifier, status, details, onPress, data, fields, label, value, onChange, options, onApply, onClear, activeFilters, onRemoveFilter, children, dates, loading | React Native |
| pagination | src/components/Table/pagination.jsx | page, totalPages, hasMore, loading, onChange | React Native |
| tabla | src/components/Table/tabla.jsx | data, columns, onRowPress, loading, error, onRetry, emptyMessage, searchable, search, onSearchChange, filters, sort, onSortChange, page, pageSize, total, hasMore, onChangePage, serverSide, selectedKeys, onSelectionChange, rowKey, renderActions, cellStyle, height, v2 | React Native |
| tablaFicha | src/components/Table/tablaFicha.jsx | data, onOpenFicha, onRowPress, ...props | Composición |
| tablaMovimientos | src/components/Table/tablaMovimientos.jsx |  | Composición |
| tablaViajes | src/components/Table/tablaViajes.jsx | data, ...props | Composición |
