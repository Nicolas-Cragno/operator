# CANTAPP Design System V2

## Auditoría previa — 30/10/2026

- Repositorio limpio al inicio; Expo SDK 54, React 19.1, RN 0.81.5, Web 0.21.4. Portal local en App.js/portal, sin router propio. No se reemplaza la arquitectura ni la navegación de las aplicaciones consumidoras.
- Existen 79 archivos JSX de componentes, tokens y 17 pruebas. Hay motores compartidos de tablas, formularios y fichas. El inventario completo se mantiene en COMPONENTES.md.
- Branding inspeccionado en `../cantapp-base/src/assets/branding`: cantapp-logo.png/.svg, cantapp-logo-white.svg, cantapp-symbol.png/.svg y versión blanca. Ilustraciones en src/assets/illustrations de BASE. No se copian ni mueven recursos: Header/Sidebar reciben source por props. El portal conserva su logo local.
- BASE usa Expo Router 6, Firebase, AsyncStorage, Lucide y SVG. No se modifica BASE, su autenticación, permisos empresariales, endpoints ni backend. La preferencia de Sidebar se integra por un adaptador de preferencias inyectado.
- V1 usa monospace general, tema oscuro predeterminado y controles 44. V2 cambia el default a Light, Inter, tamaños compactos Web y áreas táctiles 44 en Mobile. Dark permanece como legado pendiente de aprobación, sin crear una paleta V2 oscura nueva.
- Riesgos: confirmación obligatoria modifica el flujo de DeleteButton y guardado de formularios; se mantiene onPress/onSubmit y se ejecuta únicamente tras confirmar. Las APIs Tabla y Ficha anteriores siguen disponibles. DataTable es un alias configurado del mismo motor, con defaults V2 sin datos demo.
- Un modal reutilizable con contenido temporal evita apilar selectores/confirmaciones dentro de formularios. Permisos de hardware se solicitan solo al iniciar cámara/selector, no al importar ni montar el catálogo.
- Dependencias nuevas justificadas: Inter/expo-font, Lucide/react-native-svg, safe-area-context, cámara/image-picker/document-picker, QR y una sola biblioteca de gráficos. Se resolverán con expo install para SDK 54 y se verificarán imports, tipos instalados y bundles.
- Los enlaces Expo v54 redirigen a latest en este entorno. Se consulta además la documentación fuente en la rama oficial sdk-54 y los tipos instalados antes de usar APIs.
- La lista solicitada contiene **63 nombres**, no 65 (8+13+9+8+9+10+6). La matriz final usa esos 63 nombres; no se inventan dos componentes redundantes para alcanzar el número del encabezado.

## Fuentes técnicas

- [Expo SDK 54, fuentes oficiales](https://github.com/expo/expo/tree/sdk-54/docs/pages/versions/v54.0.0)
- [Cámara SDK 54](https://github.com/expo/expo/blob/sdk-54/docs/pages/versions/v54.0.0/sdk/camera.mdx)
- [ImagePicker SDK 54](https://github.com/expo/expo/blob/sdk-54/docs/pages/versions/v54.0.0/sdk/imagepicker.mdx)
- [DocumentPicker SDK 54](https://github.com/expo/expo/blob/sdk-54/docs/pages/versions/v54.0.0/sdk/document-picker.mdx)
- [Lucide Native](https://lucide.dev/guide/react-native)
- [Gifted Charts](https://github.com/Abhinandan-Kushwaha/react-native-gifted-charts)
- [QR SVG](https://github.com/Expensify/react-native-qrcode-svg)

## Entrega

Se implementan las siete familias: **63 componentes enumerados**, más `Icon` y `DesignSystemProvider` como infraestructura pública. No se agregaron variantes artificiales para compensar la diferencia numérica del pedido. Los nombres anteriores permanecen disponibles; las variantes V2 equivalentes se exportan como aliases de las implementaciones compartidas.

- [Matriz completa, props y ejemplos](DESIGN-SYSTEM-V2-COMPONENTES.md)
- [Guía para las cinco aplicaciones](V2-INTEGRACION.md)
- [Inventario de todos los archivos de componentes](COMPONENTES.md)
- [Archivos creados y modificados](V2-ARCHIVOS.md)

### Fundamentos

Tokens en `src/theme/tokens.js`, consumidos por temas, controles y componentes: paleta solicitada, radio 4, base 8, padding 16, controles Web 36 y táctiles 44, breakpoint 768, Header 48 y Sidebar 240/64. Se conserva la configuración de paletas heredada. `warningText` añade un tono de texto de contraste AA sin alterar el token warning solicitado.

Inter se carga desde ThemeProvider, también cuando el consumidor conserva ese provider anterior. Solo se incluye la variante utilizada; Consolas/Menlo/monospace se reserva para datos e identificadores. Lucide usa imports públicos individuales, evitando cargar todo su catálogo. Iconos por defecto de 18 px, con tamaños configurables. El tema oscuro anterior queda disponible como legado, **sin aprobación V2**.

La barra indeterminada usa Animated, se detiene al desmontar y respeta Reduce Motion. Los tokens exponen 150 ms para transiciones; la animación continua de progreso tiene un ciclo mayor para representar actividad, no un cambio de estado.

### Funcionalidad e integración

- Button comparte variantes, iconos, foco, loading, errores accesibles y bloqueo de Promises. IconButton/CloseButton/DeleteButton/AccessButton/SplitButton/FAB lo reutilizan. DeleteButton ejecuta onPress solo después de confirmar.
- Formularios: controles comunes, chips removibles, calendario, búsqueda manual, validación visual al perder foco y guardar, dos columnas cuando corresponde, secciones y footer fijo. Los guardados pasan por ConfirmDialog; no se agregaron validaciones empresariales.
- DataTable usa el motor Tabla con defaults V2 de 50, filas pulsables, sin acciones secundarias y DataCard Mobile. Tabla conserva los 25 anteriores y sus opciones explícitas de compatibilidad. Hay búsqueda/ordenamiento/filtros/páginas controlados, preservación del listado y selección externa cuando el consumidor la necesita.
- Modal centrado de hasta 720 px o fullscreen Mobile. Header/footer fuera del scroll, áreas seguras, foco/Escape de RN Web y onRequestClose nativo. Un coordinador mantiene un modal nativo visible; selectores y confirmaciones anidados reemplazan el contenido temporalmente y conservan el formulario montado. Dirty evita cierre accidental.
- Popover posiciona su capa dentro del contenedor modal activo en Web para conservar el foco; Escape cierra esa capa antes de llegar al diálogo exterior. En nativo usa el mismo contenedor temporal de Modal.
- ToastProvider limita a tres avisos, 4 segundos por defecto, sin bloquear la página. Tooltip, AlertDialog, LoadingOverlay y progreso comparten tokens.
- Header/Sidebar/BottomNavigation reciben logos y accesos desde la app. Sidebar persiste por adaptador opcional del mecanismo existente. «Más» abre drawer; Breadcrumbs, Tabs y Accordion no incorporan otro router.
- QRViewer/QRScanner, PhotoCapture, adjuntos y documentos tienen callbacks y estados de error. No hay navegación automática, Firestore, subida ni persistencia en estos controles. La selección múltiple conserva registros de páginas anteriores; StockSelector añade cantidad sin mover inventario.
- StatCard/KpiCard/SummaryPanel y gráficos no actualizan datos. KpiCard colorea la dirección matemática de la variación. Una única biblioteca, Gifted Charts, representa líneas, barras, áreas, tortas y donas con tooltips y leyendas.
- Portal: categorías V2 y compatibilidad, Light inicial, ejemplos interactivos para los 63 nombres, variantes y contratos, escenarios mock y copia de código. Los datos mock permanecen en portal/ejemplos y no se introducen en los nuevos defaults de producción.

### Dependencias incorporadas

| Paquete | Versión resuelta | Motivo |
| --- | --- | --- |
| @expo-google-fonts/inter | 0.4.2 | Tipografía solicitada, solo Regular empaquetada. |
| expo-font | 14.0.12 | Carga multiplataforma de Inter. |
| lucide-react-native | 1.65.0 | Iconos solicitados por subpaths públicos. |
| react-native-svg | 15.12.1 | Iconos, SVG de marca, gráficos y QR. |
| react-native-safe-area-context | 5.6.2 | Insets en navegación, modales y acciones flotantes. |
| expo-camera | 17.0.10 | Escaneo QR. |
| expo-image-picker | 17.0.11 | Cámara y galería. |
| expo-document-picker | 14.0.8 | Selector de archivos. |
| react-native-qrcode-svg | 6.3.49 | Representación QR. |
| react-native-gifted-charts | 1.4.81 | Única biblioteca de gráficos. |
| expo-linear-gradient | 15.0.8 | Dependencia de representación de Gifted Charts. |
| react-test-renderer | 19.1.0, desarrollo | Pruebas de transiciones con la versión exacta de React instalada. |

Expo install comprobó las versiones de SDK 54. Se revisaron los peerDependencies instalados de iconos/gráficos y sus tipos. `npm ls react react-native --depth=1` muestra reutilización de React 19.1 y RN 0.81.5, sin copias adicionales a ese nivel. La librería sigue sin estar preparada como distribución npm compilada con peerDependencies; se conserva la integración local existente.

### Validación

| Control | Resultado |
| --- | --- |
| npm run lint -- --no-cache | Correcto, sin errores ni advertencias. |
| npm run typecheck | Correcto. CheckJs continúa desactivado; no representa tipado estricto de toda la librería. |
| npm test | 29 pruebas aprobadas; incluye regresiones anteriores, render de componentes en ambos temas, confirmaciones, un único diálogo, dirty, búsqueda manual, errores asíncronos, cantidades, paginación de selección, tres toasts y contraste de tokens AA. |
| npm run check | 94 referencias de exportación de componentes y 519 imports locales verificados. |
| npm run audit:components | Inventario reproducible de 100 archivos JSX, incluidas adaptaciones e infraestructura interna. |
| npm run docs:v2 | 63 componentes documentados con propiedades y ejemplos. |
| npx expo install --check | Dependencias actualizadas para SDK 54. |
| npx expo config --type public | Configuración y plugins válidos; cámara declarada sin micrófono. |
| npx expo-doctor | 18/18 controles aprobados. |
| npm run build:web | Exportación local Web correcta. |
| npm run build:native | Exportaciones locales Hermes Android/iOS correctas. |

Las pruebas de render estático y transición simulan primitivas y módulos nativos. No son recorridos de navegador/emulador. React-test-renderer emite su advertencia de deprecación; está fijado a 19.1.0 y aislado de producción. Se separaron los procesos de pruebas de servidor e interacción para evitar mezclar renderers en un contexto.

La optimización de imports redujo el bundle principal Web provisional de 3.6 MB a aproximadamente 1.29 MB; los nativos provisionales de aproximadamente 5.8 MB a 3.48/3.47 MB. Estas cifras son del catálogo completo, sin gzip, y no son una medición de tiempo de inicio ni del tamaño de un APK. Los assets incluyen una única fuente Inter de unos 342 kB.

### Límites y pendientes explícitos

1. **Dispositivos:** no se ejecutaron APK/IPA, emuladores ni dispositivos físicos. Quedan pendientes cámara real, permisos denegados/permanentes, galería, safe areas, rotación, teclados y Share por plataforma. No se declara certificación Android/iOS por haber compilado bundles.
2. **Web:** falta recorrido E2E de foco, Tab/Escape, hover, dropzone, iframe PDF y cámara HTTPS en navegadores reales. Hay código y regresiones lógicas, pero no una prueba visual automatizada contra la maqueta aprobada.
3. **PDF nativo:** DocumentPreview/AttachmentViewer integran imágenes; los PDF se abren con el visor disponible del dispositivo. El preview PDF embebido nativo queda pendiente de una dependencia compatible y validación específica. En Web se integra iframe con sandbox sujeto a las políticas del documento/navegador.
4. **Popover nativo:** utiliza el contenedor Modal compartido, en lugar de una ventana flotante anclada al píxel. La limitación evita otra capa nativa y conserva selección/confirmación accesibles sin duplicar modales.
5. **WCAG:** se verificaron ratios de los tokens principales y estados semánticos; la certificación completa necesita lector de pantalla y pruebas de teclado/dispositivo. Paletas personalizadas pueden cambiar esos ratios.
6. **Dark:** pendiente de aprobación visual; se conserva la paleta legada como transición.
7. **Dependencias anteriores:** permanecen las 11 vulnerabilidades que informó npm durante la instalación (incluida la crítica de jsPDF 3.0.4). No se aplicó una actualización mayor silenciosa ni audit fix --force; requiere migración y fixtures de los documentos actuales.
8. **Integración productiva:** BASE y las cinco apps no se modificaron. La guía propone el uso de sus recursos y callbacks reales; falta probar cada consumidor con sus endpoints, preferencias y permisos ya existentes. No hubo despliegues, cambios en Firebase, autenticación ni backend.

### Cambios que debe revisar un consumidor

Light es el default; los aliases colorA–colorE continúan funcionando. Inter se carga automáticamente dentro de ThemeProvider. Los controles son compactos en Web y mantienen área táctil nativa. DeleteButton y los formularios ya no ejecutan la operación antes de confirmar. `DataTable` tiene defaults V2, mientras `Tabla` conserva su contrato anterior. Los callbacks asíncronos deben devolver su Promise para bloquear acciones repetidas y reflejar errores.

Los componentes operativos usan permisos del dispositivo solo al iniciar la acción. La configuración del portal declara cámara/fototeca, sin modificar permisos empresariales de BASE. Cada consumidor debe incluir esos plugins en su propia build si adopta las funciones de hardware. No se generaron directorios ios/android a mano.
