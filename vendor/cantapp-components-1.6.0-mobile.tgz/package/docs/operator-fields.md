Operator: configuración de campos
================================

En `operator/src/config/catalog.js`, las opciones de cada llamada a `item(...)`
aceptan tres listas independientes:

```js
item("tractores", "Tractores", "/tractores", {
  listFields: ["id", "dominio", "marca", "estado"],
  detailFields: [
    "id", "dominio", "marca",
    { key: "detalle", label: "Observaciones", section: "secondary" },
    { key: "relaciones", label: "Relaciones", section: "relations" },
  ],
  formFields: ["dominio", "marca", "modelo", "detalle", "estado"],
})
```

Sin `listFields`, se reutiliza `columns`. Sin `detailFields`, se muestran los
campos del registro, excluyendo la revisión interna y las etiquetas duplicadas.
Sin `formFields`, se conserva el esquema completo de la operación.
`detailFields` admite claves o descriptores con `key`, `label`, `type`, `section`
y `render(value, record)`. Las secciones `secondary` y `relations` van a la derecha.

Los tipos, controles, validaciones y campos condicionales siguen definidos en
`cantapp-components/src/data/administrationFields.js`. `formFields` selecciona
campos de ese esquema; no crea controles ni cambia sus contratos. Los campos
obligatorios permanecen visibles. Los valores iniciales y defaults se conservan,
y al editar se envían únicamente los cambios según el contrato existente.

No se consultan subcolecciones nuevas desde la ficha. Solo se presentan los datos
que la integración existente ya entrega; no se deducen endpoints ni permisos.
