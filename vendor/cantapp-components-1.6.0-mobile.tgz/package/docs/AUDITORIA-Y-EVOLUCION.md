# Auditoría y evolución de CANTAPP Components

Fecha: 29/10/2026. Alcance: este repositorio, sin servicios productivos ni despliegues.

## 1. Componentes existentes

El [inventario completo](COMPONENTES.md) registra todos los archivos JSX, propiedades y tipo de composición. Incluye componentes internos, aliases y formularios específicos; no se eliminaron exports públicos.

| Familia | Cambios implementados |
| --- | --- |
| Button y wrappers Access/Alert/Full/Text | Contraste, foco y hover Web, mínimo táctil de 44, carga, disabled y estados accesibles. Se corrige la precedencia de `text` cuando no se proporciona `label`. |
| BooleanButton / DoubleBooleanButton | Estado seleccionado accesible; DoubleBooleanButton propaga disabled. |
| Close/Delete/Img/LogoButton | Área táctil, etiquetas accesibles y colores del tema. |
| Card y wrappers CardLabel/Button/Footer/Info/Item/Mini | Tipografía común; Card interactiva anuncia su función. |
| BigCard/CardIcon/CardLogo/CardLogoButton/OilCard/TripCard | Colores de superficie, título, texto y acciones adaptados al tema, manteniendo propiedades y callbacks. |
| Input/TextArea/InputForm | Requerido, disabled, error, props adicionales del control y compatibilidad con onChangeText. |
| Select / MultiSelect / Checkbox / InputBusqueda | Tema, etiquetas, selección accesible y áreas táctiles; controles deshabilitados no invocan cambios. Select conserva su búsqueda existente. |
| DateInput | Inicialmente vacío; mes actual o seleccionado; grilla semanal alineada, navegación de meses, etiquetas, disabled y requerido. |
| FormStandard y los ocho formularios de recursos | Tema heredado, bloqueo durante guardado, validación de fechas/números/requeridos y envío de defaultValue. Se elimina el objeto default inestable que podía reinicializar el formulario. |
| Tabla / TablaFicha / TablaMovimientos / TablaViajes | Motor compartido, paginación, ordenamiento, búsqueda, filtros inyectables, selección controlada, acciones y estados. TablaViajes conserva columnas y cellStyle; TablaFicha presenta tipo y fecha. |
| Ficha / FichaChofer / FichaMovimiento | Campos estructurados y tema; presentación modal configurable mediante visible. Las estadísticas y relaciones también quedan dentro del modal de las fichas específicas. |
| FichaRelaciones | Conserva el contrato de paginación externa; recibe la tipografía compartida. |
| Modal / ModalColeccion / ModalOptions | Modal base con tema, campos estructurados, scroll y edición exclusiva: onEdit ya no dispara también onOpenForm. ModalColeccion hereda el tema. ModalOptions conserva acciones de identidad azul/blanco. |
| Header / Sidebar / LowBar / Layout / Tabs | Navegación exportada, tokens del tema, estado seleccionado con contraste. No se incorporó un router dentro de la librería: sus callbacks siguen perteneciendo a las aplicaciones. |
| Clock / Banner / Loading y wrappers funcionales | Tipografía común; Loading hereda el color del tema. Banner y sus wrappers conservan su presentación sobre imagen. FormSection reutiliza DetailSection. |
| PDFDocument / PDFViaje / ReporteAveria / PDFViewer | Se conserva el motor de generación existente. Se aísla jsPDF en un archivo .web.js; PDFViewer limita la página al cambiar la colección. Los documentos imprimibles conservan papel blanco. |

## 2. Componentes nuevos

- `DataValue`, `DateValue`, `DetailField`, `DetailSection`: fechas explícitas, timestamps, booleanos, arrays y objetos anidados; URLs y archivos HTTP(S), referencias con callback y protección de ciclos.
- `DateRangeFilter`: reutiliza DateInput, valida ambos extremos, admite rangos abiertos y emite selección/aplicación/limpieza.
- `DateTimeInput`: reutiliza DateInput e Input para fecha y hora local explícita.
- `StatusBadge`, `Alert`, `ErrorState`, `LoadingState`, `ProgressIndicator`, `Skeleton`: información textual además del color. `EmptyState` público usa el estado genérico; la ruta interna anterior se conserva por compatibilidad.
- `ConfirmDialog`: confirmación explícita y bloqueo durante operación.
- `FileInput`: adjuntos, vista previa de imagen, progreso y errores, con adaptadores de selección/captura inyectados.
- `KpiCard`, `Dashboard`, `ChartPanel`: indicadores, distribución adaptable y contenedores para gráficos de la aplicación, sin librería de gráficos adicional.
- `FormField`, `FormActions`, `ValidationMessage`; `FormSection` exporta la implementación funcional ya existente.

## 3. Sistema visual

Se conservan `colorA` a `colorE` y las paletas configurables. Se agregan `primary`, `special`, `details`, `surface`, `surfaceElevated`, `border`, `focus`, `hover`, `disabled`, `success`, `warning`, `danger`, `info`, `onAccent`, espaciados y altura de control. `radius` sigue siendo 4.

Los valores de identidad son los solicitados: oscuro primary #0d1f7f, texto #ffffff, special #fdd255 y details #730f21; claro primary #ffffff, texto #000000, special #0d1f7f y details #fdd255. Las superficies amplían esa identidad sin reemplazar los aliases existentes.

Tipografía: Web usa Consolas con Courier New y monospace de respaldo; iOS usa Menlo y Android monospace. No se agregaron archivos de fuentes. Los estilos existentes importan la decisión común de plataforma.

## 4. Portal

Catálogo con navegación y búsqueda, tema claro/oscuro, ejemplos mock de personas y tractores, apertura de ficha por encima del listado, filtro de fechas, movimiento de stock, comprobantes e indicadores. El fondo de preview deja de generar cientos de vistas para una grilla decorativa.

Incluye contratos extraídos del código, referencias específicas de las APIs principales, código seleccionable y copia con Clipboard del navegador cuando está disponible. En otras plataformas se conserva la selección manual del código. Los controles principales ofrecen variantes normal/disabled/loading/error según las propiedades que soportan.

## 5. Compatibilidad comprobada

- Expo SDK 54, React 19.1 y React Native 0.81.5 permanecen en sus versiones originales.
- Exportaciones locales Web, Android e iOS exitosas. Son bundles JS/Hermes y assets, no APK/IPA firmados ni pruebas de dispositivo.
- Antes del aislamiento PDF: bundles nativos de aproximadamente 3.48 MB; después: aproximadamente 1.96 MB, sin resolver jsPDF en Android/iOS.
- Los tests de render usan React real y primitivas nativas simuladas. No certifican geometría, TalkBack/VoiceOver, teclado, foco ni gestos reales.
- El modal utiliza el portal, focus trap, restauración de foco y Escape del Modal de React Native Web instalado (0.21.4), y onRequestClose en nativo. Hace falta validación manual de teclado y lector de pantalla en cada plataforma.
- No se migró el portal a Expo Router ni se añadieron dependencias de navegación: el catálogo actual usa estado local y no define rutas de aplicación.

Se consultaron [referencia Expo SDK 54](https://docs.expo.dev/versions/v54.0.0/), [índice oficial de Expo](https://docs.expo.dev/llms.txt), [Modal RN 0.81](https://reactnative.dev/docs/0.81/modal), [accesibilidad RN 0.81](https://reactnative.dev/docs/0.81/accessibility) y [FlatList RN 0.81](https://reactnative.dev/docs/0.81/flatlist). En esta sesión los enlaces versionados de Expo redirigieron a latest; por ello no se introdujeron APIs nuevas de Expo y se verificó el código instalado para el modal Web.

## 6. Validación

- `npm run lint -- --no-cache`: sin errores ni advertencias.
- `npm run typecheck`: correcto. Incluye los JS/JSX en el proyecto y contratos TS de las funciones de datos; `checkJs` está desactivado y esto **no equivale a tipar toda la librería**.
- `npm test`: 17 pruebas correctas de datos, timestamps, ciclos, fechas inválidas, rangos, tablas, selección, paginación de servidor, vista móvil, modales, formularios, exports, aislamiento PDF y render de todos los componentes p?blicos del cat?logo en ambos temas.
- `npm run check`: valida exports y todas las referencias locales de librería y portal.
- `npm run build:web` y `npm run build:native`: exportación local de Web/Android/iOS.
- `npm run audit:components`: inventario reproducible de todos los componentes y contratos del portal.
- Se instalaron únicamente herramientas de desarrollo para lint y TypeScript usando expo install. Los tests usan node:test, React y Babel existentes.
- `npm audit --json`: 11 dependencias reportadas (5 bajas, 3 moderadas, 2 altas, 1 crítica). Entre ellas jsPDF 3.0.4, postcss, image-size y dependencias de Expo. No se aplicó `audit fix --force`: propone cambios mayores e incluso bajar Expo a SDK 51. La migración de jsPDF a una versión corregida requiere validar impresión y documentos existentes.

## 7. Impacto en consumidores

- `DateInput` sin value ahora empieza vacío, en lugar de 30/10/1995. Quien necesitaba una fecha inicial debe proporcionarla.
- Tabla muestra 25 registros por página por defecto. Para una consulta paginada desde el servidor usar `serverSide`, `page`, `pageSize`, `total` o `hasMore` y `onChangePage`. No se debe volver a cortar la página en la aplicación.
- La búsqueda y el ordenamiento locales operan sobre data. Con serverSide la app procesa callbacks y entrega la página nueva. Usar claves estables y únicas; `selectedKeys` contiene strings.
- `onRowPress` se ofrece mediante la acción explícita «Ver ficha», separada de los controles de selección y acciones de fila.
- Para conservar la presentación embebida de Ficha, omitir visible; para cumplir el flujo modal de las aplicaciones, pasar visible y onClose. El portal usa ese flujo. Este opt-in preserva integraciones anteriores.
- Fechas string solo se interpretan al declarar type date/datetime. Los números, nombres y documentos no se convierten en fechas. Los timestamps estructurados se reconocen automáticamente.
- Los nuevos tokens cambian las superficies y estados; se mantienen paletas antiguas configurables. Una paleta personalizada necesita revisar su contraste.
- Se agrega `react-native: src/index.js` para que Metro resuelva la librería compartida. `main: index.js` continúa iniciando el portal Expo y `module: src/index.js` se conserva. Esto no es todavía un paquete npm compilado universal.
- No se movieron React/React Native a peerDependencies durante esta intervención. En un monorepo, la app debe resolver una sola instancia; la publicación requiere separar peerDependencies y configurar exports con pruebas en CANTAPP BASE.

## 8. Siguiente etapa

1. Ejecutar recorridos manuales en Web, Android e iOS: teclado, modal anidado, lector de pantalla, rotación, tamaño de fuente, formularios largos y cámara/permisos de los adaptadores consumidores.
2. Migrar jsPDF y dependencias vulnerables con fixtures de PDF y un plan de actualización compatible de Expo.
3. Probar el paquete local con CANTAPP BASE y preparar peerDependencies/exports para distribución; conservar un contrato versionado de APIs.
4. Agregar pruebas E2E de foco/Escape y de integración con paginación asíncrona; estas requieren navegador/emulador disponibles.
5. Completar tipado estricto, estados adicionales de controles (switch/radio) solo cuando los consumidores requieran contratos distintos, y mediciones de listas con datos representativos.
6. Mantener los componentes específicos como composiciones; decidir con los consumidores si se pueden deprecar wrappers internos redundantes, sin eliminarlos silenciosamente.
