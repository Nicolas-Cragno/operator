# CANTAPP Components · Design System V2

V2 incorpora Light industrial, Inter, Lucide y las siete familias solicitadas. La lista del pedido enumera **63 componentes**, todos exportados y con ejemplos; conserva las APIs anteriores.

- [Informe V2 y límites de validación](docs/DESIGN-SYSTEM-V2.md)
- [Matriz de componentes, propiedades y ejemplos](docs/DESIGN-SYSTEM-V2-COMPONENTES.md)
- [Integración con Operator, Admin, Trafic, Route y Boss](docs/V2-INTEGRACION.md)

Usar `DesignSystemProvider` en la raíz de la aplicación. El tema predeterminado ahora es Light; Dark conserva la paleta anterior, pendiente de aprobación V2. `DataTable` usa 50 registros por página, mientras `Tabla` conserva 25. Guardar formularios y DeleteButton requieren confirmación.

Biblioteca visual compartida y portal de ejemplos de CANTAPP. Expo SDK 54, React 19.1, React Native 0.81.5 y React Native Web. Datos y operaciones se reciben mediante props; no hay acceso a Firebase ni a APIs empresariales.

## Desarrollo

```sh
npm ci
npm run web
npm run android
```

El portal incluye búsqueda por componente, temas, contratos, ejemplos de código y escenarios con datos mock. No requiere credenciales.

## Validación local

```sh
npm run lint -- --no-cache
npm run typecheck
npm test
npm run check
npm run audit:components
npm run docs:v2
npm run build:web
npm run build:native
```

Los builds exportan archivos locales, sin desplegar. `build:native` genera bundles Android/iOS en `dist/native`; no genera un APK/IPA ni sustituye las pruebas en dispositivo. El typecheck actual cubre contratos de utilidades y estructura del proyecto; no tiene checkJs estricto para todo el JSX.

## Tabla y ficha modal

```jsx
import { useState } from 'react';
import { View } from 'react-native';
import { ThemeProvider, Tabla, Ficha } from 'cantapp-components';

export default function Personas({ registros, total, page, setPage, loading }) {
  const [registro, setRegistro] = useState(null);
  return <ThemeProvider mode="claro"><View style={{ flex: 1 }}>
    <Tabla data={registros}
      columns={[{ key: 'id', label: 'DNI' }, { key: 'nombre', label: 'Nombre' }]}
      serverSide page={page} pageSize={25} total={total}
      onChangePage={setPage} loading={loading} onRowPress={setRegistro} />
    <Ficha visible={!!registro} data={registro || {}}
      onClose={() => setRegistro(null)} />
  </View></ThemeProvider>;
}
```

La aplicación obtiene la página del servidor. Con `serverSide`, Tabla no filtra, ordena ni corta los registros recibidos. `onSearchChange`, `onSortChange` y `onChangePage` permiten coordinar nuevas consultas. Para cursores sin total conocido usar `hasMore`. Pasar siempre claves estables mediante id o rowKey; selectedKeys usa strings.

Para datos locales, Tabla pagina de a 25 por defecto y admite búsqueda, ordenamiento, selección y acciones. En celular muestra etiquetas por registro; en escritorio usa columnas con scroll horizontal.

## Datos y fechas

```jsx
<DataValue value="30123456" />
<DataValue value={{ seconds: 1790000000, nanoseconds: 0 }} />
<DataValue value={{ telefono: '011 4000 0000', permisos: ['Ingreso'] }} />
<DataValue value="2026-10-29" type="date" />
<DateRangeFilter value={rango} onChange={setRango}
  onApply={aplicarFiltro} onClear={limpiarFiltro} />
```

No se interpretan números o strings arbitrarios como fechas. Date y timestamps estructurados se reconocen automáticamente; los strings necesitan un tipo explícito. Los filtros devuelven `{from,to}` en dd/mm/aaaa; la aplicación define zona horaria y límites inclusivos/exclusivos del backend. DateTimeInput usa dd/mm/aaaa HH:mm en horario local.

## Adjuntos y documentos

FileInput recibe `onPick` y `onCapture` asíncronos: pueden devolver un array de archivos o `{canceled,assets}`. La aplicación administra permisos, cámara, subida y almacenamiento; el componente presenta selección, imágenes, progreso y errores. Quitar un adjunto solo emite callbacks.

PDFDocument, PDFViaje y ReporteAveria conservan la generación de PDF existente: jsPDF en Web, expo-print y expo-sharing en nativo. PDFViewer presenta imágenes de páginas, no interpreta binarios PDF. El renderizador Web está separado para excluir jsPDF de Android/iOS.

## Identidad y distribución

Radio de 4, identidad azul/amarillo/blanco/bordó, temas semánticos y tipografía Inter y datos en Consolas/monoespaciada con alternativas del sistema. Se conservan las paletas colorA–colorE y exports anteriores.

El punto público es `src/index.js`, indicado en `module` y `react-native`; `main: index.js` inicia el portal Expo. Para uso local con Metro, configurar el workspace para una sola instancia de React/React Native. La distribución npm con exports compilados y peerDependencies sigue requiriendo una migración probada con CANTAPP BASE.

Consultá el [informe de implementación, validación y compatibilidad](docs/AUDITORIA-Y-EVOLUCION.md) y el [inventario de todos los componentes](docs/COMPONENTES.md). El informe registra cambios que afectan consumidores, límites de la comprobación móvil y dependencias que requieren actualización.
