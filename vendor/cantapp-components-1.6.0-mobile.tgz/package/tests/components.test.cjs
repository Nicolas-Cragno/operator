const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const babel=require('@babel/core');
const {render,press,events,Tabla,Ficha,Modal,DateInput,DateRangeFilter,FormStandard,formatValue,formatDate,toDate,validateDateRange,makeTheme,setWidth}=require('./helpers.cjs');

test('fill table retains every column and supplied server page on mobile', () => {
  setWidth(390);
  try {
    const columns = Array.from({ length: 9 }, (_, index) => ({ key: `field${index}`, label: `Column ${index}` }));
    const row = Object.fromEntries(columns.map(column => [column.key, `Value ${column.key}`]));
    const html = render(Tabla, { v2: true, fill: true, serverSide: true, page: 4, pageSize: 1, total: 10, data: [{ id: '42', ...row }, { id: '43', ...row }], columns });
    for (const column of columns) assert.match(html, new RegExp(column.label));
    assert.match(html, /Abrir 42/);
    assert.match(html, /Abrir 43/);
    assert.ok(events.some(event => event.name === 'ScrollView' && event.horizontal && event.style.flex === 1));
  } finally { setWidth(1000); }
});
test('strings and numbers never become dates, including epoch-like identifiers', () => {
  for (const value of ['Claudia Medina', '30123456', 0, 745, '2026-10-29', '', null, false]) assert.equal(toDate(value), null);
  assert.equal(formatValue(0), '0'); assert.equal(formatValue('30123456'), '30123456'); assert.equal(formatValue(false), 'No');
});
test('timestamps, invalid dates and leap days', () => {
  assert.equal(toDate({ seconds: 0, nanoseconds: 0 }).getTime(), 0);
  assert.equal(formatDate({ seconds: 1790000000, nanoseconds: 0 }, { timeZone: 'UTC' }), '21/09/2026');
  assert.equal(toDate('31/02/2026', true), null); assert.equal(toDate('2026-02-31', true), null);
  assert.ok(toDate('29/02/2024', true)); assert.equal(toDate('29/02/2025', true), null);
  assert.equal(toDate({ seconds: 1, nanoseconds: -1 }), null);
  assert.equal(toDate('29/10/2026 24:00', true), null);
  assert.equal(toDate('29/10/2026 14:30', true).getHours(), 14);
});
test('nested arrays and objects are readable and cycle-safe', () => {
  assert.equal(formatValue({ id: '745', tags: ['Activo', true] }), 'id: 745 · tags: Activo · Sí');
  const value = {}; value.self = value; assert.match(formatValue(value), /circular/);
});
test('range validates both endpoints and rejects reversed intervals', () => {
  assert.equal(validateDateRange('', ''), ''); assert.equal(validateDateRange('29/10/2026', '29/10/2026'), '');
  assert.ok(validateDateRange('30/10/2026', '29/10/2026')); assert.ok(validateDateRange('99/10/2026', ''));
});
test('table renders identifiers, empty, loading and error states', () => {
  assert.match(render(Tabla, { data: [{ id: '30123456' }], columns: [{ key: 'id', label: 'DNI' }] }), /30123456/);
  assert.match(render(Tabla, { data: [] }), /No hay registros/);
  assert.match(render(Tabla, { loading: true }), /Cargando/);
  assert.match(render(Tabla, { error: 'Sin conexión' }), /Sin conexión/);
});
test('server pagination never slices, searches or reorders supplied page', () => {
  let page;
  const html = render(Tabla, { data: [{ id: 'B' }, { id: 'A' }], columns: [{ key: 'id', label: 'ID' }], serverSide: true, searchable: true, search: 'missing', sort: { key: 'id', direction: 'asc' }, page: 4, pageSize: 1, hasMore: true, onChangePage: p => { page = p; } });
  assert.ok(html.indexOf('>B<') < html.indexOf('>A<')); press('Siguiente'); assert.equal(page, 5);
});
test('row callbacks and selection preserve controlled keys', () => {
  let selected; let opened;
  render(Tabla, { data: [{ id: '745' }], onRowPress: row => { opened = row; }, onSelectionChange: keys => { selected = keys; } });
  press('Abrir 745'); assert.equal(opened.id, '745');
  events.find(e => e.accessibilityRole === 'checkbox').onPress(); assert.deepEqual(selected, ['745']);
});
test('mobile table includes field labels', () => { setWidth(390); const html = render(Tabla, { data: [{ id: '745' }], columns: [{ key: 'id', label: 'Interno' }] }); assert.match(html, /Interno/); setWidth(1000); });
test('modal visibility, X close and exclusive edit callback', () => {
  assert.doesNotMatch(render(Modal, { visible: false }), /role="dialog"/);
  let closed = 0; let edits = 0; let forms = 0;
  assert.match(render(Modal, { visible: true, onClose: () => closed++, onEdit: () => edits++, onOpenForm: () => forms++ }), /role="dialog"/);
  press('Cerrar'); press('Editar'); assert.equal(closed, 1); assert.equal(edits, 1); assert.equal(forms, 0);
});
test('record detail is modal when visible is supplied', () => {
  const html = render(Ficha, { visible: true, data: { id: '30123456', contacto: { telefono: '123' } } });
  assert.match(html, /role="dialog"/); assert.match(html, /30123456/); assert.match(html, /telefono/);
  assert.doesNotMatch(render(Ficha, { visible: false }), /role="dialog"/);
});
test('date input begins empty and respects disabled state', () => {
  render(DateInput); assert.equal(events.find(e => e.name === 'TextInput').value, '');
  render(DateInput, { disabled: true }); assert.equal(events.find(e => e.name === 'TextInput').editable, false);
});
test('range apply and clear emit controlled values, invalid apply is disabled', () => {
  let applied; let changed; let cleared = false;
  const range = { from: '01/10/2026', to: '29/10/2026' };
  render(DateRangeFilter, { value: range, onApply: v => { applied = v; }, onChange: v => { changed = v; }, onClear: () => { cleared = true; } });
  press('Aplicar filtros'); assert.deepEqual(applied, range); press('Limpiar'); assert.deepEqual(changed, { from: '', to: '' }); assert.ok(cleared);
  render(DateRangeFilter, { value: { from: '30/10/2026', to: '01/10/2026' } }); assert.ok(events.find(e => e.accessibilityLabel === 'Aplicar filtros').disabled);
});
test('form only submits valid input and loading disables controls', () => {
  let submitted = 0;
  render(FormStandard, { fields: [{ key: 'fecha', label: 'Fecha', type: 'date' }], data: { fecha: '31/02/2026' }, onSubmit: () => submitted++ }); press('Guardar'); assert.equal(submitted, 0);
  render(FormStandard, { loading: true }); assert.equal(events.find(e => e.name === 'TextInput').editable, false);
});
test('themes keep identity, radius and readable semantic roles', () => {
  assert.equal(makeTheme().primary, '#0d1f7f'); assert.equal(makeTheme('claro').primary, '#0d1f7f');
  for (const mode of ['oscuro', 'claro']) { const t = makeTheme(mode); assert.equal(t.radius, 4); assert.ok(t.surface && t.border && t.onAccent); }
});
test('V2 light text and semantic badge tokens meet AA contrast', () => {
  const { tokens } = require('../src/theme/tokens');
  const luminance = hex => { const [r,g,b] = hex.slice(1).match(/../g).map(value => parseInt(value,16)/255).map(value => value <= 0.04045 ? value/12.92 : ((value+0.055)/1.055)**2.4); return r*0.2126+g*0.7152+b*0.0722; };
  const ratio = (a,b) => { const l1=luminance(a),l2=luminance(b); return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05); };
  const c=tokens.colors;
  for (const [fg,bg] of [[c.text,c.surface],[c.muted,c.surface],['#ffffff',c.primary],[c.success,c.successBg],[c.danger,c.dangerBg],[c.warningText,c.warningBg],[c.info,c.infoBg]]) assert.ok(ratio(fg,bg)>=4.5, `${fg} / ${bg}`);
});
test('every portal component is publicly exported', () => {
  const parse = file => babel.parseSync(fs.readFileSync(file, 'utf8'), { babelrc: false, configFile: false, parserOpts: { plugins: ['jsx'] } }).program.body;
  const exports = new Set(parse('src/index.js').flatMap(node => node.type === 'ExportNamedDeclaration' ? node.specifiers.map(s => s.exported.name) : []));
  const groups = parse('portal/catalog.js').find(node => node.type === 'VariableDeclaration' && node.declarations[0].id.name === 'groups').declarations[0].init;
  for (const group of groups.properties) for (const item of group.value.elements) assert.ok(exports.has(item.value), `Missing export: ${item.value}`);
  for (const name of ['Button','BooleanButton','Modal','Ficha','Tabla','TablaViajes','DateInput','PDFViewer','generatePDF','createDocument','ThemeProvider']) assert.ok(exports.has(name));
});
test('PDF browser dependency is isolated from the native engine', () => {
  assert.doesNotMatch(fs.readFileSync('src/components/PDF/engine/pdfEngine.js', 'utf8'), /import\('jspdf'\)/);
  assert.match(fs.readFileSync('src/components/PDF/engine/webPdf.web.js', 'utf8'), /import\('jspdf'\)/);
});
test('all public visual components render with mock defaults in both themes', () => {
  const UI = require('../src/index');
  const catalog = require('../portal/catalog').catalog;
  for (const group of catalog) for (const item of group.items) {
    if (item.name === 'Escenarios') continue;
    assert.equal(typeof UI[item.name], 'function', item.name);
    for (const mode of ['claro', 'oscuro']) assert.doesNotThrow(() => render(UI[item.name], {}, mode), `${item.name} (${mode})`);
  }
});
