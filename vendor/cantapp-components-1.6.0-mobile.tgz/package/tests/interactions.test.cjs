const test=require('node:test');
const assert=require('node:assert/strict');
const {React,ThemeProvider,Modal,FormStandard}=require('./helpers.cjs');
const Renderer = require('react-test-renderer');
const { act } = Renderer;
global.IS_REACT_ACT_ENVIRONMENT = true;
async function mount(Component, props = {}) {
  let root;
  await act(async () => { root = Renderer.create(React.createElement(ThemeProvider, { mode: 'claro' }, React.createElement(Component, props))); });
  return root;
}
const action = (root, label) => root.root.findAll(node => node.type === 'div' && node.props.label === label).at(-1);
const click = async (root, label) => { const button = action(root, label); assert.ok(button, label); assert.ok(!button.props.disabled, label); await act(async () => { await button.props.onPress(); }); };
const unmount = async root => { await act(async () => root.unmount()); };

test('DeleteButton waits for confirmation and cancel never invokes delete', async () => {
  const DeleteButton = require('../src/components/Button/deleteButton').default;
  let deleted = 0; const root = await mount(DeleteButton, { onPress: () => deleted++ });
  await click(root, 'Eliminar'); assert.equal(deleted, 0);
  await click(root, 'Cancelar'); assert.equal(deleted, 0);
  await click(root, 'Eliminar'); await click(root, 'Confirmar'); assert.equal(deleted, 1);
  await unmount(root);
});
test('form save confirms inside the existing modal and retains input on cancel', async () => {
  let saved; const fields = [{ key: 'nombre', label: 'Nombre', required: true }];
  function Screen() { return React.createElement(Modal, { visible: true, onClose: () => {} }, React.createElement(FormStandard, { fields, data: { nombre: 'Claudia' }, onSubmit: data => { saved = data; } })); }
  const root = await mount(Screen);
  await click(root, 'Guardar'); assert.equal(saved, undefined);
  assert.equal(root.root.findAll(node => node.type === 'div' && node.props.role === 'dialog').length, 1);
  await click(root, 'Cancelar');
  assert.ok(root.root.findAll(node => node.type === 'div' && node.props['data-kind'] === 'TextInput').some(node => node.props.value === 'Claudia'));
  await click(root, 'Guardar'); await click(root, 'Guardar'); assert.deepEqual(saved, { nombre: 'Claudia' });
  await unmount(root);
});
test('manual search only runs on button or submit, not while typing', async () => {
  const { SearchInput } = require('../src/components/Input/controls'); let calls = 0; let draft;
  const root = await mount(SearchInput, { value: 'tractor', onChange: value => { draft = value; }, onSearch: () => calls++ });
  const input = root.root.find(node => node.type === 'div' && node.props['data-kind'] === 'TextInput');
  await act(async () => input.props.onChangeText('745')); assert.equal(calls, 0); assert.equal(draft, '745');
  await click(root, 'Buscar'); assert.equal(calls, 1);
  await act(async () => input.props.onSubmitEditing()); assert.equal(calls, 2);
  await unmount(root);
});
test('asynchronous actions block duplicate presses until settled', async () => {
  const Button = require('../src/components/Button/button').default; let count = 0; let resolve;
  const pending = new Promise(done => { resolve = done; });
  const root = await mount(Button, { label: 'Operar', onPress: () => { count++; return pending; } });
  const press = action(root, 'Operar').props.onPress;
  let first; await act(async () => { first = press(); await press(); }); assert.equal(count, 1);
  await act(async () => { resolve(); await first; }); await unmount(root);
});
test('V2 defines exactly 63 named components and every one has an example', () => {
  const { v2Names, v2Usage } = require('../portal/v2Manifest'); const UI = require('../src');
  assert.equal(v2Names.length, 63); assert.equal(new Set(v2Names).size, 63);
  for (const name of v2Names) { assert.equal(typeof UI[name], 'function', name); assert.ok(v2Usage[name], name); }
});
test('Android back/escape requests preserve dirty forms until discard is confirmed', async () => {
  let closed = 0;
  const root = await mount(Modal, { visible:true, dirty:true, onClose:()=>closed++, children:React.createElement('span',null,'Contenido') });
  await act(async()=>root.root.find(node=>node.type==='div'&&node.props.role==='dialog').props.onRequestClose());
  assert.equal(closed,0); await click(root,'Seguir editando'); assert.equal(closed,0);
  await act(async()=>root.root.find(node=>node.type==='div'&&node.props.role==='dialog').props.onRequestClose());
  await click(root,'Descartar cambios'); assert.equal(closed,1); await unmount(root);
});
test('independent dialogs coordinate a single active native modal', async () => {
  function Screen(){return React.createElement(React.Fragment,null,React.createElement(Modal,{visible:true,title:'Primero'}),React.createElement(Modal,{visible:true,title:'Segundo'}));}
  const root=await mount(Screen);
  assert.equal(root.root.findAll(node=>node.type==='div'&&node.props.role==='dialog').length,1);
  await unmount(root);
});
test('StockSelector returns stock, unit and a configured quantity without persistence', async () => {
  const {StockSelector}=require('../src');let result;
  const root=await mount(StockSelector,{visible:true,data:[{id:'ST-1',nombre:'Aceite',existencia:12,unidad:'lts.'}],onSelect:value=>{result=value;},onClose:()=>{}});
  await click(root,'Aceite');
  const input=root.root.findAll(node=>node.type==='div'&&node.props['data-kind']==='TextInput').at(-1);
  await act(async()=>input.props.onChangeText('3'));
  await click(root,'Seleccionar');assert.equal(result.id,'ST-1');assert.equal(result.quantity,3);assert.equal(result.unidad,'lts.');
  await unmount(root);
});
test('failed asynchronous actions expose an accessible error instead of disappearing', async () => {
  const Button=require('../src/components/Button/button').default;
  const root=await mount(Button,{label:'Operar',onPress:async()=>{throw new Error('Error de ejemplo');}});
  await click(root,'Operar');assert.match(JSON.stringify(root.toJSON()),/Error de ejemplo/);await unmount(root);
});
test('toast provider retains at most three nonblocking notifications', async () => {
  const {ToastProvider,useToast}=require('../src/components/Modal/notifications');let toast;
  function Harness(){toast=useToast();return React.createElement('span',null,'Página');}
  const root=await mount(ToastProvider,{children:React.createElement(Harness)});
  await act(async()=>{for(let index=0;index<4;index++)toast.show({title:`Aviso ${index}`,duration:0});});
  const text=JSON.stringify(root.toJSON());assert.doesNotMatch(text,/Aviso 0/);for(let index=1;index<4;index++)assert.match(text,new RegExp(`Aviso ${index}`));
  await unmount(root);
});
test('multiple resource selection survives externally paginated data', async () => {
  const {PersonSelector}=require('../src');let selected;
  const first={id:'P-1',nombre:'Claudia'},second={id:'P-2',nombre:'Martín'};
  const props={visible:true,multiple:true,onSelect:value=>{selected=value;},onClose:()=>{}};
  const root=await mount(PersonSelector,{...props,data:[first]});await click(root,'Claudia');
  await act(async()=>root.update(React.createElement(ThemeProvider,{mode:'claro'},React.createElement(PersonSelector,{...props,data:[second]}))));
  await click(root,'Martín');await click(root,'Seleccionar');assert.deepEqual(selected.map(item=>item.id),['P-1','P-2']);
  await unmount(root);
});


test('multiple selection keeps IDs and hides a long option list until opened', async () => {
  const MultiSelect = require('../src/components/Input/multiSelect').default;
  let selected;
  const root = await mount(MultiSelect, { label: 'Tractores', value: ['t-42'], options: [{ value: 't-42', label: '42 ABC123' }, { value: 't-99', label: '99 DEF456' }], onChange: value => { selected = value; } });
  assert.equal(root.root.findAll(node => node.type === 'div' && node.props.label === '99 DEF456').length, 0);
  await click(root, 'Quitar 42 ABC123');
  assert.deepEqual(selected, []);
  await unmount(root);
});
