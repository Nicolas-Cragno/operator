const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const babel = require('@babel/core');
const events = [];
let width = 1000;
const primitive = name => function Primitive(props) {
  events.push({ name, ...props });
  return React.createElement('div', { 'data-kind': name, onPress: props.onPress, onBlur: props.onBlur, onChangeText: props.onChangeText, onSubmitEditing: props.onSubmitEditing, label: props.accessibilityLabel, disabled: props.disabled, value: props.value, selected: props.accessibilityState?.selected }, props.children);
};
const native = {
  View: primitive('View'), Text: primitive('Text'), Pressable: primitive('Pressable'), TextInput: primitive('TextInput'),
  ScrollView: primitive('ScrollView'), ActivityIndicator: primitive('ActivityIndicator'),
  Image: primitive('Image'), ImageBackground: primitive('ImageBackground'),
  Switch: primitive('Switch'),
  Animated: { Value: class { interpolate() { return 0; } setValue() {} }, Image: primitive('AnimatedImage'), View: primitive('AnimatedView'), timing:()=>({}), loop:()=>({start(){},stop(){}}) },
  AccessibilityInfo:{isReduceMotionEnabled:async()=>true,addEventListener:()=>({remove(){}})},
  Easing: { linear: value => value },
  Modal: props => props.visible ? React.createElement('div', { role: 'dialog', onRequestClose: props.onRequestClose }, props.children) : null,
  FlatList: ({ data, renderItem, ListHeaderComponent }) => React.createElement('div', null, ListHeaderComponent, data.map((item, index) => React.createElement(React.Fragment, { key: index }, renderItem({ item, index })))),
  Platform: { OS: 'web', select: options => options.web },
  StyleSheet: { create: value => value }, useWindowDimensions: () => ({ width, height: 800 }),
  Linking: { openURL: () => {} },
  Share: { share: async () => ({}) },
};
const load = Module._load;
Module._load = function (id, ...args) {
  if (id === 'react-native') return native;
  if (id === 'react-native-safe-area-context') return { SafeAreaView: primitive('SafeAreaView'), SafeAreaProvider: primitive('SafeAreaProvider'), SafeAreaInsetsContext: React.createContext(null) };
  if (id === 'react-native-svg') return { SvgUri: primitive('SvgUri') };
  if (id.startsWith('lucide-react-native/icons/')) return {__esModule:true,default:primitive(id)};
  if (id === 'lucide-react-native') return new Proxy({}, { get: (_, name) => primitive(String(name)) });
  if (id === 'react-native-qrcode-svg') return { __esModule: true, default: primitive('QRCode') };
  if (id === 'react-native-gifted-charts') return { BarChart: primitive('BarChart'), LineChart: primitive('LineChart'), PieChart: primitive('PieChart') };
  if (id === 'expo-camera') return { useCameraPermissions: () => [null, async () => ({ granted: true })], CameraView: primitive('CameraView') };
  if (id.startsWith('@expo-google-fonts/')) return { Inter_400Regular: 1 };
  if (id === 'expo-font') return { useFonts: () => [true, null] };
  if (id.startsWith('expo-')) return {};
  return load.call(this, id, ...args);
};
const originalJs = require.extensions['.js'];
const compile = (module, filename) => {
  if (!filename.startsWith(path.resolve('src')) && !filename.startsWith(path.resolve('portal'))) return originalJs(module, filename);
  const result = babel.transformSync(fs.readFileSync(filename, 'utf8'), { filename, babelrc: false, configFile: false, plugins: ['@babel/plugin-transform-react-jsx', '@babel/plugin-transform-modules-commonjs'] });
  module._compile(result.code, filename);
};
require.extensions['.jsx'] = compile;
require.extensions['.js'] = compile;
require.extensions['.png'] = module => { module.exports = 1; };
require.extensions['.jpg'] = module => { module.exports = 1; };
const { formatValue, formatDate, toDate, validateDateRange } = require('../src/utils/data');
const Tabla = require('../src/components/Table/tabla').default;
const Ficha = require('../src/components/Ficha/ficha').default;
const Modal = require('../src/components/Modal/modal').default;
const DateInput = require('../src/components/Input/dateInput').default;
const DateRangeFilter = require('../src/components/Input/dateRangeFilter').default;
const FormStandard = require('../src/components/Form/formStandard').default;
const { ThemeProvider } = require('../src/theme/themeContext');
const { makeTheme } = require('../src/theme/theme');
function render(Component, props = {}, mode = 'oscuro') { events.length = 0; return renderToStaticMarkup(React.createElement(ThemeProvider, { mode }, React.createElement(Component, props))); }
const press = label => { const event = events.find(e => e.name === 'Pressable' && e.accessibilityLabel === label); assert.ok(event, `Missing button: ${label}`); assert.ok(!event.disabled); event.onPress(); };


module.exports={React,events,native,render,press,ThemeProvider,Modal,FormStandard,Tabla,Ficha,DateInput,DateRangeFilter,formatValue,formatDate,toDate,validateDateRange,makeTheme,setWidth:value=>{width=value;}};
