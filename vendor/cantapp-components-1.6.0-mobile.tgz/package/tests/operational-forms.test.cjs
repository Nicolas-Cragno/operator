const test = require('node:test');
const assert = require('node:assert/strict');
const { React, ThemeProvider, FormStandard } = require('./helpers.cjs');
const Renderer = require('react-test-renderer');
const { administrationFields } = require('../src/data/administrationFields');
const { validateArticleLines } = require('../src/components/Form/articleLines');
const Select = require('../src/components/Input/select').default;
const { NumberInput } = require('../src/components/Input/controls');
global.IS_REACT_ACT_ENVIRONMENT = true;
const { act } = Renderer;
async function click(root, label) {
  const button = root.root.findAll(node => node.type === 'div' && node.props.label === label).at(-1);
  assert.ok(button, label); assert.ok(!button.props.disabled);
  await act(async () => { await button.props.onPress(); });
}
test('article lines validate positive quantities, units and repeated IDs', () => {
  assert.ok(validateArticleLines([], { required: true }));
  assert.equal(validateArticleLines([]), '');
  assert.ok(validateArticleLines([{ id: 'a', cantidad: 0 }]));
  assert.ok(validateArticleLines([{ id: 'a', cantidad: 1 }, { id: 'a', cantidad: 2 }]));
  assert.ok(validateArticleLines([{ id: 'a', cantidad: 1 }], { includeUnit: true }));
  assert.equal(validateArticleLines([{ id: 'a', cantidad: 1.5, unidad: 'LT' }], { includeUnit: true }), '');
});
for (const type of ['asignacion', 'tallerTractor', 'tallerFurgon']) test(`${type}: productive schema and protected identity`, () => {
  const fields = administrationFields(type);
  assert.ok(fields.some(field => field.type === 'articleLines' && field.relation === 'stock'));
  assert.ok(!fields.some(field => ['id', 'fecha', 'orden'].includes(field.key)));
  assert.deepEqual(administrationFields('detalle').map(field => field.key), ['detalle']);
});
for (const mode of ['claro', 'oscuro']) test(`FormStandard ${mode}: add/remove articles, unit from catalog, confirmation and retained data after failure`, async () => {
  const fields = [{ key: 'repuestos', label: 'Repuestos', type: 'articleLines', required: true, includeUnit: true }];
  const initial = { repuestos: [] };
  const options = { repuestos: [{ value: 'a', label: 'Filtro', unidad: 'UN' }] };
  let calls = 0; let saved; let root;
  await act(async () => { root = Renderer.create(React.createElement(ThemeProvider, { mode }, React.createElement(FormStandard, { fields, data: initial, optionsByField: options, onSubmit: async value => { if (++calls === 1) throw new Error('Error del servidor'); saved = value; } }))); });
  await click(root, 'Guardar');
  assert.equal(calls, 0); assert.match(JSON.stringify(root.toJSON()), /Campo obligatorio/);
  await click(root, 'Agregar artículo');
  await act(async () => root.root.findByType(Select).props.onChange('a'));
  await act(async () => root.root.findByType(NumberInput).props.onChange('2'));
  await click(root, 'Agregar artículo');
  await click(root, 'Quitar artículo 2');
  await click(root, 'Guardar'); assert.equal(calls, 0);
  await click(root, 'Guardar'); assert.equal(calls, 1);
  assert.match(JSON.stringify(root.toJSON()), /Error del servidor/);
  assert.equal(root.root.findByType(NumberInput).props.value, '2');
  await click(root, 'Guardar');
  assert.deepEqual(saved.repuestos, [{ id: 'a', cantidad: '2', unidad: 'UN' }]);
  await act(async () => root.unmount());
});
