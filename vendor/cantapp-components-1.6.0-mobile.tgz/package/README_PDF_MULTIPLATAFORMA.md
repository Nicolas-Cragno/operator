# PDFs multiplataforma (V1.6)

`generatePDF(document, { action })` genera PDFs con **jsPDF en web** y **expo-print en Android/iOS**. `action`: `save`, `share` o `print`. En Android, guardar/compartir abre el diálogo nativo de compartir; `print` abre la impresión nativa. En web, `save` descarga el PDF y `print` abre el PDF con la orden de impresión (según el navegador puede requerir interacción).

## Uso

```jsx
import { createPDFViaje, generatePDF } from 'cantapp-components';

const doc = createPDFViaje({
  data: { viaje: '001-00001412', chofer: 'ARASCO, WALTER OMAR', tractor: '745' },
  header: { title: 'EMPRESA A', subtitle: 'Hoja de ruta' },
  filename: 'viaje-001-00001412.pdf',
});
await generatePDF(doc, { action: 'save' });
```

La app decide qué `header` corresponde al usuario. No hay Firebase ni autenticación en la librería.

## Plantillas al estilo Nexar

`createDocument({data, fields, template})` acepta `fields` con `{key,label,x,y,fontSize,maxWidth}`; `x` e `y` son **milímetros desde el borde superior izquierdo de una página A4**. `template` admite `require('...jpg')`, URI o data URI; se convierte en fondo de página antes de imprimir el texto. La librería **no adivina coordenadas de Nexar**: hay que configurar las posiciones para cada plantilla.

Si no se indica plantilla ni datos, se genera una página blanca A4 con el título si lo hay. Las plantillas originales de Nexar están en `src/assets/images/plantilla*.jpg`; se deben seleccionar explícitamente desde la app o el portal.

`PDFViewer` sigue siendo un visor de imágenes paginadas, no un renderizador PDF binario. `ReporteAveria` ahora genera PDF, pero sus campos/coordenadas de BESS todavía necesitan mapearse para reproducir el documento original exactamente.

## Instalación

```powershell
npx expo install expo-print expo-sharing expo-asset expo-file-system
npm install jspdf
npx expo start --web
```

## Límites y validación

El motor está implementado para web y nativo, pero **no se ha ejecutado una prueba real de impresión en Android/iOS ni en el navegador del usuario**. Las plantillas pueden requerir ajuste de márgenes y coordenadas; no se incluyen tests visuales contra Nexar. La impresión web depende de las restricciones de ventanas emergentes del navegador.
