import React from 'react';
import Portal from './portal/Portal';
import DesignSystemProvider from './src/theme/designSystemProvider';
export default function App() { return <DesignSystemProvider><Portal /></DesignSystemProvider>; }
