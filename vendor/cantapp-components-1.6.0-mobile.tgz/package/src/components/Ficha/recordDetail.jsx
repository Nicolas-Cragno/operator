import React, { useState } from 'react';
import { View, Text, useWindowDimensions } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { tokens } from '../../theme/tokens';
import Button from '../Button/button';
import BackButton from '../Button/BackButton';
import ReloadButton from '../Button/ReloadButton';

import { DetailSection } from '../Data/dataValue';

import DataTable from '../Table/dataTable';
import { SearchInput } from '../Input/controls';
import DateRangeFilter from '../Input/dateRangeFilter';

export function DetailTags({ items = [] }) {
  const t = useCantappTheme();
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4 }}>{items.map((item, i) =>
    <View key={item.key ?? i} style={{ alignSelf: 'flex-start', borderRadius: 4, backgroundColor: item.active === true ? 'rgba(22, 121, 74, 0.09)' : 'rgba(100, 116, 139, 0.08)', paddingHorizontal: 6, paddingVertical: 2 }}>
      <Text style={{ fontFamily, fontSize: 11, lineHeight: 16, fontWeight: '400', color: item.active === true ? t.success : t.muted }}>{item.label}</Text>
    </View>)}</View>;
}

export function DetailStatistics({ items = [] }) {
  const t = useCantappTheme();
  const { width, fontScale } = useWindowDimensions();
  const compact = width < 768;
  const [availableWidth, setAvailableWidth] = useState(0);
  const gap = 6;
  // Measure the actual container: fichas can also appear inside narrow modals.
  const singleColumn = compact && availableWidth > 0 && availableWidth < 2 * 120 * fontScale + gap;
  const cardWidth = availableWidth > 0 ? (availableWidth - gap) / 2 : '48%';
  return <View onLayout={compact ? event => setAvailableWidth(event.nativeEvent.layout.width) : undefined} style={{ flexDirection: 'row', flexWrap: 'wrap', alignSelf: 'stretch', minWidth: 0, flexShrink: compact ? 0 : undefined, gap }}>{items.map(item =>
    <View key={item.key} style={{ flexGrow: 1, flexShrink: 0, flexBasis: compact ? singleColumn || item.fullWidth ? '100%' : cardWidth : 130, minWidth: 0, maxWidth: '100%', padding: 8, gap: 4, borderRadius: 4, borderWidth: 0.5, borderColor: t.border, backgroundColor: t.surface }}>
      <Text style={{ fontFamily, fontSize: 11, lineHeight: 15, color: t.muted, minWidth: 0, flexShrink: 1 }}>{item.label}</Text>
      <Text selectable style={{ fontFamily, fontSize: 14, lineHeight: 20, fontWeight: '500', color: t.text, minWidth: 0, flexShrink: 1 }}>{item.value}</Text>
    </View>)}</View>;
}

export function RecordDetail({ title, subtitle, active, sections = [], relations = [], relationsLoading, relationsError, onRetryRelations, onOpenRelation, onOpenStock, onEdit, updatedAt, actions }) {
  const t = useCantappTheme();
  const compact = useWindowDimensions().width < 768;
  return <View style={{ minWidth: 0, flexShrink: compact ? 0 : undefined, gap: tokens.padding }}>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', flexShrink: compact ? 0 : undefined, minWidth: 0, justifyContent: 'space-between', alignItems: 'center', gap: tokens.space }}>
      <Text accessibilityRole="header" style={{ fontFamily, fontSize: 20, fontWeight: '600', color: t.text, flexShrink: 1 }}>{title}</Text>
      <View style={{ alignItems: 'flex-end', maxWidth: compact ? '100%' : undefined, minWidth: 0, gap: tokens.space }}>{!!subtitle && <Text style={{ fontFamily, color: t.muted }}>{subtitle}</Text>}{active !== undefined && <DetailTags items={[{ label: active ? 'Activo' : 'Inactivo', active }]} />}</View>
    </View>
    {!compact && actions}
    <View style={{ flexDirection: compact ? 'column' : 'row', flexShrink: compact ? 0 : undefined, minWidth: 0, alignItems: 'stretch', gap: tokens.padding }}>
      <View style={{ flex: compact ? undefined : 2, flexShrink: compact ? 0 : undefined, width: compact ? '100%' : undefined, minWidth: 0, gap: tokens.padding }}>{sections.map(section => <DetailSection key={section.key} title={section.title}>
        <View style={{ minWidth: 0, flexShrink: compact ? 0 : undefined, gap: 10 }}>{section.fields.map(field => <View key={field.key} style={{ minWidth: 0, flexShrink: compact ? 0 : undefined, gap: 4 }}>
          <Text style={{ fontFamily, fontSize: 11, lineHeight: 16, color: t.muted }}>{field.label}</Text>
          {field.format === 'tags' ? <DetailTags items={field.value} /> : field.format === 'statistics' ? <DetailStatistics items={field.value} /> : <Text selectable style={{ fontFamily, fontSize: 14, lineHeight: 20, color: t.text }}>{field.value}</Text>}
        </View>)}</View>
      </DetailSection>)}{onOpenStock && <Button label="Ver stock actual" variant="outline" onPress={onOpenStock} />}</View>
      <View style={{ flex: compact ? undefined : 1, flexShrink: compact ? 0 : undefined, width: compact ? '100%' : undefined, minWidth: 0, gap: tokens.space }}><DetailSection title="Relaciones">
        {relationsLoading ? <Text style={{ fontFamily, color: t.muted }}>Cargando relaciones…</Text> : relationsError ? <><Text style={{ fontFamily, color: t.danger }}>{relationsError}</Text><Button label="Reintentar relaciones" variant="outline" onPress={onRetryRelations} /></> : relations.length ? relations.map(relation => <Button key={relation.entity} label={`${relation.total} ${relation.label}`} variant="outline" onPress={() => onOpenRelation(relation)} />) : <Text style={{ fontFamily, color: t.muted }}>Sin relaciones registradas.</Text>}
      </DetailSection></View>
    </View>
    <View style={{ borderTopWidth: 1, borderColor: t.border, paddingTop: tokens.padding, minWidth: 0, flexShrink: compact ? 0 : undefined, gap: tokens.space, alignItems: 'flex-start' }}>
      {!!updatedAt && <Text style={{ fontFamily, color: t.muted }}>Última edición: {updatedAt}</Text>}
      {onEdit && <Button label="Editar" onPress={onEdit} />}
      {compact && actions}
    </View>
  </View>;
}

// The caller owns the server query; this component never slices or counts pages.
export function RelatedRecordsTable({ title, data, columns, total, page, pageSize = 25, search, onSearch, onChangePage, onRowPress, loading, error, onRetry, onBack, onReload, showBack = true, dateFilter = false, dateRange, onDateChange }) {
  const t = useCantappTheme();
  return <View style={{ gap: tokens.padding }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>{showBack && <BackButton onPress={onBack} />}<Text accessibilityRole="header" style={{ fontFamily, color: t.text, fontSize: 18, flexShrink: 1 }}>{title}</Text>{onReload && <ReloadButton loading={loading} onPress={onReload} />}</View>
    {dateFilter && <DateRangeFilter key={`${dateRange?.from || ''}:${dateRange?.to || ''}`} compact autoApply defaultValue={dateRange} onApply={onDateChange} />}
    <SearchInput label={`Buscar en ${title}`} value={search} onChange={onSearch} onSearch={onSearch} />
    <DataTable serverSide data={data} columns={columns} total={total} page={page} pageSize={pageSize} onChangePage={onChangePage} onRowPress={onRowPress} loading={loading} error={error} onRetry={onRetry} />
  </View>;
}
