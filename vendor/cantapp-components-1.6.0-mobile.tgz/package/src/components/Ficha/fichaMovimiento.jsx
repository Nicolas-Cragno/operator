import { tokens } from '../../theme/tokens';
import { useCantappTheme } from '../../theme/themeContext';
import React from 'react';
import Modal from '../Modal/modal';
import {View,Text,useWindowDimensions} from 'react-native';import Ficha from './ficha';import TablaFicha from '../Table/tablaFicha';import {movimiento} from '../../data/examples';
function FichaMovimiento({data=movimiento,eventos=[{id:'EV-001',tipo:'SALIDA',fecha:'26/10/2026'},{id:'EV-002',tipo:'CARGA',fecha:'27/10/2026'}],onOpenEvento,visible,onClose,...props}) { const t=useCantappTheme();
 const wide=useWindowDimensions().width>=750;
 const content=<View style={{backgroundColor:t.surface,padding:12,flexDirection:wide?'row':'column',gap:12}}><View style={{flex:1,minWidth:0}}><Ficha title="Movimiento / Viaje" data={data} onClose={onClose} {...props}/></View><View style={{flex:1,minWidth:0,gap:tokens.space}}><Text style={{color:t.special,fontWeight:'700'}}>Eventos del período y recursos relacionados</Text><TablaFicha data={eventos} onOpenFicha={onOpenEvento}/></View></View>;
 return visible===undefined?content:<Modal visible={visible} onClose={onClose} title="Ficha del registro">{content}</Modal>;
}
export default FichaMovimiento;
