import { tokens } from '../../theme/tokens';
import React from 'react';
import { View } from 'react-native';
import { persona } from '../../data/examples';
import { fieldsFrom } from '../../utils/helpers';
import Button from '../Button/button';
import { DetailField, DetailSection } from '../Data/dataValue';
import Modal from '../Modal/modal';
export default function Ficha({title='Ficha de persona',data=persona,fields,sections,relations=[],onEdit,onClose,onOpenRelation,visible}) {
 const shown=sections||[{title:'Datos',fields:fields||fieldsFrom(data)}];
 const content=<View style={{gap:tokens.padding}}>{shown.map((section,i)=><DetailSection key={section.key||i} title={section.title}>{section.fields?.map(field=><DetailField key={field.key} label={field.label} value={data?.[field.key]} type={field.type} render={field.render}/>)}{section.render?.(data)}</DetailSection>)}{relations.length>0&&<DetailSection title="Relaciones">{relations.map(r=><Button key={r.id} variant="outline" label={r.label||r.id} onPress={()=>onOpenRelation?.(r)}/>)}</DetailSection>}<View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{onEdit&&<Button label="Editar" onPress={()=>onEdit(data)}/>}<Button label="Cerrar" variant="outline" onPress={onClose}/></View></View>;
 // Keep the legacy embedded presentation; consumers opt into modal presentation with visible.
 return visible===undefined?<DetailSection title={title}>{content}</DetailSection>:<Modal visible={visible} title={title} onClose={onClose}>{content}</Modal>;
}
