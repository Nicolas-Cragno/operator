import React from 'react';
import { View, Text } from 'react-native';
import { relaciones } from '../../data/examples';
import CardLabel from '../Card/cardLabel';
import { useCantappTheme } from '../../theme/themeContext';
import styles from './styles/fichaRelaciones.styles';
function FichaRelaciones({ data = relaciones, total = data.length, onOpenRelation, onLoadMore, hasMore = false }) { const t = useCantappTheme(); return <View style={[styles.root, { gap: 10 }]}><Text style={[styles.text, { color: t.colorA }]}>Relaciones ({data.length} de {total})</Text>{data.map(r => <CardLabel key={r.id} relation={r} onPress={onOpenRelation} />)}{hasMore ? <Text onPress={onLoadMore} style={[styles.text, { color: t.colorA }]}>Ver más relaciones</Text> : null}</View>; }
export default FichaRelaciones;
