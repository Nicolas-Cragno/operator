import { useCantappTheme } from '../../theme/themeContext';
import React from 'react';
import Modal from '../Modal/modal';
import {View,Text,useWindowDimensions} from 'react-native';import Ficha from './ficha';import TablaFicha from '../Table/tablaFicha';import {persona} from '../../data/examples';
function FichaChofer({data=persona,estadisticas={viajes:132,promedio:40.25,diferencia:22},viajes=[{id:'001-00001412',tipo:'Viaje',fecha:'26/10/2026'}],movimientos=[],onOpenRelation,visible,onClose,...props}) { const t=useCantappTheme();
 const wide=useWindowDimensions().width>=750;
 const content=<View style={{backgroundColor:t.surface,flexDirection:wide?'row':'column',gap:12,padding:12}}><View style={{flex:1,minWidth:0}}><Ficha title="Ficha de chofer" data={data} onClose={onClose} {...props}/></View><View style={{flex:1,minWidth:0,gap:10}}><Text style={{color:t.special,fontWeight:'700'}}>Estadísticas</Text><View style={{flexDirection:'row',justifyContent:'space-between'}}>{Object.entries(estadisticas).map(([k,v])=><View key={k}><Text style={{color:t.muted}}>{k}</Text><Text style={{color:t.text,fontWeight:'700'}}>{String(v)}</Text></View>)}</View><Text style={{color:t.special,fontWeight:'700'}}>Viajes y movimientos</Text><TablaFicha data={[...viajes,...movimientos]} onOpenFicha={onOpenRelation}/></View></View>;
 return visible===undefined?content:<Modal visible={visible} onClose={onClose} title="Ficha del registro">{content}</Modal>;
}
export default FichaChofer;
