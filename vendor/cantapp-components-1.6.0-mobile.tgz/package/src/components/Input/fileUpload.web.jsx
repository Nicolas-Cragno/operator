import { tokens } from '../../theme/tokens';
import React, { useEffect, useRef, useState } from 'react';
import FileInput from './fileInput';
import { pickDocuments } from '../Operational/media';
import { useCantappTheme } from '../../theme/themeContext';
export default function FileUpload({files=[],onChange,onPick,disabled=false,loading=false,...props}){
 const t=useCantappTheme();const [hover,setHover]=useState(false);const urls=useRef([]);
 useEffect(()=>()=>urls.current.forEach(url=>URL.revokeObjectURL(url)),[urls]);
 return <div role="group" aria-label="Soltar archivos o usar el selector" onDragOver={event=>{event.preventDefault();if(!disabled&&!loading)setHover(true);}} onDragLeave={()=>setHover(false)} onDrop={event=>{event.preventDefault();setHover(false);if(disabled||loading)return;const added=Array.from(event.dataTransfer.files).map(file=>({file,name:file.name,mimeType:file.type,size:file.size,uri:URL.createObjectURL(file)}));urls.current.push(...added.map(file=>file.uri));onChange?.([...files,...added]);}} style={{border:'1px dashed '+(hover?t.primary:t.border),borderRadius:tokens.radius,padding:tokens.padding,background:hover?t.selection:t.surface}}><FileInput {...props} files={files} disabled={disabled} loading={loading} onChange={onChange} onPick={onPick||pickDocuments}/></div>;
}
