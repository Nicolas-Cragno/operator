import React from 'react';
import FileInput from './fileInput';
import { pickDocuments } from '../Operational/media';
export default function FileUpload({onPick,...props}){return <FileInput {...props} onPick={onPick||pickDocuments}/>;}
