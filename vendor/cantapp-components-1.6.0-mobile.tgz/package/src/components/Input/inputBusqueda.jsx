import { tokens } from '../../theme/tokens';
import { useCantappTheme } from '../../theme/themeContext';
import React, { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import Input from './input';
function InputBusqueda({ value, onChange, fields = [{key:'id',label:'ID'},{key:'nombre',label:'Nombre'},{key:'dominio',label:'Dominio'}], selectedFields, onFieldsChange, ...props }) { const t=useCantappTheme();
 const [local, setLocal] = useState(fields.map(x=>x.key));
 const chosen = selectedFields ?? local;
 const toggle = key => { const next=chosen.includes(key)?chosen.filter(x=>x!==key):[...chosen,key];if(!selectedFields)setLocal(next);onFieldsChange?.(next); };
 return <View style={{gap:tokens.space}}><Input label="Buscar" placeholder="Buscar registros..." value={value} onChange={onChange} {...props}/><View style={{flexDirection:'row',flexWrap:'wrap',gap:12}}>{fields.map(f=><Pressable accessibilityRole="checkbox" accessibilityState={{checked:chosen.includes(f.key)}} key={f.key} onPress={()=>toggle(f.key)} style={{minHeight:44,flexDirection:'row',alignItems:'center',gap:5}}><Text style={{color:t.special}}>{chosen.includes(f.key)?'☑':'☐'}</Text><Text style={{color:t.text}}>{f.label}</Text></Pressable>)}</View>{!chosen.length && <Text style={{color:t.muted,fontSize:11}}>Sin filtros: buscar en todos los campos</Text>}</View>;
}
export default InputBusqueda;
