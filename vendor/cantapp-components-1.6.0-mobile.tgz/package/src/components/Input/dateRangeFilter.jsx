import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text } from 'react-native';
import DateInput from './dateInput';
import Button from '../Button/button';
import { validateDateRange } from '../../utils/data';
import { useCantappTheme } from '../../theme/themeContext';
export default function DateRangeFilter({value,defaultValue,onChange,onApply,onClear,disabled=false,loading=false,compact=false,autoApply=false}) {
 const t=useCantappTheme();const [local,setLocal]=useState(()=>defaultValue??{from:'',to:''}); const range=value??local;
 const error=validateDateRange(range.from,range.to);
 const update=next=>{if(value===undefined)setLocal(next);onChange?.(next);if(autoApply&&!validateDateRange(next.from,next.to))onApply?.(next);};
 const clear=<Button label="Limpiar fechas" variant="ghost" disabled={disabled||loading} onPress={()=>{update({from:'',to:''});onClear?.();}}/>;
 return <View style={{gap:8}}><View style={{flexDirection:'row',flexWrap:'wrap',alignItems:'flex-end',gap:compact?8:12}}><View style={{flexGrow:1,flexBasis:compact?170:230,minWidth:compact?160:230,maxWidth:compact?250:undefined}}><DateInput label="Desde" value={range.from||''} onChange={from=>update({...range,from})} disabled={disabled||loading}/></View><View style={{flexGrow:1,flexBasis:compact?170:230,minWidth:compact?160:230,maxWidth:compact?250:undefined}}><DateInput label="Hasta" value={range.to||''} onChange={to=>update({...range,to})} disabled={disabled||loading}/></View>{compact&&clear}</View>{error?<Text accessibilityRole="alert" style={{color:t.danger,fontSize:12}}>{error}</Text>:null}{(!autoApply||!compact)&&<View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{!autoApply&&<Button label="Aplicar filtros" disabled={disabled||!!error} loading={loading} onPress={()=>onApply?.(range)}/>} {!compact&&clear}</View>}</View>;
}
