import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, TextInput } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { controlHeight, focusStyle } from '../../theme/controls';
export default function Input({label='Descripción',value='',onChange,onChangeText,placeholder='Ingresá un valor',disabled=false,multiline=false,error,style,inputStyle,keyboardType='default',required=false,onBlur,onFocus,validate,grow=false,...props}){
 const t=useCantappTheme();const [focused,setFocused]=useState(false);const [localError,setError]=useState('');const [height,setHeight]=useState(96);const message=error||localError;
 return <View style={[{gap:4},style]}>{label&&<Text style={{fontFamily,fontSize:12,color:t.text}}>{label}{required?' · Obligatorio':''}</Text>}<TextInput {...props} value={String(value??'')} onChangeText={onChange||onChangeText} accessibilityLabel={label} accessibilityState={{disabled}} editable={!disabled} placeholder={placeholder} placeholderTextColor={t.muted} multiline={multiline} keyboardType={keyboardType} onFocus={event=>{setFocused(true);onFocus?.(event);}} onBlur={event=>{setFocused(false);setError(validate?.(value)||(required&&!String(value??'').trim()?'Campo obligatorio':''));onBlur?.(event);}} onContentSizeChange={grow?event=>setHeight(Math.max(96,event.nativeEvent.contentSize.height)):undefined} style={[{fontFamily,fontSize:14,color:t.text,backgroundColor:t.surface,borderRadius:tokens.radius,borderWidth:1,borderColor:message?t.danger:t.border,minHeight:multiline?96:controlHeight,height:multiline&&grow?height:undefined,paddingHorizontal:10,paddingVertical:6,opacity:disabled?0.5:1,textAlignVertical:multiline?'top':'center'},focused&&focusStyle(t.focus),inputStyle]}/>{message?<Text accessibilityRole="alert" style={{fontFamily,fontSize:12,color:t.danger}}>{message}</Text>:null}</View>;
}
