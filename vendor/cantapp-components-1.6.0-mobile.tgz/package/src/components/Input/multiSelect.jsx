import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import Input from './input';
import { Popover } from '../Modal/notifications';
import Checkbox from './checkbox';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
export default function MultiSelect({label='Opciones',value=[],onChange,options=[],disabled=false,required=false,error}){
 const t=useCantappTheme();const [open,setOpen]=useState(false);const [query,setQuery]=useState('');const items=options.map(option=>typeof option==='string'?{label:option,value:option}:option);
 const toggle=key=>onChange?.(value.includes(key)?value.filter(item=>item!==key):[...value,key]);
 return <View style={{gap:tokens.space}}><Text style={{fontFamily,color:t.text,fontSize:12}}>{label}{required?' · Obligatorio':''}</Text><View style={{flexDirection:'row',flexWrap:'wrap',gap:4}}>{value.map(key=><Button key={key} label={String(items.find(item=>item.value===key)?.label||key)} icon="close" variant="secondary" accessibilityLabel={`Quitar ${items.find(item=>item.value===key)?.label||key}`} disabled={disabled} onPress={()=>toggle(key)}/>)}</View><Popover open={open&&!disabled} onOpenChange={setOpen} label={label} trigger={<Button label={value.length?`${value.length} seleccionados`:'Seleccionar...'} icon="down" variant="outline" disabled={disabled} accessibilityState={{expanded:open&&!disabled}} onPress={()=>setOpen(old=>!old)}/>}><Input label={`Buscar ${label}`} value={query} onChange={setQuery}/><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" style={{maxHeight:240}}>{items.filter(item=>`${item.label} ${item.value}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())).map(item=><Checkbox key={item.value} label={item.label} value={value.includes(item.value)} onChange={()=>toggle(item.value)} disabled={disabled||item.disabled}/>)}</ScrollView></Popover>{error&&<Text accessibilityRole="alert" style={{color:t.danger}}>{error}</Text>}</View>;
}
