import { tokens } from '../../theme/tokens';
import React from 'react';
import { Pressable, Text, View } from 'react-native';
import Icon from '../Functional/icon';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { controlHeight, focusStyle } from '../../theme/controls';
export default function Checkbox({label='Activo',value=true,onChange,disabled=false,required=false}){
 const t=useCantappTheme();return <Pressable accessibilityRole="checkbox" accessibilityLabel={label} accessibilityState={{checked:!!value,disabled}} disabled={disabled} onPress={()=>onChange?.(!value)} style={({focused})=>[{minHeight:controlHeight,flexDirection:'row',alignItems:'center',gap:tokens.space,padding:4,borderRadius:tokens.radius,opacity:disabled?0.5:1},focused&&focusStyle(t.focus)]}><View style={{width:18,height:18,borderWidth:1,borderColor:value?t.primary:t.border,borderRadius:tokens.radius,backgroundColor:value?t.primary:t.surface,alignItems:'center',justifyContent:'center'}}>{value&&<Icon name="check" size={14} color="#ffffff"/>}</View><Text style={{fontFamily,fontSize:14,color:t.text}}>{label}{required?' · Obligatorio':''}</Text></Pressable>;
}
