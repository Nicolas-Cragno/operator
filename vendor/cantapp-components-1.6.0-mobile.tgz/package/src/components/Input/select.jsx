import React, { useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import Input from './input';
import Button from '../Button/button';
import { Popover } from '../Modal/notifications';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
export default function Select({label='Seleccionar',value,onChange,options=[],disabled=false,searchable=true,placeholder='Seleccionar…',required=false,error,onBlur}){
 const t=useCantappTheme();const [open,setOpen]=useState(false);const [query,setQuery]=useState('');
 const items=options.map(option=>typeof option==='string'?{label:option,value:option}:option);
 const shown=items.filter(item=>String(item.label).toLowerCase().includes(query.toLowerCase()));const selected=items.find(item=>item.value===value);
 return <View style={{gap:4}}><Text style={{fontFamily,color:t.text,fontSize:12}}>{label}{required?' · Obligatorio':''}</Text><Popover open={open&&!disabled} onOpenChange={next=>{setOpen(next);if(!next)onBlur?.();}} label={label} trigger={<Button variant="outline" label={selected?.label||placeholder} icon="down" accessibilityLabel={label} accessibilityState={{expanded:open}} disabled={disabled} onPress={()=>setOpen(old=>!old)} style={{alignItems:'flex-start'}}/>}>{searchable&&<Input label={`Buscar ${label}`} value={query} onChange={setQuery}/>}<ScrollView nestedScrollEnabled style={{maxHeight:220}}>{shown.length?shown.map(item=><Button key={item.value} label={String(item.label)} accessibilityState={{selected:value===item.value}} variant={item.value===value?'secondary':'ghost'} disabled={item.disabled} onPress={()=>{onChange?.(item.value);setOpen(false);setQuery('');onBlur?.(item.value);}} style={{alignItems:'flex-start'}}/>):<Text style={{fontFamily,color:t.muted,padding:8}}>Sin resultados</Text>}</ScrollView></Popover>{error&&<Text accessibilityRole="alert" style={{color:t.danger,fontSize:12}}>{error}</Text>}</View>;
}
