import { tokens } from '../../theme/tokens';
import React from 'react';
import { View } from 'react-native';
import DateInput from './dateInput';
import Input from './input';
export default function DateTimeInput({ value = '', onChange, label = 'Fecha y hora', disabled = false, required = false }) {
  const [date = '', time = ''] = String(value || '').split(' ');
  const update = (nextDate, nextTime) => onChange?.(`${nextDate} ${nextTime}`.trimEnd());
  return <View style={{ gap:tokens.space }}><DateInput label={label} value={date} onChange={next => update(next, time)} disabled={disabled} required={required} /><Input label="Hora (HH:mm)" value={time} placeholder="14:30" keyboardType="numbers-and-punctuation" onChange={next => update(date, next)} disabled={disabled} required={required} /></View>;
}
