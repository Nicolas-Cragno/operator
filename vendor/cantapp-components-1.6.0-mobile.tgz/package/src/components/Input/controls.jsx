import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text, Pressable, Switch as NativeSwitch } from 'react-native';
import Input from './input';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
import { controlHeight, focusStyle } from '../../theme/controls';
import { fontFamily } from '../../theme/typography';
export function NumberInput({value='',onChange,step=1,min=-Infinity,max=Infinity,steppers=false,disabled=false,...props}){
 const change=direction=>{const number=(Number.isFinite(Number(value))?Number(value):0)+direction*step;onChange?.(String(Math.max(min,Math.min(max,number))));};
 return <View style={{flexDirection:'row',gap:tokens.space,alignItems:'flex-end'}}><View style={{flex:1}}><Input {...props} value={value} onChange={onChange} disabled={disabled} keyboardType="numeric" validate={v=>v!==''&&!Number.isFinite(Number(v))?'Número inválido':''}/></View>{steppers&&<><Button iconOnly icon="minus" variant="outline" accessibilityLabel="Disminuir" disabled={disabled||Number(value)<=min} onPress={()=>change(-1)}/><Button iconOnly icon="plus" variant="outline" accessibilityLabel="Aumentar" disabled={disabled||Number(value)>=max} onPress={()=>change(1)}/></>}</View>;
}
export function RadioGroup({label='Opciones',value,onChange,options=[],disabled=false,required=false}){
 const t=useCantappTheme();return <View accessibilityRole="radiogroup" accessibilityLabel={label} style={{gap:4}}><Text style={{fontFamily,color:t.text,fontSize:12}}>{label}{required?' · Obligatorio':''}</Text>{options.map(option=>{const item=typeof option==='string'?{label:option,value:option}:option;return <Pressable key={item.value} accessibilityRole="radio" accessibilityState={{checked:value===item.value,disabled:disabled||item.disabled}} disabled={disabled||item.disabled} onPress={()=>onChange?.(item.value)} style={({focused})=>[{minHeight:controlHeight,flexDirection:'row',alignItems:'center',gap:tokens.space,padding:8,borderRadius:tokens.radius},focused&&focusStyle(t.focus)]}><Text style={{color:t.primary}}>{value===item.value?'◉':'○'}</Text><Text style={{fontFamily,color:t.text}}>{item.label}</Text></Pressable>;})}</View>;
}
export function Switch({label='Activo',value=false,onChange,disabled=false}){const t=useCantappTheme();return <View style={{minHeight:44,flexDirection:'row',alignItems:'center',gap:tokens.space}}><NativeSwitch accessibilityLabel={label} disabled={disabled} value={!!value} onValueChange={onChange} trackColor={{false:t.border,true:t.primary}}/><Text style={{fontFamily,color:t.text}}>{label}</Text></View>;}
export function SearchInput({value='',onChange,onSearch,label='Buscar',placeholder='Buscar registros',disabled=false,loading=false}){return <View style={{flexDirection:'row',gap:tokens.space,alignItems:'flex-end'}}><View style={{flex:1}}><Input label={label} value={value} onChange={onChange} placeholder={placeholder} disabled={disabled||loading} returnKeyType="search" onSubmitEditing={()=>{if(!disabled&&!loading)onSearch?.(value);}}/></View><Button icon="search" label="Buscar" disabled={disabled} loading={loading} onPress={()=>onSearch?.(value)}/></View>;}
