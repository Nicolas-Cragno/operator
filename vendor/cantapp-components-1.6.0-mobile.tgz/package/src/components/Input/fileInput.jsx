import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, Image } from 'react-native';
import Button from '../Button/button';
import { ProgressIndicator } from '../Functional/states';
import { useCantappTheme } from '../../theme/themeContext';
// Selection/capture adapters belong to the host app, including permissions.
export default function FileInput({ label = 'Adjuntos', files = [], onPick, onCapture, onChange, onRemove, onError, disabled = false, loading = false, required = false, error: externalError }) {
  const t = useCantappTheme(); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const pick = async adapter => {
    if (busy || loading || disabled || !adapter) return;
    setBusy(true); setError('');
    try { const result = await adapter(); if (result && !result.canceled) { const selected = result.assets || (Array.isArray(result) ? result : [result]); onChange?.([...files, ...selected]); } }
    catch (e) { setError(e.message || 'No se pudo seleccionar el archivo.'); onError?.(e); }
    finally { setBusy(false); }
  };
  return <View style={{ gap: 12 }}><Text style={{ color: t.special }}>{label}{required?' - Obligatorio':''}</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap:tokens.space }}><Button label="Seleccionar archivos" disabled={disabled || !onPick} loading={busy || loading} onPress={() => pick(onPick)} />{onCapture && <Button label="Tomar fotografía" variant="outline" disabled={disabled || busy || loading} onPress={() => pick(onCapture)} />}</View>{!files.length && <Text style={{ color: t.muted }}>Sin adjuntos</Text>}{files.map((file, index) => <View key={file.id || file.uri || index} style={{ padding: 12, gap:tokens.space, borderWidth: 1, borderColor: t.border, borderRadius:tokens.radius }}><Text style={{ color: t.text }}>{file.name || file.fileName || `Archivo ${index + 1}`}</Text>{file.uri && /^image\//.test(file.mimeType || file.type || '') && <Image source={{ uri: file.uri }} accessibilityLabel={file.name || 'Vista previa'} resizeMode="contain" style={{ width: '100%', height: 160 }} />}{file.progress != null && <ProgressIndicator value={file.progress} label="Subida" />}{file.error && <Text accessibilityRole="alert" style={{ color: t.danger }}>{file.error}</Text>}<Button label="Quitar adjunto" variant="outline" disabled={disabled || busy || loading} onPress={() => { onRemove?.(file, index); onChange?.(files.filter((_, i) => i !== index)); }} /></View>)}{(externalError||error) && <Text accessibilityRole="alert" style={{ color: t.danger }}>{externalError||error}</Text>}</View>;
}
