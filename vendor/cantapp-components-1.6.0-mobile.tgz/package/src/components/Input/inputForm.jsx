import React from 'react';
import Input from './input';
function InputForm(props) { return <Input label='Campo de formulario' {...props} />; }
export default InputForm;
