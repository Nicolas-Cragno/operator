import React from 'react';
import Input from './input';
function TextArea(props) { return <Input label='Observaciones' multiline {...props} />; }
export default TextArea;
