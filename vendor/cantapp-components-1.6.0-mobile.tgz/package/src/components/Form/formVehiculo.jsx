import React from 'react';
import FormStandard from './formStandard';
import { vehiculo } from '../../data/examples';
function FormVehiculo({ data = vehiculo, fields = [{ key: 'interno', label: 'Interno', type: 'text', valueType: 'string' }, { key: 'dominio', label: 'Dominio', type: 'text', valueType: 'string' }, { key: 'tipo', label: 'Tipo', type: 'select', options: [{ label: 'Tractor', value: 'TRACTOR' }, { label: 'Furgón', value: 'FURGON' }, { label: 'Vehículo', value: 'VEHICULO' }] }], ...props }) { return <FormStandard title="FormVehiculo" data={data} fields={fields} {...props} />; }
export default FormVehiculo;
