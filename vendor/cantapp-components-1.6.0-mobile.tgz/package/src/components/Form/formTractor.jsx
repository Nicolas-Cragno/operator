import React from 'react';
import FormStandard from './formStandard';
import { tractor } from '../../data/examples';
function FormTractor({ data = tractor, fields = [{ key: 'interno', label: 'Interno', type: 'text', valueType: 'string' }, { key: 'dominio', label: 'Dominio', type: 'text', valueType: 'string' }, { key: 'marca', label: 'Marca', type: 'select', options: [{ label: 'Scania', value: 'SCANIA' }, { label: 'Mercedes-Benz', value: 'MERCEDES' }, { label: 'Iveco', value: 'IVECO' }] }, { key: 'estado', label: 'Estado', type: 'select', options: [{ label: 'Activo', value: 'ACTIVO' }, { label: 'Inactivo', value: 'INACTIVO' }] }], ...props }) { return <FormStandard title="FormTractor" data={data} fields={fields} {...props} />; }
export default FormTractor;
