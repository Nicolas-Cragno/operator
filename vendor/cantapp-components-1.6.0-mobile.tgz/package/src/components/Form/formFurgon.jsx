import React from 'react';
import FormStandard from './formStandard';
import { furgon } from '../../data/examples';
function FormFurgon({ data = furgon, fields = [{ key: 'interno', label: 'Interno', type: 'text', valueType: 'string' }, { key: 'dominio', label: 'Dominio', type: 'text', valueType: 'string' }, { key: 'tipo', label: 'Tipo', type: 'select', options: [{ label: 'Tractor', value: 'TRACTOR' }, { label: 'Furgón', value: 'FURGON' }, { label: 'Vehículo', value: 'VEHICULO' }] }, { key: 'estado', label: 'Estado', type: 'select', options: [{ label: 'Activo', value: 'ACTIVO' }, { label: 'Inactivo', value: 'INACTIVO' }] }], ...props }) { return <FormStandard title="FormFurgon" data={data} fields={fields} {...props} />; }
export default FormFurgon;
