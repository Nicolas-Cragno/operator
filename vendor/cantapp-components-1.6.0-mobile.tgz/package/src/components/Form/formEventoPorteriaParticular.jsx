import React, { useMemo } from "react";
import FormStandard from "./formStandard";

function FormEventoPorteriaParticular({
  data = {},
  optionsByField = {},
  onSubmit,
  onCancel,
  loading = false,
}) {
  const initialData = useMemo(() => ({ ...data, area: "porteria" }), [data]);
  const sections = useMemo(
    () => [
      {
        title: "Movimiento",
        fields: [
          {
            key: "tipo",
            label: "Tipo",
            type: "select",
            required: true,
            options: [
              { label: "ENTRADA", value: "ENTRADA" },
              { label: "SALIDA", value: "SALIDA" },
            ],
          },
          {
            key: "operador",
            label: "Operador",
            type: "searchSelect",
            required: true,
          },
          {
            key: "persona",
            label: "Persona",
            type: "searchSelect",
            required: true,
          },
          { key: "vehiculo", label: "Vehículo", type: "searchSelect" },
          { key: "detalle", label: "Detalle", type: "textarea" },
        ],
      },
    ],
    [],
  );
  const handleSubmit = (values) =>
    onSubmit?.({
      ...values,
      area: "porteria",
      formulario: "movPorteriaParticular",
    });

  return (
    <FormStandard
      title="Portería · Particular"
      sections={sections}
      data={initialData}
      optionsByField={optionsByField}
      onSubmit={handleSubmit}
      onCancel={onCancel}
      loading={loading}
    />
  );
}

export default FormEventoPorteriaParticular;
