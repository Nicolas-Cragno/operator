import React from 'react';
import FormStandard from './formStandard';
import { asignacion } from '../../data/examples';
function FormAsignacion({ data = asignacion, fields = [{ key: 'persona', label: 'Persona', type: 'searchSelect', options: [{ label: 'ROSAS MEDINA, CLAUDIO HECTOR', value: '30123456' }, { label: 'GOMEZ, JORGE', value: '20123456' }] }, { key: 'articulo', label: 'Articulo', type: 'searchSelect', options: [{ label: 'Llave torx', value: 'ST-001' }, { label: 'Filtro de aceite', value: 'ST-002' }] }, { key: 'cantidad', label: 'Cantidad', type: 'number', valueType: 'number' }, { key: 'usuario', label: 'Usuario', type: 'searchSelect', options: [{ label: 'CRAGNO, NICOLAS LAUTARO', value: 'US-001' }, { label: 'Operador de ejemplo', value: 'US-002' }] }], ...props }) { return <FormStandard title="FormAsignacion" data={data} fields={fields} {...props} />; }
export default FormAsignacion;
