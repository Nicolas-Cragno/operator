import React from 'react';
import FormStandard from './formStandard';
import { cliente } from '../../data/examples';
function FormCliente({ data = cliente, fields = [{ key: 'nombre', label: 'Nombre', type: 'text', valueType: 'string' }, { key: 'cuit', label: 'Cuit', type: 'text', valueType: 'string' }, { key: 'estado', label: 'Estado', type: 'select', options: [{ label: 'Activo', value: 'ACTIVO' }, { label: 'Inactivo', value: 'INACTIVO' }] }], ...props }) { return <FormStandard title="FormCliente" data={data} fields={fields} {...props} />; }
export default FormCliente;
