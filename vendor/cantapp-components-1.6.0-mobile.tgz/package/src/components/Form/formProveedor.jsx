import React from 'react';
import FormStandard from './formStandard';
import { proveedor } from '../../data/examples';
function FormProveedor({ data = proveedor, fields = [{ key: 'nombre', label: 'Nombre', type: 'text', valueType: 'string' }, { key: 'cuit', label: 'Cuit', type: 'text', valueType: 'string' }, { key: 'telefono', label: 'Telefono', type: 'text', valueType: 'string' }], ...props }) { return <FormStandard title="FormProveedor" data={data} fields={fields} {...props} />; }
export default FormProveedor;
