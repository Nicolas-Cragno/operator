import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text } from 'react-native';
import Button from '../Button/button';
import ConfirmDialog from '../Modal/confirmModal';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
export function ValidationMessage({children}){const t=useCantappTheme();return children?<Text accessibilityRole="alert" style={{color:t.danger,fontFamily,fontSize:12}}>{children}</Text>:null;}
export function FormField({label,required,error,hint,children}){const t=useCantappTheme();return <View style={{gap:4}}><Text style={{color:t.text,fontFamily,fontSize:12}}>{label}{required?' · Obligatorio':''}</Text>{children}{hint&&<Text style={{color:t.muted,fontFamily,fontSize:12}}>{hint}</Text>}<ValidationMessage>{error}</ValidationMessage></View>;}
export function FormActions({onSubmit,onCancel,loading=false,disabled=false,submitLabel='Guardar'}){
 const [confirm,setConfirm]=useState(false);return <><View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}><Button label={submitLabel} disabled={disabled} loading={loading} onPress={()=>setConfirm(true)}/><Button label="Cancelar" variant="outline" onPress={onCancel} disabled={disabled||loading}/></View><ConfirmDialog visible={confirm} danger={false} title="Confirmar guardado" onClose={()=>setConfirm(false)} onConfirm={async()=>{await onSubmit?.();setConfirm(false);}}/></>;
}
export { default as FormSection } from '../Functional/formSection';
