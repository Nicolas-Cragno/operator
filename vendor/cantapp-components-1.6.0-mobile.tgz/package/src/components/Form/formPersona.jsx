import React from 'react';
import FormStandard from './formStandard';
import { persona } from '../../data/examples';
function FormPersona({ data = persona, fields = [{ key: 'id', label: 'Id', type: 'text', valueType: 'string' }, { key: 'nombre', label: 'Nombre', type: 'text', valueType: 'string' }, { key: 'dni', label: 'Dni', type: 'text', valueType: 'string' }, { key: 'telefono', label: 'Telefono', type: 'text', valueType: 'string' }, { key: 'estado', label: 'Estado', type: 'select', options: [{ label: 'Activo', value: 'ACTIVO' }, { label: 'Inactivo', value: 'INACTIVO' }] }, { key: 'sucursal', label: 'Sucursal', type: 'select', options: [{ label: 'Don Torcuato', value: '01' }, { label: 'Río Grande', value: '02' }] }], ...props }) { return <FormStandard title="FormPersona" data={data} fields={fields} {...props} />; }
export default FormPersona;
