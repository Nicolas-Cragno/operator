import React from 'react';
import { View, Text } from 'react-native';
import Select from '../Input/select';
import { NumberInput } from '../Input/controls';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';

export function validateArticleLines(value, { required = false, includeUnit = false, includeMoney = false, quantityRules = {} } = {}) {
  if (!Array.isArray(value) || (required && !value.length)) return 'Seleccioná al menos un artículo';
  if (value.length > 50) return 'Máximo 50 artículos';
  const ids = new Set();
  for (const item of value) {
    if (!item?.id) return 'Seleccioná el artículo de cada fila';
    if (ids.has(item.id)) return 'No repitas artículos';
    ids.add(item.id);
    if (!Number.isFinite(Number(item.cantidad)) || Number(item.cantidad) <= 0) return 'Las cantidades deben ser positivas';
    if (quantityRules.integerUnits?.includes(item.unidad) && !Number.isSafeInteger(Number(item.cantidad))) return `${item.unidad}: ingresá un entero positivo`;
    if (includeMoney && (!Number.isFinite(Number(item.valor ?? 0)) || Number(item.valor ?? 0) < 0)) return 'Precio inválido';
    if (includeUnit && !item.unidad) return 'El artículo debe tener una unidad vigente';
  }
  return '';
}

export default function ArticleLines({ label, value = [], onChange, disabled, options = [], includeUnit = false, includeMoney = false, currency = 'pesos' }) {
  const theme = useCantappTheme();
  const rows = Array.isArray(value) ? value : [];
  const update = (index, change) => onChange(rows.map((row, position) => position === index ? { ...row, ...change } : row));
  return <View style={{ gap: 12 }}>
    <Text style={{ color: theme.text, fontWeight: '600' }}>{label}</Text>
    {rows.map((row, index) => <View key={index} style={{ gap: 8, borderWidth: 1, borderColor: theme.border, padding: 12, borderRadius: 8 }}>
      <Select label={`Artículo ${index + 1}`} required disabled={disabled} value={row.id} options={options}
        onChange={id => update(index, { id, unidad: options.find(option => option.value === id)?.unidad || '' })} />
      <NumberInput label={`Cantidad ${index + 1}`} required disabled={disabled} value={row.cantidad} onChange={cantidad => update(index, { cantidad })} />
      {includeMoney && <NumberInput label={`Precio unitario ${index + 1} (${currency === 'dolares' ? 'USD' : 'ARS'})`} disabled={disabled} value={row.valor ?? 0} onChange={valor => update(index, { valor })} />}
      {includeUnit && <Text style={{ color: theme.text }}>Unidad: {row.unidad || 'Seleccioná un artículo'}</Text>}
      <Button label={`Quitar artículo ${index + 1}`} variant="outline" disabled={disabled} onPress={() => onChange(rows.filter((_, position) => position !== index))} />
    </View>)}
    <Button label="Agregar artículo" variant="outline" disabled={disabled || rows.length >= 50} onPress={() => onChange([...rows, { id: '', cantidad: '', ...(includeMoney ? { valor: 0 } : {}), ...(includeUnit ? { unidad: '' } : {}) }])} />
  </View>;
}
