import React from 'react';
import FormStandard from './formStandard';
import { stock } from '../../data/examples';
function FormStock({ data = stock, fields = [{ key: 'nombre', label: 'Nombre', type: 'text', valueType: 'string' }, { key: 'unidad', label: 'Unidad', type: 'select', options: [{ label: 'Unidad', value: 'un.' }, { label: 'Litros', value: 'lts.' }, { label: 'Kilogramos', value: 'kg.' }] }, { key: 'cantidad', label: 'Cantidad', type: 'number', valueType: 'number' }, { key: 'proveedor', label: 'Proveedor', type: 'searchSelect', options: [{ label: 'Proveedor ejemplo A', value: 'PV-001' }, { label: 'Proveedor ejemplo B', value: 'PV-002' }] }], ...props }) { return <FormStandard title="FormStock" data={data} fields={fields} {...props} />; }
export default FormStock;
