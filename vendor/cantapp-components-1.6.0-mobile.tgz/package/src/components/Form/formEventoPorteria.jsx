import React, { useMemo } from "react";
import FormStandard from "./formStandard";

const CHECKS = [
  ["ckAntivandalico", "Antivandálico"],
  ["ckCorte", "Corte"],
  ["ckDesenganche", "Desenganche"],
  ["ckPanico", "Pánico"],
  ["ckPuertaCabina", "Puerta cabina"],
  ["ckPuertaFurgon", "Puerta furgón"],
  ["ckReporte", "Reporte"],
];

const resourceIds = value => [].concat(value ?? []).filter(id => id != null && String(id).trim() !== "").map(id => String(id).trim());
const validateResources = values => !Array.isArray(values) || values.length > 4 || new Set(values).size !== values.length
  ? "Seleccioná hasta cuatro recursos sin repetir" : "";

function FormEventoPorteria({
  data = {},
  viajeProgramado = null,
  optionsByField = {},
  onSubmit,
  onCancel,
  loading = false,
}) {
  const initialData = useMemo(
    () => ({
      ...viajeProgramado,
      ...data,
      area: "porteria",
      tipo: data.tipo ?? (viajeProgramado ? "SALIDA" : undefined),
      tractor: resourceIds(data.tractor ?? viajeProgramado?.tractor),
      furgon: resourceIds(data.furgon ?? viajeProgramado?.furgon),
      chequeos: data.chequeos ?? [],
    }),
    [data, viajeProgramado],
  );

  const sections = useMemo(
    () => [
      {
        title: "Movimiento",
        fields: [
          {
            key: "tipo",
            label: "Tipo",
            type: "select",
            required: true,
            options: [
              { label: "ENTRADA", value: "ENTRADA" },
              { label: "SALIDA", value: "SALIDA" },
            ],
          },
          {
            key: "operador",
            label: "Operador",
            type: "searchSelect",
            required: true,
          },
          {
            key: "persona",
            label: "Chofer",
            type: "searchSelect",
            required: true,
          },
          {
            key: "tractor",
            label: "Tractores",
            type: "multiSelect",
            required: true,
            validate: validateResources,
          },
        ],
      },
      {
        title: "Carga",
        fields: [
          { key: "furgon", label: "Furgones / carga", type: "multiSelect", validate: validateResources },
          { key: "cliente", label: "Cliente", type: "searchSelect" },
          { key: "destino", label: "Destino", type: "searchSelect" },
          { key: "cargado", label: "Con carga", type: "switch" },
          { key: "detalle", label: "Detalle", type: "textarea" },
        ],
      },
      {
        title: "Chequeos",
        fields: [
          {
            key: "chequeos",
            label: "Chequeos",
            type: "multiSelect",
            options: CHECKS.map(([value, label]) => ({ value, label })),
          },
        ],
      },
    ],
    [],
  );

  const handleSubmit = (values) =>
    onSubmit?.({ ...values, tractor: resourceIds(values.tractor), furgon: resourceIds(values.furgon), area: "porteria", formulario: "movPorteria" });

  return (
    <FormStandard
      title="Evento de Portería"
      sections={sections}
      data={initialData}
      optionsByField={optionsByField}
      onSubmit={handleSubmit}
      onCancel={onCancel}
      loading={loading}
    />
  );
}

export default FormEventoPorteria;
