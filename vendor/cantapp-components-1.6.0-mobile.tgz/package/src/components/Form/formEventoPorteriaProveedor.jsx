import React, { useMemo } from "react";
import FormStandard from "./formStandard";

function FormEventoPorteriaProveedor({
  data = {},
  optionsByField = {},
  onSubmit,
  onCancel,
  loading = false,
}) {
  const initialData = useMemo(() => ({ ...data, area: "porteria" }), [data]);
  const sections = useMemo(
    () => [
      {
        title: "Movimiento",
        fields: [
          {
            key: "tipo",
            label: "Tipo",
            type: "select",
            required: true,
            options: [
              { label: "ENTRADA", value: "ENTRADA" },
              { label: "SALIDA", value: "SALIDA" },
            ],
          },
          {
            key: "operador",
            label: "Operador",
            type: "searchSelect",
            required: true,
          },
          {
            key: "destino",
            label: "Destino / sector",
            type: "searchSelect",
            required: true,
          },
          { key: "empresa", label: "Proveedor", type: "searchSelect" },
          { key: "persona", label: "Persona", type: "searchSelect" },
          { key: "vehiculo", label: "Vehículo", type: "searchSelect" },
          { key: "remito", label: "Remito", type: "text" },
          { key: "detalle", label: "Detalle", type: "textarea" },
        ],
      },
    ],
    [],
  );
  const handleSubmit = (values) =>
    onSubmit?.({
      ...values,
      area: "porteria",
      formulario: "movPorteriaProveedor",
    });

  return (
    <FormStandard
      title="Portería · Proveedor"
      sections={sections}
      data={initialData}
      optionsByField={optionsByField}
      onSubmit={handleSubmit}
      onCancel={onCancel}
      loading={loading}
    />
  );
}

export default FormEventoPorteriaProveedor;
