import React from "react";
import { View, Text } from "react-native";
import Modal from "./modal";
import Button from "../Button/button";
import { useCantappTheme } from "../../theme/themeContext";

function QROptionsModal({
  visible = false,
  onClose,
  opciones = [],
  onSelect,
  title = "Acciones del recurso",
}) {
  const theme = useCantappTheme();
  const handleSelect = (opcion) => {
    onClose?.();
    onSelect?.(opcion);
  };
  return (
    <Modal visible={visible} onClose={onClose} title={title}>
      <View style={{ gap: 12 }}>
        {opciones.length === 0 && (
          <Text style={{ color: theme.muted }}>
            No hay opciones disponibles.
          </Text>
        )}
        {opciones.map((opcion, index) => (
          <Button
            key={String(opcion.id ?? index)}
            label={opcion.title ?? opcion.label ?? "Abrir"}
            disabled={opcion.disabled}
            onPress={() => handleSelect(opcion)}
          />
        ))}
      </View>
    </Modal>
  );
}

export default QROptionsModal;
