import { tokens } from '../../theme/tokens';
import React from 'react';
import {View,Pressable,Text} from 'react-native';import Modal from './modal';
function ModalOptions({visible=false,onClose,title='Seleccionar formulario',options=[{label:'Persona',formType:'persona'},{label:'Tractor',formType:'tractor'}],onOpenForm}) {
 return <Modal visible={visible} onClose={onClose} title={title}><View style={{gap:tokens.space}}>{options.map((o,i)=><Pressable key={String(o.formType||i)} onPress={()=>{onOpenForm?.(o.formType,o);onClose?.()}} style={{backgroundColor:'#0d1f7f',padding:13,borderRadius:tokens.radius}}><Text style={{color:'#fff'}}>{o.label}</Text></Pressable>)}</View></Modal>;
}
export default ModalOptions;
