import { tokens } from '../../theme/tokens';
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, Platform, useWindowDimensions, ActivityIndicator } from 'react-native';
import { SafeAreaInsetsContext } from 'react-native-safe-area-context';
import Modal, { useModalSurface } from './modal';
import FloatingLayer from './floatingLayer';
import Button from '../Button/button';
import CloseButton from '../Button/closeButton';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
const ToastContext=createContext(null);
export function Toast({visible=true,title='Notificación',description,tone='info',onClose,duration=4000}){
 const t=useCantappTheme();const close=useRef(onClose);close.current=onClose;const [dismissed,setDismissed]=useState(false);
 useEffect(()=>{setDismissed(false);if(!visible||!duration)return undefined;const timer=setTimeout(()=>{setDismissed(true);close.current?.();},duration);return ()=>clearTimeout(timer);},[visible,duration]);
 return !visible||dismissed?null:<View accessibilityLiveRegion="polite" accessibilityRole={tone==='danger'?'alert':undefined} style={{backgroundColor:t.surface,borderWidth:1,borderColor:t[tone]||t.border,borderLeftWidth:4,borderRadius:tokens.radius,padding:12,width:'100%',maxWidth:360,gap:4,elevation:6}}><View style={{flexDirection:'row',alignItems:'center'}}><Text style={{color:t.text,fontFamily,fontWeight:'600',flex:1}}>{title}</Text><CloseButton onPress={onClose}/></View>{description&&<Text style={{color:t.muted,fontFamily}}>{description}</Text>}</View>;
}
export function ToastProvider({children}){
 const [messages,setMessages]=useState([]);const serial=useRef(0);const compact=useWindowDimensions().width<768;const insets=useContext(SafeAreaInsetsContext);
 const dismiss=id=>setMessages(old=>old.filter(message=>message.id!==id));
 const show=message=>{const id=++serial.current;setMessages(old=>[...old,{...(typeof message==='string'?{title:message}:message),id}].slice(-3));return id;};
 return <ToastContext.Provider value={{show,dismiss}}>{children}<View pointerEvents="box-none" style={{position:'absolute',top:(insets?.top||0)+16,right:16,left:compact?16:undefined,alignItems:compact?'center':'flex-end',gap:tokens.space,zIndex:10000}}>{messages.map(message=><Toast key={message.id} {...message} onClose={()=>dismiss(message.id)}/>)}</View></ToastContext.Provider>;
}
export function useToast(){const context=useContext(ToastContext);if(!context)throw new Error('useToast requiere ToastProvider o DesignSystemProvider.');return context;}
export function AlertDialog({visible=false,title='Información',description='',onClose,children}){const t=useCantappTheme();return <Modal visible={visible} title={title} onClose={onClose} footer={<Button label="Entendido" onPress={onClose}/>}><Text style={{fontFamily,color:t.text}}>{description}</Text>{children}</Modal>;}
export function Popover({open=false,onOpenChange,trigger,children,label='Opciones'}){
 const t=useCantappTheme();const surface=useModalSurface();const openChange=useRef(onOpenChange);openChange.current=onOpenChange;const anchor=useRef(null);const content=useRef(null);const {width,height}=useWindowDimensions();const [position,setPosition]=useState({x:16,y:60});
 useEffect(()=>{if(!open||Platform.OS!=='web')return undefined;
  const previous=document.activeElement;anchor.current?.measureInWindow?.((x,y,w,h)=>setPosition({x:Math.max(8,Math.min(x,width-288)),y:y+h+240>height?Math.max(8,y-240):y+h+4}));
  const frame=requestAnimationFrame(()=>content.current?.focus?.());
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();}};
  const release=e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();openChange.current?.(false);}};
  document.addEventListener('keydown',key,true);document.addEventListener('keyup',release,true);return ()=>{cancelAnimationFrame(frame);document.removeEventListener('keydown',key,true);document.removeEventListener('keyup',release,true);previous?.focus?.();};
 },[open,width,height]);
 return <><View ref={anchor}>{trigger}</View>{Platform.OS==='web'?open&&<FloatingLayer container={surface?.portalTarget?.current}><View style={{position:'fixed',top:0,right:0,left:0,bottom:0,zIndex:20000}}><Pressable accessibilityLabel="Cerrar opciones" onPress={()=>onOpenChange?.(false)} style={{position:'absolute',top:0,right:0,left:0,bottom:0}}/><View ref={content} tabIndex={-1} accessibilityLabel={label} style={{position:'absolute',left:position.x,top:position.y,width:280,maxHeight:Math.max(100,Math.min(320,height-position.y-8)),padding:8,backgroundColor:t.surface,borderWidth:1,borderColor:t.border,borderRadius:tokens.radius,elevation:6}}>{children}</View></View></FloatingLayer>:<Modal visible={open} title={label} onClose={()=>onOpenChange?.(false)}>{children}</Modal>}</>;
}
export function Tooltip({text='Ayuda',children}){
 const [open,setOpen]=useState(false);const t=useCantappTheme();
 return <View style={{position:'relative',alignSelf:'flex-start'}}><Pressable accessibilityLabel={text} onHoverIn={()=>setOpen(true)} onHoverOut={()=>setOpen(false)} onFocus={()=>setOpen(true)} onBlur={()=>setOpen(false)} onLongPress={()=>setOpen(true)} onPressOut={()=>{if(Platform.OS!=='web')setOpen(false);}}>{children||<Text style={{color:t.info,fontFamily}}>Ayuda</Text>}</Pressable>{open&&<View accessibilityRole="text" style={{position:'absolute',bottom:'100%',left:0,zIndex:100,padding:8,maxWidth:280,backgroundColor:t.text,borderRadius:tokens.radius}}><Text style={{fontFamily,color:t.surface}}>{text}</Text></View>}</View>;
}
export function LoadingOverlay({visible=false,label='Cargando…',children}){
 const t=useCantappTheme();return <View style={{position:'relative',minHeight:visible?100:undefined}}>{children}{visible&&<View accessibilityViewIsModal accessibilityLiveRegion="polite" style={{position:'absolute',top:0,left:0,right:0,bottom:0,alignItems:'center',justifyContent:'center',backgroundColor:'rgba(243,245,248,0.92)',zIndex:100}} onStartShouldSetResponder={()=>true}><ActivityIndicator color={t.primary}/><Text style={{fontFamily,color:t.text,marginTop:8}}>{label}</Text></View>}</View>;
}
