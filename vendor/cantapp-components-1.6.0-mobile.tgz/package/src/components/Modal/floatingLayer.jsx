import React from 'react';
import { View } from 'react-native';
export default function FloatingLayer({children}){return <View>{children}</View>;}
