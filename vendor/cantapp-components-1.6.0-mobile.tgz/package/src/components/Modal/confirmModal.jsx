import { tokens } from '../../theme/tokens';
import React, { useRef, useState } from 'react';
import Modal from './modal';
import { View, Text } from 'react-native';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
export default function ConfirmModal({title='Confirmar acción',description='¿Querés continuar?',onConfirm,onClose,loading=false,danger=true,confirmLabel='Confirmar',children,...props}){
 const t=useCantappTheme();const lock=useRef(false);const [working,setWorking]=useState(false);const [error,setError]=useState('');
 const execute=async()=>{if(lock.current||loading)return;lock.current=true;setWorking(true);setError('');try{await onConfirm?.();}catch(e){setError(e.message||'No se pudo completar la acción');}finally{lock.current=false;setWorking(false);}};
 const busy=loading||working;const footer=<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Cancelar" variant="outline" disabled={busy} onPress={onClose}/><Button label={confirmLabel} variant={danger?'danger':'primary'} loading={busy} onPress={execute}/></View>;
 return <Modal {...props} title={title} onClose={busy?undefined:onClose} closeOnBackdrop={!busy} footer={footer}><Text style={{color:t.text}}>{description}</Text>{children}{error&&<Text accessibilityRole="alert" style={{color:t.danger}}>{error}</Text>}</Modal>;
}
