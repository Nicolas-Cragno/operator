import { useCantappTheme } from '../../theme/themeContext';
import React,{useState} from 'react';
import {View,Text,Pressable,ScrollView} from 'react-native';
import Modal from './modal';import InputBusqueda from '../Input/inputBusqueda';
function ModalColeccion({visible=false,onClose,title='Seleccionar registro',items=[{id:'30123456',nombre:'ROSAS MEDINA, CLAUDIO HECTOR'},{id:'222',nombre:'Tractor 222'}],onOpenFicha,onSelect,fields}) { const t=useCantappTheme();
 const [query,setQuery]=useState('');const [active,setActive]=useState(['id','nombre']);
 const filtered=items.filter(item=>active.some(key=>String(item[key]??'').toLowerCase().includes(query.toLowerCase())));
 return <Modal visible={visible} onClose={onClose} title={title}><View style={{gap:10}}><InputBusqueda value={query} onChange={setQuery} fields={fields||[{key:'id',label:'ID'},{key:'nombre',label:'Nombre'}]} selectedFields={active} onFieldsChange={setActive}/><ScrollView style={{maxHeight:340}}>{filtered.map((item,i)=><Pressable key={String(item.id||i)} onPress={()=>{onSelect?.(item);onOpenFicha?.(item)}} style={{padding:11,borderBottomWidth:1,borderColor:t.border}}><Text style={{color:t.text}}>{item.nombre||item.descripcion||item.id}</Text></Pressable>)}</ScrollView></View></Modal>;
}
export default ModalColeccion;
