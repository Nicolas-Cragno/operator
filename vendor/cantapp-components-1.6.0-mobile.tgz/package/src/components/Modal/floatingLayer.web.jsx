import { createPortal } from 'react-dom';
export default function FloatingLayer({children,container}){return typeof document==='undefined'?null:createPortal(children,container||document.body);}
