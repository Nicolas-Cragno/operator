import { tokens } from '../../theme/tokens';
import React, { createContext, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { Modal as NativeModal, View, Text, ScrollView, Pressable, Platform, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import Button from '../Button/button';
import CloseButton from '../Button/closeButton';
import BackButton from '../Button/BackButton';
import { DetailField } from '../Data/dataValue';
const SurfaceContext=createContext(null);
let active=[]; const listeners=new Set();
function notify(){listeners.forEach(fn=>fn());}
function subscribe(fn){listeners.add(fn);return ()=>listeners.delete(fn);}
function snapshot(){return active[active.length-1] || null;}
export function useModalSurface(){return useContext(SurfaceContext);}
function Panel({title='Detalle',children,footer,data,fields,onClose,onEdit,onOpenForm,formType,dirty=false,closeOnBackdrop=true,requestRef,presentation,maxWidth=720,showBack=false,onBack}){
 const t=useCantappTheme(); const viewportWidth=useWindowDimensions().width; const compact=viewportWidth<768; const panel=useRef(null); const [overlay,setOverlay]=useState(null); const [customFooter,setFooter]=useState(null); const [formDirty,setDirty]=useState(false);
 const closeOverlay=()=>{if(overlay&&Object.hasOwn(overlay,'onClose')&&typeof overlay.onClose!=='function')return;overlay?.onClose?.();setOverlay(null);};
 const requestClose=()=>{if(dirty||formDirty){setOverlay({title:'Cambios sin guardar',content:<Text style={{color:t.text}}>Se perderán los cambios. ¿Querés cerrar?</Text>,footer:<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Seguir editando" variant="outline" onPress={()=>setOverlay(null)}/><Button label="Descartar cambios" variant="danger" onPress={()=>{setOverlay(null);onClose?.();}}/></View>});}else onClose?.();};
 const requestBack=()=>onBack&&!dirty&&!formDirty?onBack():requestClose(); if(requestRef)requestRef.current=overlay?closeOverlay:requestBack;
 const closeCurrent=useRef(requestClose);closeCurrent.current=requestClose;
 const surface=useMemo(()=>({replace:setOverlay,close:()=>setOverlay(null),requestClose:()=>closeCurrent.current?.(),setFooter,setDirty,portalTarget:panel}),[]);
 const overlayVisible=!!overlay;const overlayTitle=overlay?.title;const previousFocus=useRef(null);
 useEffect(()=>{if(Platform.OS!=='web'||typeof document==='undefined')return;if(overlayVisible){previousFocus.current=document.activeElement;panel.current?.focus?.();}else if(previousFocus.current?.isConnected){previousFocus.current.focus?.();previousFocus.current=null;}else panel.current?.focus?.();},[overlayVisible,overlayTitle]);
 return <SurfaceContext.Provider value={surface}><View style={{flex:1,justifyContent:'center',backgroundColor:'rgba(11,20,40,0.6)',padding:compact||presentation==='drawer'?0:24,...(Platform.OS==='web'?{backdropFilter:'blur(3px)'}:{})}}>
  <Pressable accessibilityLabel="Cerrar fondo del diálogo" disabled={!closeOnBackdrop||dirty||formDirty} onPress={overlay?closeOverlay:onClose} style={{position:'absolute',top:0,left:0,right:0,bottom:0}}/>
  <SafeAreaView ref={panel} edges={['top','bottom','left','right']} {...(Platform.OS==='web'?{tabIndex:-1,'aria-label':overlay?.title||title}:{})} accessibilityViewIsModal onAccessibilityEscape={overlay?closeOverlay:requestBack} style={{backgroundColor:t.surface,width:presentation==='drawer'?Math.min(320,Math.max(240,viewportWidth)):'100%',maxWidth:compact?undefined:maxWidth,maxHeight:compact||presentation==='drawer'?'100%':'92%',height:compact||presentation==='drawer'?'100%':undefined,alignSelf:presentation==='drawer'?'flex-end':'center',borderRadius:compact?0:4,borderWidth:compact?0:1,borderColor:t.border}}>
   <View style={{display:overlay?'none':'flex',flex:compact?1:undefined,maxHeight:compact?'100%':undefined,flexShrink:1}}>
    <View style={{minHeight:48,flexDirection:'row',alignItems:'center',paddingHorizontal:tokens.padding,borderBottomWidth:1,borderColor:t.border,gap:8}}>{showBack&&<BackButton disabled={!onClose&&!onBack} onPress={requestBack}/>}<Text accessibilityRole="header" style={{color:t.text,fontSize:20,fontFamily,fontWeight:'600',flex:1}}>{title}</Text><CloseButton disabled={!onClose} onPress={requestClose}/></View>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:tokens.padding,gap:12}} style={{flex:compact?1:undefined,flexShrink:1}}>{data&&(fields||Object.keys(data).map(key=>({key,label:key}))).map(field=><DetailField key={field.key} label={field.label} value={data[field.key]} type={field.type} render={field.render}/>)}{children}</ScrollView>
    {(customFooter||footer||onEdit||onOpenForm)&&<View style={{padding:tokens.padding,borderTopWidth:1,borderColor:t.border}}>{customFooter||footer}{(onEdit||onOpenForm)&&<Button label="Editar" onPress={()=>onEdit?onEdit(data):onOpenForm?.(formType,data)}/>}</View>}
   </View>
   {overlay&&<View style={{flex:compact?1:undefined,flexShrink:1}}><View style={{minHeight:48,paddingHorizontal:tokens.padding,flexDirection:'row',alignItems:'center',borderBottomWidth:1,borderColor:t.border,gap:8}}>{showBack&&<BackButton disabled={Object.hasOwn(overlay,'onClose')&&typeof overlay.onClose!=='function'} onPress={closeOverlay}/>}<Text accessibilityRole="header" style={{fontFamily,fontSize:20,color:t.text,flex:1}}>{overlay.title}</Text><CloseButton disabled={Object.hasOwn(overlay,'onClose')&&typeof overlay.onClose!=='function'} onPress={closeOverlay}/></View><ScrollView style={{flex:compact?1:undefined,flexShrink:1}} contentContainerStyle={{padding:tokens.padding,gap:12}}>{overlay.content}</ScrollView>{overlay.footer&&<View style={{padding:tokens.padding,borderTopWidth:1,borderColor:t.border}}>{overlay.footer}</View>}</View>}
  </SafeAreaView></View></SurfaceContext.Provider>;
}
export default function Modal({visible=false,onClose,title='Detalle',children,...props}){
 const {data,fields,onEdit,onOpenForm,formType,footer}=props;
 const parent=useContext(SurfaceContext); const id=useRef(Symbol('modal')); const top=useSyncExternalStore(subscribe,snapshot,()=>id.current);const request=useRef(onClose);
 useEffect(()=>{if(!visible||parent)return undefined;const key=id.current;active=[...active,key];notify();return ()=>{active=active.filter(item=>item!==key);notify();};},[visible,parent]);
 useEffect(()=>{if(visible&&parent){
  const content=<>{data&&(fields||Object.keys(data).map(key=>({key,label:key}))).map(field=><DetailField key={field.key} label={field.label} value={data[field.key]} type={field.type} render={field.render}/>)}{children}</>;
  const edit=(onEdit||onOpenForm)?<Button label="Editar" onPress={()=>onEdit?onEdit(data):onOpenForm?.(formType,data)}/>:null;
  parent.replace({title,content,footer:footer||edit,onClose});
 }},[visible,parent,children,footer,title,onClose,data,fields,onEdit,onOpenForm,formType]);
 useEffect(()=>{if(!visible||!parent)return undefined;return ()=>parent.replace(null);},[visible,parent]);

 if(parent)return null;
 return <NativeModal visible={visible&&top===id.current} transparent animationType="fade" onRequestClose={()=>request.current?.()}><Panel requestRef={request} {...props} title={title} onClose={onClose}>{children}</Panel></NativeModal>;
}
