import React from 'react';
import { View, Text, useWindowDimensions } from 'react-native';
import DataValue from './dataValue';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';

export default function RecordDetails({ data = {}, fields = [], event = false }) {
  const t = useCantappTheme();
  const compact = useWindowDimensions().width < 768;
  const secondary = field => ['secondary', 'relations'].includes(field.section);
  const groups = [fields.filter(field => !secondary(field)), fields.filter(secondary)];
  return <View style={{ flexDirection: compact ? 'column' : 'row', gap: 24, alignItems: 'flex-start' }}>
    {groups.map((group, index) => <View key={index} style={{ flex: compact ? undefined : 1, width: compact ? '100%' : undefined, minWidth: 0, gap: 8 }}>
      <Text accessibilityRole="header" style={{ color: t.special, fontFamily, fontSize: 16, fontWeight: '700' }}>{index ? event ? 'Información adicional' : 'Relaciones y registros' : 'Información principal'}</Text>
      {group.map(field => <View key={field.key} style={{ flexDirection: 'row', gap: 12, paddingVertical: 12 }}>
        <Text style={{ width: '36%', color: t.muted, fontFamily }}>{field.label || field.key}</Text>
        <View style={{ flex: 1, minWidth: 0 }}>{field.render ? field.render(data[field.key], data) : <DataValue value={field.value !== undefined ? field.value : data[field.key]} type={field.type} />}</View>
      </View>)}
      {!group.length && <Text style={{ color: t.muted, fontFamily, paddingVertical: 12 }}>{index ? 'Sin registros relacionados' : 'Sin datos'}</Text>}
    </View>)}
  </View>;
}
