import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text, Linking, Pressable } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import { formatValue, formatDate, toDate } from '../../utils/data';

export function DateValue({ value, withTime, timeZone }) { const t = useCantappTheme(); return <Text selectable style={{ color: t.text, fontFamily:dataFontFamily }}>{formatDate(value, { withTime, timeZone })}</Text>; }
export default function DataValue({ value, type, depth = 0, ancestors = [], onOpenReference }) {
  const t = useCantappTheme();
  if (type === 'date' || type === 'datetime' || toDate(value)) return <DateValue value={value} withTime={type === 'datetime'} />;
  const url = type === 'file' ? value?.url || value?.uri : value;
  if ((type === 'url' || type === 'file') && typeof url === 'string' && /^https?:\/\//i.test(url)) return <Pressable accessibilityRole="link" onPress={() => Linking.openURL(url)}><Text style={{ color: t.info, fontFamily, textDecorationLine: 'underline' }}>{value?.name || url}</Text></Pressable>;
  if (type === 'reference' && onOpenReference) return <Pressable accessibilityRole="button" onPress={() => onOpenReference(value)}><Text style={{ color: t.info, fontFamily }}>{value?.label || value?.path || formatValue(value)}</Text></Pressable>;
  if (value && typeof value === 'object' && depth < 6 && !ancestors.includes(value)) return <View style={{ gap: 6, flexShrink: 1 }}>{Object.entries(value).length ? Object.entries(value).map(([key, child]) => <View key={key} style={{ gap: 4, borderLeftWidth: 1, borderColor: t.border, paddingLeft: 8 }}><Text style={{ color: t.muted, fontFamily }}>{Array.isArray(value) ? `Elemento ${Number(key) + 1}` : key}</Text><DataValue value={child} depth={depth + 1} ancestors={[...ancestors, value]} onOpenReference={onOpenReference} /></View>) : <Text style={{ color: t.muted, fontFamily }}>Sin datos</Text>}</View>;
  return <Text selectable style={{ color: t.text, fontFamily:typeof value==='number'?dataFontFamily:fontFamily, flexShrink: 1 }}>{ancestors.includes(value) ? '[Referencia circular]' : formatValue(value)}</Text>;
}
export function DetailField({ label, value, type, render }) { const t = useCantappTheme(); return <View style={{ gap: 6, paddingVertical: 10, borderBottomWidth: 1, borderColor: t.border }}><Text style={{ color: t.muted, fontFamily }}>{label}</Text>{render ? render(value) : <DataValue value={value} type={type} />}</View>; }
export function DetailSection({ title, children }) { const t = useCantappTheme(); return <View style={{ gap:tokens.space }}><Text accessibilityRole="header" style={{ color: t.special, fontFamily, fontSize: 18, fontWeight: '700' }}>{title}</Text>{children}</View>; }
