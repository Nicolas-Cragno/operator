import React, { useEffect, useState } from 'react';
import { Text } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import styles from './styles/clock.styles';
function Clock() { const t = useCantappTheme(); const [now, setNow] = useState(new Date()); useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []); return <Text style={[styles.text, { color: t.colorA }]}>{now.toLocaleString('es-AR')}</Text>; }
export default Clock;
