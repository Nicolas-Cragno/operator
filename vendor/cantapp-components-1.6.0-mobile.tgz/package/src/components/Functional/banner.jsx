import { tokens } from '../../theme/tokens';
import React from 'react';
import {ImageBackground,Text,View} from 'react-native';
import {images} from '../../assets/images';
import styles from './styles/banner.styles';
function Banner({title='Recursos',subtitle='Gestión de flota',description, image=images.tractorDemo || images.tractor,backgroundImage=image,style}) {return <ImageBackground source={backgroundImage} imageStyle={{opacity:.65,borderRadius:tokens.radius}} style={[styles.root,{minHeight:150,justifyContent:'center'},style]}><View style={{padding:10}}><Text style={[styles.title,{fontSize:22}]}>{title}</Text><Text style={styles.text}>{description||subtitle}</Text></View></ImageBackground>;}
export default Banner;
