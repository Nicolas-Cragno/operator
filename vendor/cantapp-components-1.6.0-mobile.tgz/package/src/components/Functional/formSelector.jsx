import React from 'react';
import Banner from './banner';
function FormSelector({ title = 'Seleccionar formulario', description = '', ...props }) { return <Banner title={title} description={description} {...props} />; }
export default FormSelector;
