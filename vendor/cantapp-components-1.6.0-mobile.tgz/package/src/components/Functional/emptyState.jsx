import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
function EmptyState({ title = 'No hay registros', description = 'Probá cambiar los filtros.', children, style }) {
  const t = useCantappTheme();
  return <View accessibilityLiveRegion="polite" style={[{ padding: 24, gap:tokens.space, backgroundColor: t.surface, borderWidth: 1, borderColor: t.border, borderRadius:tokens.radius }, style]}><Text style={{ color: t.text, fontFamily, fontWeight: '700' }}>{title}</Text>{description ? <Text style={{ color: t.muted, fontFamily }}>{description}</Text> : null}{children}</View>;
}
export default EmptyState;
