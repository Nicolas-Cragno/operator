import React from 'react';
import Banner from './banner';
function FormHeader({ title = 'Datos generales', description = '', ...props }) { return <Banner title={title} description={description} {...props} />; }
export default FormHeader;
