import { useCantappTheme } from '../../theme/themeContext';
import React,{useEffect,useRef} from 'react';
import {Animated,View,Text,Easing} from 'react-native';
const logo=require('../../../assets/logos/logo.png');
function Loading({appLogo=logo,label='Cargando...'}) { const t=useCantappTheme();
 const spin=useRef(new Animated.Value(0)).current;const pulse=useRef(new Animated.Value(1)).current;
 useEffect(()=>{const a=Animated.loop(Animated.timing(spin,{toValue:1,duration:2300,easing:Easing.linear,useNativeDriver:true}));const b=Animated.loop(Animated.sequence([Animated.timing(pulse,{toValue:1.1,duration:750,useNativeDriver:true}),Animated.timing(pulse,{toValue:1,duration:750,useNativeDriver:true})]));a.start();b.start();return()=>{a.stop();b.stop()};},[spin,pulse]);
 return <View style={{alignItems:'center',justifyContent:'center',padding:20,gap:10}}><Animated.Image source={appLogo} resizeMode="contain" style={{width:70,height:70,transform:[{rotate:spin.interpolate({inputRange:[0,1],outputRange:['0deg','360deg']})},{scale:pulse}]}}/><Text style={{color:t.special}}>{label}</Text></View>;
}
export default Loading;
