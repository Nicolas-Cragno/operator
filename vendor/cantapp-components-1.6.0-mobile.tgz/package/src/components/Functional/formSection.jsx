import React from 'react';
import { DetailSection } from '../Data/dataValue';
import { Text } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
export default function FormSection({title='Secci?n del formulario',description,children}) { const t=useCantappTheme();return <DetailSection title={title}>{description&&<Text style={{color:t.muted}}>{description}</Text>}{children}</DetailSection>; }
