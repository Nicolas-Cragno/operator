import React, { useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, Animated, Easing, View } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { tokens } from '../../theme/tokens';
export default function IndeterminateTrack() {
  const t = useCantappTheme();
  const position = useRef(new Animated.Value(0)).current;
  const [width, setWidth] = useState(240);
  const [reduced, setReduced] = useState(true);
  useEffect(() => {
    let mounted = true;
    AccessibilityInfo.isReduceMotionEnabled().then(value => { if (mounted) setReduced(value); }).catch(() => {});
    const subscription = AccessibilityInfo.addEventListener('reduceMotionChanged', setReduced);
    return () => { mounted = false; subscription.remove(); };
  }, []);
  useEffect(() => {
    if (reduced) return undefined;
    position.setValue(0);
    const animation = Animated.loop(Animated.timing(position, { toValue: 1, duration: tokens.duration * 8, easing: Easing.linear, useNativeDriver: true, isInteraction: false }));
    animation.start();
    return () => animation.stop();
  }, [position, reduced]);
  return <View onLayout={event => setWidth(event.nativeEvent.layout.width)} style={{ height: 8, backgroundColor: t.border, borderRadius: tokens.radius, overflow: 'hidden' }}><Animated.View style={{ height: 8, width: '30%', backgroundColor: t.primary, transform: [{ translateX: reduced ? width * 0.35 : position.interpolate({ inputRange: [0, 1], outputRange: [-width * 0.3, width] }) }] }} /></View>;
}
