import React from 'react';
import Banner from './banner';
function FormList({ title = 'Elementos agregados', description = '', ...props }) { return <Banner title={title} description={description} {...props} />; }
export default FormList;
