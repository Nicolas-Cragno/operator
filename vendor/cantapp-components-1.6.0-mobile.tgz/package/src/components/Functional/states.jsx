import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import Button from '../Button/button';
import Icon from './icon';
import IndeterminateTrack from './indeterminateTrack';
export function StatusBadge({label='Pendiente',tone='info'}){const t=useCantappTheme();return <View style={{alignSelf:'flex-start',borderRadius:tokens.radius,backgroundColor:t[tone+'Bg']||t.hover,paddingVertical:4,paddingHorizontal:8}}><Text style={{fontFamily,fontSize:12,fontWeight:'600',color:t[tone+'Text']||t[tone]||t.info}}>{label}</Text></View>;}
export function Alert({title='Información',description,tone='info',children}){const t=useCantappTheme();return <View accessibilityRole={tone==='danger'?'alert':undefined} accessibilityLiveRegion="polite" style={{padding:tokens.padding,gap:tokens.space,borderRadius:tokens.radius,borderWidth:1,borderColor:t[tone]||t.border,backgroundColor:t[tone+'Bg']||t.surface}}><Text style={{fontFamily,color:t.text,fontWeight:'600'}}>{title}</Text>{description&&<Text style={{fontFamily,color:t.muted}}>{description}</Text>}{children}</View>;}
export { default as EmptyState } from './emptyState';
export function ErrorState({title='No se pudo completar la operación',description,onRetry}){return <Alert title={title} description={description} tone="danger">{onRetry&&<Button label="Reintentar" onPress={onRetry}/>}</Alert>;}
export function LoadingState({label='Cargando…'}){const t=useCantappTheme();return <View accessibilityLiveRegion="polite" style={{padding:24,gap:tokens.space,alignItems:'center'}}><ActivityIndicator color={t.primary}/><Text style={{fontFamily,color:t.text}}>{label}</Text></View>;}
export function ProgressIndicator({value=0,label='Progreso',indeterminate=false}){const t=useCantappTheme();const progress=Math.max(0,Math.min(100,Number(value)||0));return <View accessibilityRole="progressbar" accessibilityLabel={label} accessibilityValue={indeterminate?{text:'En curso'}:{min:0,max:100,now:progress}} style={{gap:6}}><Text style={{fontFamily,color:t.text}}>{label}{indeterminate?'…':': '+Math.round(progress)+'%'}</Text>{indeterminate?<IndeterminateTrack/>:<View style={{height:8,borderRadius:tokens.radius,overflow:'hidden',backgroundColor:t.border}}><View style={{height:8,width:`${progress}%`,backgroundColor:t.primary}}/></View>}</View>;}
export function Skeleton({height=100,width='100%'}){const t=useCantappTheme();return <View accessibilityLabel="Cargando contenido" style={{height,width,alignItems:'center',justifyContent:'center'}}><ActivityIndicator color={t.primary}/></View>;}
export function StatusIndicator({label='Activo',tone='success',icon='check'}){const t=useCantappTheme();return <View style={{flexDirection:'row',alignItems:'center',gap:tokens.space}}><Icon name={icon} color={t[tone]||t.info}/><Text style={{fontFamily,color:t.text}}>{label}</Text></View>;}
