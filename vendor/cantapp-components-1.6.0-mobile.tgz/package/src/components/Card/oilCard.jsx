import useComponentStyles from '../../theme/useComponentStyles';
import React from 'react';
import {View,Text,Pressable} from 'react-native';
import baseStyles from './styles/oilCard.styles';
function OilCard({date='2026-10-15',place='YPF Don Torcuato',lts=240,onClick,onDelete,style}) { const styles=useComponentStyles(baseStyles);const d=date instanceof Date?date.toLocaleDateString('es-AR'):String(date);return <View style={[styles.root,styles.row,style]}><View style={styles.column}><Text style={styles.title}>{d}</Text><Text style={styles.text}>{place||'-'} · {lts??'-'} lts.</Text></View><Pressable onPress={onDelete||onClick}><Text style={styles.title}>✕</Text></Pressable></View>;}
export default OilCard;
