import React from 'react';
import Card from './card';
function CardInfo({ title = 'CardInfo', subtitle = 'Registro de ejemplo', ...props }) { return <Card title={title} subtitle={subtitle} {...props} />; }
export default CardInfo;
