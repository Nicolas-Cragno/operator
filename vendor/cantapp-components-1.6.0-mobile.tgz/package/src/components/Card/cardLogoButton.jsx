import useComponentStyles from '../../theme/useComponentStyles';
import React from 'react';
import {View,Text,Image,Pressable} from 'react-native';
import {images} from '../../assets/images';
import baseStyles from './styles/cardLogoButton.styles';
function CardLogoButton({title='Elementos',logo=images.producto,onClick,onClickButton,onList,onAdd,addOn=true,style}) { const styles=useComponentStyles(baseStyles);return <View style={[styles.root,styles.row,style]}><Image source={logo} style={styles.image}/><View style={styles.column}><Text style={styles.title}>{title}</Text><View style={[styles.row,{flexWrap:'wrap'}]}><Pressable onPress={onList||onClick} style={styles.button}><Text style={styles.buttonText}>☰ Listado</Text></Pressable>{addOn&&<Pressable onPress={onAdd||onClickButton} style={styles.button}><Text style={styles.buttonText}>＋ Agregar</Text></Pressable>}</View></View></View>;}
export default CardLogoButton;
