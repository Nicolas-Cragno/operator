import React from 'react';
import Card from './card';
function ItemCard({ title = 'ItemCard', subtitle = 'Registro de ejemplo', ...props }) { return <Card title={title} subtitle={subtitle} {...props} />; }
export default ItemCard;
