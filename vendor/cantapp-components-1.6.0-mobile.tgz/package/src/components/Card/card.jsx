import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import styles from './styles/card.styles';
function Card({ title = 'Ficha de ejemplo', subtitle = 'Información de demostración', children, onPress, style }) {
 const t = useCantappTheme();
 const content = <View style={[styles.root, { backgroundColor: t.colorD, borderColor: t.colorE, borderWidth: 1, padding: 14, gap: 7 }, style]}>{title ? <Text style={[styles.text, { color: t.colorA, fontSize: 17, fontWeight: '700' }]}>{title}</Text> : null}{subtitle ? <Text style={[styles.text, { color: t.muted, fontSize: 12 }]}>{subtitle}</Text> : null}{children}</View>;
 return onPress ? <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={onPress}>{content}</Pressable> : content;
}
export default Card;
