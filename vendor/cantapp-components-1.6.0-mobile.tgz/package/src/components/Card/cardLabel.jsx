import React from 'react';
import { Text } from 'react-native';
import Card from './card';
import { useCantappTheme } from '../../theme/themeContext';
import { relaciones } from '../../data/examples';
import styles from './styles/cardLabel.styles';
function CardLabel({ relation = relaciones[0], onPress, style }) { const t = useCantappTheme(); return <Card title={relation.tipo?.toUpperCase() || 'RELACIÓN'} subtitle={relation.id || '-'} onPress={() => onPress?.(relation)} style={style}><Text style={[styles.text, { color: t.text, lineHeight: 21 }]}>{relation.label || '-'}</Text></Card>; }
export default CardLabel;
