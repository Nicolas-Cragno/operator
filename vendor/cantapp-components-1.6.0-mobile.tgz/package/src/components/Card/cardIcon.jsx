import useComponentStyles from '../../theme/useComponentStyles';
import React from 'react';
import {Pressable,Text,View} from 'react-native';
import baseStyles from './styles/cardIcon.styles';
function CardIcon({icon='▣',text='Ver recursos',onPress,onClick,style}) { const styles=useComponentStyles(baseStyles);return <Pressable accessibilityRole="button" accessibilityLabel={text} onPress={onPress||onClick} style={[styles.root,styles.row,style]}><View>{typeof icon==='string'?<Text style={[styles.title,{fontSize:28}]}>{icon}</Text>:icon}</View><Text style={styles.text}>{text}</Text></Pressable>;}
export default CardIcon;
