import useComponentStyles from '../../theme/useComponentStyles';
import React from 'react';
import {View,Text,Image,Pressable} from 'react-native';
import {images} from '../../assets/images';
import baseStyles from './styles/bigCard.styles';
function BigCard({title='Flota Don Torcuato',value1=120,value2=65,value3=82,logo=images.tractor,onPress,style}) { const styles=useComponentStyles(baseStyles);return <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={onPress} style={[styles.root,styles.row,style]}><Image source={logo} style={styles.image}/><View style={styles.column}><Text style={styles.title}>{title}</Text><Text style={styles.text}>♙ {value1} empleados</Text><Text style={styles.text}>▰ {value2} tractores</Text><Text style={styles.text}>▣ {value3} furgones</Text></View></Pressable>;}
export default BigCard;
