import React from 'react';
import Card from './card';
function CardButton({ title = 'CardButton', subtitle = 'Registro de ejemplo', ...props }) { return <Card title={title} subtitle={subtitle} {...props} />; }
export default CardButton;
