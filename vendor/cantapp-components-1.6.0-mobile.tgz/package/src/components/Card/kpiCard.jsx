import { tokens } from '../../theme/tokens';
import React from 'react';
import { Text, View } from 'react-native';
import Card from './card';
import Icon from '../Functional/icon';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
export default function KpiCard({title='Indicador',value=0,change,changeLabel='respecto al período anterior',children,...props}){
 const t=useCantappTheme();const direction=Number(change)>0?'↑':Number(change)<0?'↓':'→';const color=Number(change)>0?t.success:Number(change)<0?t.danger:t.muted;
 return <Card title={title} subtitle="" {...props}><Text style={{fontFamily:dataFontFamily,fontSize:28,color:t.text,fontWeight:'600'}}>{value}</Text>{change!=null&&<Text style={{fontFamily,fontSize:12,color}}>{direction} {Number(change)>0?'+':''}{change}% {changeLabel}</Text>}{children}</Card>;
}
export function StatCard({title='Indicador',value=0,icon,...props}){const t=useCantappTheme();return <Card title={title} subtitle="" {...props}><View style={{flexDirection:'row',gap:tokens.space,alignItems:'center'}}>{icon&&<Icon name={icon} color={t.primary}/>}<Text style={{fontFamily:dataFontFamily,fontSize:28,color:t.text}}>{value}</Text></View></Card>;}
