import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, Pressable, useWindowDimensions } from 'react-native';
import { BarChart, LineChart, PieChart } from 'react-native-gifted-charts';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { EmptyState } from '../Functional/states';
const colors=['#0d1f7f','#175cd3','#16794a','#a96808','#730f21'];
export default function ChartContainer({title='Gráfico',type='line',data=[],legend=[],onSelect,height=220}){
 const t=useCantappTheme();const compact=useWindowDimensions().width<768;const [width,setWidth]=useState(320);const [selected,setSelected]=useState(null);
 const normalized=data.map((item,index)=>({...item,value:Number(item.value)||0,color:item.color||colors[index%colors.length],onPress:()=>{setSelected(item);onSelect?.(item,index);}}));
 const tooltip=item=><View style={{padding:8,backgroundColor:t.surface,borderWidth:1,borderColor:t.border,borderRadius:tokens.radius}}><Text style={{fontFamily,color:t.text}}>{item?.label}: {item?.value}</Text></View>;
 const props={data:normalized,width:Math.max(120,width-(compact?64:200)),height,isAnimated:false,color:t.primary,frontColor:t.primary,xAxisColor:t.border,yAxisColor:t.border,xAxisLabelTextStyle:{color:t.muted},yAxisTextStyle:{color:t.muted}};
 return <View onLayout={event=>setWidth(event.nativeEvent.layout.width)} style={{padding:tokens.padding,gap:tokens.padding,borderWidth:1,borderColor:t.border,borderRadius:tokens.radius,backgroundColor:t.surface,overflow:'hidden'}}><Text accessibilityRole="header" style={{fontFamily,fontSize:16,color:t.text,fontWeight:'600'}}>{title}</Text><View style={{flexDirection:compact?'column':'row',gap:tokens.padding}}><View style={{flex:1,minWidth:0}}>{!data.length?<EmptyState/>:['pie','donut'].includes(type)?<PieChart data={normalized} donut={type==='donut'} radius={Math.max(50,Math.min(110,(width-100)/2))} focusOnPress showTooltip tooltipComponent={tooltip}/>:type==='bar'?<BarChart {...props} renderTooltip={tooltip}/>:<LineChart {...props} areaChart={type==='area'} pointerConfig={{pointerLabelComponent:items=>tooltip(items[0]),activatePointersOnLongPress:false}}/>}</View><View style={{gap:tokens.space,minWidth:compact?undefined:120}}>{(legend.length?legend:normalized).map((item,index)=><Pressable key={item.key||index} accessibilityRole="button" accessibilityLabel={`${item.label}: ${item.value??''}`} onPress={()=>{setSelected(item);onSelect?.(item,index);}} style={{flexDirection:'row',alignItems:'center',gap:tokens.space,minHeight:44}}><View style={{width:12,height:12,borderRadius:tokens.radius,backgroundColor:item.color||colors[index%colors.length]}}/><Text style={{fontFamily,color:t.muted}}>{item.label}</Text></Pressable>)}</View></View>{selected&&<Text accessibilityLiveRegion="polite" style={{color:t.text,fontFamily}}>{selected.label}: {selected.value}</Text>}</View>;
}
