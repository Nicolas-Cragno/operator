import useComponentStyles from '../../theme/useComponentStyles';
import React from 'react';
import { Pressable,Text,Image } from 'react-native';
import { images } from '../../assets/images';
import baseStyles from './styles/cardLogo.styles';
function CardLogo({ title='Tractores',logo=images.tractor,onPress,onClick,style }) { const styles=useComponentStyles(baseStyles); return <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={onPress||onClick} style={[styles.root,styles.row,style]}><Image source={logo} style={styles.image}/><Text style={styles.title}>{title}</Text></Pressable>; }
export default CardLogo;
