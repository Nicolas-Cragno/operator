import React from 'react';
import Card from './card';
function CardFooter({ title = 'CardFooter', subtitle = 'Registro de ejemplo', ...props }) { return <Card title={title} subtitle={subtitle} {...props} />; }
export default CardFooter;
