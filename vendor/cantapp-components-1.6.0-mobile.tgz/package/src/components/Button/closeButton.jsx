import React from 'react';
import Button from './button';
import Icon from '../Functional/icon';
export default function CloseButton({onPress,disabled=false,size=20,color}){return <Button iconOnly variant="ghost" accessibilityLabel="Cerrar" disabled={disabled} onPress={onPress} icon={<Icon name="close" size={Math.min(size,24)} color={color}/>}/>;}
