import React from 'react';
import { useCantappTheme } from '../../theme/themeContext';
import { controlHeight } from '../../theme/controls';
import Button from './button';
import { Tooltip } from '../Modal/notifications';

export default function NavigationIconButton({ label, Icon, onPress, loading = false, disabled = false }) {
  const theme = useCantappTheme();
  return <Tooltip text={label}>
    <Button accessibilityLabel={label} variant="ghost" iconOnly
      icon={<Icon size={18} strokeWidth={1.8} color={theme.muted} accessible={false} />}
      loading={loading} disabled={disabled || loading} accessibilityState={{ busy: loading }} onPress={onPress}
      style={{ alignSelf: 'flex-start', width: controlHeight, height: controlHeight, padding: 0 }} />
  </Tooltip>;
}
