import React from 'react';
import Button from './button';
function FullButton({ label = 'Continuar', onPress, ...props }) { return <Button label={label} variant="primary" onPress={onPress} {...props} />; }
export default FullButton;
