import React from "react";
import ArrowLeft from "lucide-react-native/icons/arrow-left";
import NavigationIconButton from "./NavigationIconButton";

export default function BackButton(props) {
  return <NavigationIconButton {...props} label="Volver" Icon={ArrowLeft} />;
}
