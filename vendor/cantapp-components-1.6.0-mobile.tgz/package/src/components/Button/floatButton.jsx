import React from "react";
import { Pressable, View } from "react-native";
import Icon from "../Functional/icon";
import { useCantappTheme } from "../../theme/themeContext";

function FloatButton({
  onPress,
  icon = "qr",
  disabled = false,
  bottom = 24,
  right = 20,
  accessibilityLabel = "Escanear QR",
}) {
  const theme = useCantappTheme();
  return (
    <View
      pointerEvents="box-none"
      style={{
        position: "absolute",
        bottom,
        right,
        zIndex: 1000,
        elevation: 12,
      }}
    >
      <Pressable
        onPress={onPress}
        disabled={disabled}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
        style={{
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: theme.primary,
          alignItems: "center",
          justifyContent: "center",
          opacity: disabled ? 0.5 : 1,
        }}
      >
        <Icon name={icon} size={25} color="#ffffff" />
      </Pressable>
    </View>
  );
}

export default FloatButton;
