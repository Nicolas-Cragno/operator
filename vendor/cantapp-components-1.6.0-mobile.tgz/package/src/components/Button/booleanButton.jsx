import React, { useState } from "react";
import Button from "./button";
function BooleanButton({
  value,
  onChange,
  trueLabel = "Desactivar",
  falseLabel = "Activar",
  ...props
}) {
  const [local, setLocal] = useState(false);
  const active = value === undefined ? local : !!value;
  return (
    <Button
      {...props}
      accessibilityState={{ selected: active }}
      label={active ? trueLabel : falseLabel}
      variant={active ? "primary" : "outline"}
      onPress={() => {
        if (value === undefined) setLocal(!active);
        onChange?.(!active);
      }}
    />
  );
}
export default BooleanButton;
