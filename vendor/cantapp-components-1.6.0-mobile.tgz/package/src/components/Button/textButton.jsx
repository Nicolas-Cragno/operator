import React from 'react';
import Button from './button';
function TextButton({ label = 'Ver detalle', onPress, ...props }) { return <Button label={label} variant="outline" onPress={onPress} {...props} />; }
export default TextButton;
