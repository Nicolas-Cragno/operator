import React from 'react';
import { useCantappTheme } from '../../theme/themeContext';
import {Pressable,Image,Text} from 'react-native';
import {images} from '../../assets/images';
import styles from './styles/logoButton.styles';
function LogoButton({logo=images.logo,image=logo,label='',onPress,onClick,disabled=false,style}) {const t=useCantappTheme();return <Pressable accessibilityRole="button" accessibilityLabel={label || "Abrir"} accessibilityState={{disabled}} disabled={disabled} onPress={onPress||onClick} style={[styles.root,styles.row,{backgroundColor:t.surface,borderColor:t.border,minHeight:44},style,{opacity:disabled?.5:1}]}><Image source={image} style={styles.image}/>{!!label&&<Text style={[styles.title,{color:t.special}]}>{label}</Text>}</Pressable>;}
export default LogoButton;
