import React from 'react';
import Button from './button';
export default function AccessButton({label='Abrir',onPress,allowed=true,disabled=false,icon='access',...props}){return <Button {...props} label={label} icon={icon} disabled={disabled||!allowed} onPress={onPress}/>;}
