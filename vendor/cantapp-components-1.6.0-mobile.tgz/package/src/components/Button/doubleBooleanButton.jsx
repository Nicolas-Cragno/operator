import React, { useState } from 'react';
import { View } from 'react-native';
import Button from './button';
function DoubleBooleanButton({ value, onChange, options = [{ label: 'Opción A', value: 'A' }, { label: 'Opción B', value: 'B' }], trueLabel, falseLabel, disabled=false }) {
 const [local, setLocal] = useState(options[0]?.value);
 const selected = value === undefined ? local : value;
 const items = trueLabel && falseLabel ? [{label:falseLabel,value:false},{label:trueLabel,value:true}] : options;
 return <View style={{flexDirection:'row',gap:4}}>{items.map(o => <View key={String(o.value)} style={{flex:1}}><Button disabled={disabled} accessibilityState={{selected:selected===o.value}} label={o.label} variant={selected === o.value ? 'primary' : 'outline'} onPress={() => {if(value === undefined)setLocal(o.value);onChange?.(o.value);}} /></View>)}</View>;
}
export default DoubleBooleanButton;
