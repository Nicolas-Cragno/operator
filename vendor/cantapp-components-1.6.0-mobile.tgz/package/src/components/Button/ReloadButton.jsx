import React from 'react';
import RotateCcw from 'lucide-react-native/icons/rotate-ccw';
import NavigationIconButton from './NavigationIconButton';

export default function ReloadButton(props) {
  return <NavigationIconButton {...props} label="Actualizar" Icon={RotateCcw} />;
}
