import React from 'react';
import { useCantappTheme } from '../../theme/themeContext';
import {Pressable,Image,Text} from 'react-native';
import {images} from '../../assets/images';
import styles from './styles/imgButton.styles';
function ImgButton({image=images.tractor,logo=image,label='Tractores',onPress,onClick,disabled=false,style}) {const t=useCantappTheme();return <Pressable accessibilityRole="button" accessibilityLabel={label || "Abrir"} accessibilityState={{disabled}} disabled={disabled} onPress={onPress||onClick} style={[styles.root,styles.row,{backgroundColor:t.surface,borderColor:t.border,minHeight:44},style,{opacity:disabled?.5:1}]}><Image source={logo} style={styles.image}/><Text style={[styles.title,{color:t.special}]}>{label}</Text></Pressable>;}
export default ImgButton;
