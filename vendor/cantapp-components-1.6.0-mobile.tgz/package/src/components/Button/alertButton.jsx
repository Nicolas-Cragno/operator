import React from 'react';
import Button from './button';
function AlertButton({ label = 'Advertencia', onPress, ...props }) { return <Button label={label} variant="danger" onPress={onPress} {...props} />; }
export default AlertButton;
