import React, { useState } from 'react';
import Button from './button';
import Icon from '../Functional/icon';
import ConfirmDialog from '../Modal/confirmModal';
import { useCantappTheme } from '../../theme/themeContext';
export default function DeleteButton({onPress,disabled=false,size=18,color,confirmationTitle='Eliminar registro',confirmationDescription='Esta acción no se puede deshacer.',...props}){
 const t=useCantappTheme();const [open,setOpen]=useState(false);
 return <><Button {...props} iconOnly variant="ghost" accessibilityLabel="Eliminar" disabled={disabled} onPress={()=>setOpen(true)} icon={<Icon name="delete" size={Math.min(size,24)} color={color||t.danger}/>}/><ConfirmDialog visible={open} title={confirmationTitle} description={confirmationDescription} onClose={()=>setOpen(false)} onConfirm={async()=>{await onPress?.();setOpen(false);}}/></>;
}
