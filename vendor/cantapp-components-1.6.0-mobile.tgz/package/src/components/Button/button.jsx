import { tokens } from '../../theme/tokens';
import React, { useRef, useState } from 'react';
import { Pressable, Text, ActivityIndicator, View } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
import { controlHeight, focusStyle } from '../../theme/controls';
import Icon from '../Functional/icon';
export default function Button({ label, text, onPress, disabled = false, loading = false, variant = 'primary', icon, iconOnly = false, style, children, accessibilityLabel, accessibilityState, accessibilityRole='button', onError, ...props }) {
 const t=useCantappTheme(); const lock=useRef(false); const [busy,setBusy]=useState(false);const [actionError,setActionError]=useState(''); const [focused,setFocused]=useState(false);
 const primary=variant==='primary', danger=variant==='danger';
 const bg=primary?t.primary:danger?t.danger:variant==='secondary'?t.selection || t.hover:'transparent';
 const fg=primary||danger?'#ffffff':t.primary;
 const execute=async event=>{if(lock.current||disabled||loading)return;lock.current=true;setActionError('');try{const result=onPress?.(event);if(result?.then){setBusy(true);await result;}}catch(error){setActionError(error.message||'No se pudo completar la acción');onError?.(error);}finally{lock.current=false;setBusy(false);}};
 const name=accessibilityLabel || label || text || (typeof children==='string'?children:undefined);
 return <><Pressable {...props} accessibilityRole={accessibilityRole} accessibilityLabel={name} accessibilityState={{...accessibilityState,disabled:disabled||loading||busy,busy:loading||busy}} disabled={disabled||loading||busy} onFocus={()=>setFocused(true)} onBlur={()=>setFocused(false)} onPress={execute} style={({pressed,hovered})=>[{minHeight:controlHeight,minWidth:iconOnly?controlHeight:undefined,borderRadius:tokens.radius,paddingHorizontal:iconOnly?8:16,paddingVertical:6,backgroundColor:hovered&&variant==='ghost'?t.hover:primary&&hovered?t.primaryHover || t.primary:bg,borderWidth:1,borderColor:variant==='outline'?t.border:'transparent',opacity:disabled?0.45:pressed?0.8:1,alignItems:'center',justifyContent:'center'},focused&&focusStyle(t.focus),style]}>
  {loading||busy?<ActivityIndicator color={fg}/>:<View style={{flexDirection:'row',gap:tokens.space,alignItems:'center'}}>{icon&&(typeof icon==='string'?<Icon name={icon} color={fg}/>:icon)}{!iconOnly&&<Text style={{fontFamily,fontSize:14,color:fg,fontWeight:'600'}}>{children??label??text??'Guardar'}</Text>}</View>}
 </Pressable>{actionError&&<Text accessibilityRole="alert" style={{fontFamily,color:t.danger,fontSize:12}}>{actionError}</Text>}</>;
}
