import { SafeAreaInsetsContext } from 'react-native-safe-area-context';
import React, { useContext, useState } from 'react';
import { View, Platform } from 'react-native';
import Button from './button';
import { Popover } from '../Modal/notifications';
export function IconButton({label='Acción',icon='plus',...props}){return <Button variant="ghost" {...props} iconOnly accessibilityLabel={props.accessibilityLabel||label} icon={icon}/>;}
export function SplitButton({label='Guardar',onPress,options=[],disabled=false,loading=false}){const [open,setOpen]=useState(false);return <View style={{flexDirection:'row',gap:1,alignSelf:'flex-start'}}><Button label={label} onPress={onPress} disabled={disabled} loading={loading}/><Popover open={open} onOpenChange={setOpen} trigger={<Button iconOnly icon="down" accessibilityLabel="Más acciones" disabled={disabled||loading} onPress={()=>setOpen(v=>!v)}/>}>{options.map((option,i)=><Button key={option.key||i} variant="ghost" label={option.label} disabled={option.disabled} onPress={async()=>{setOpen(false);await option.onPress?.();}}/>)}</Popover></View>;}
export function FloatingActionButton({label='Agregar',icon='plus',onPress,showOnWeb=false,...props}){const insets=useContext(SafeAreaInsetsContext);return Platform.OS==='web'&&!showOnWeb?null:<Button {...props} accessibilityLabel={label} iconOnly icon={icon} onPress={onPress} style={{width:48,height:48,position:'absolute',right:16,bottom:24+(insets?.bottom||0),elevation:4}}/>;}
