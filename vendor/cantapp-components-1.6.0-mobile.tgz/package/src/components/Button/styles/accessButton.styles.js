import { fontFamily } from '../../../theme/typography';
import { StyleSheet } from 'react-native';
export default StyleSheet.create({ root: { borderRadius: 4 }, text: { fontFamily } });
