import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text } from 'react-native';
import { toDate, formatDate, formatValue } from '../../utils/data';
import DataValue from '../Data/dataValue';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import { EmptyState } from '../Functional/states';
export function Timeline({items=[],dateKey='date',renderItem}){
 const t=useCantappTheme();const sorted=[...items].sort((a,b)=>(toDate(b[dateKey],true)?.getTime()??-Infinity)-(toDate(a[dateKey],true)?.getTime()??-Infinity));
 return <View style={{gap:tokens.padding}}>{sorted.length?sorted.map((item,index)=><View key={item.id||index} style={{paddingLeft:16,borderLeftWidth:2,borderColor:t.border,gap:tokens.space}}><Text style={{fontFamily:dataFontFamily,fontSize:12,color:t.muted}}>{formatDate(item[dateKey],{withTime:true})}</Text>{renderItem?renderItem(item):<><Text style={{fontFamily,color:t.text,fontWeight:'600'}}>{item.title||item.operation}</Text>{item.description&&<Text style={{fontFamily,color:t.muted}}>{item.description}</Text>}</>}</View>):<EmptyState/>}</View>;
}
export function AuditHistory({items=[]}){const t=useCantappTheme();return <Timeline items={items} renderItem={item=><View style={{gap:tokens.space}}><Text style={{fontFamily,color:t.text}}>{formatValue(item.user?.name||item.user?.nombre||item.user)||'Usuario no disponible'} · {item.operation||'Operación'}</Text>{Object.entries(item.changes||{}).map(([key,change])=><View key={key} style={{gap:4}}><Text style={{fontFamily,color:t.muted}}>{key}</Text><Text style={{color:t.muted}}>Anterior</Text><DataValue value={change.before}/><Text style={{color:t.muted}}>Nuevo</Text><DataValue value={change.after}/></View>)}</View>}/>;}
