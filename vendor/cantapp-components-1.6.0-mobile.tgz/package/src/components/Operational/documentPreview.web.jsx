import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text, Image, Linking } from 'react-native';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
export default function DocumentPreview({file,onOpen,onShare}){
 const t=useCantappTheme();const raw=file?.uri||file?.url||'';const uri=/^(https?:|blob:|data:image\/)/i.test(raw)?raw:null;const image=/^image\//.test(file?.mimeType||file?.type||'')||/\.(png|jpe?g|webp)(\?|$)/i.test(uri||'');const pdf=file?.mimeType==='application/pdf'||/\.pdf(\?|$)/i.test(uri||'');
 return <View style={{gap:12}}><Text style={{color:t.text}}>{file?.name||'Documento'}</Text>{uri&&image?<Image source={{uri}} accessibilityLabel={file?.name||'Vista previa'} resizeMode="contain" style={{width:'100%',height:320}}/>:uri&&pdf?<iframe title={file?.name||'Vista previa PDF'} src={uri} sandbox="allow-same-origin" referrerPolicy="no-referrer" style={{width:'100%',height:420,border:0}}/>:<Text style={{color:t.muted}}>Vista previa no disponible para este formato.</Text>}<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Abrir" icon="external" disabled={!uri} onPress={()=>onOpen?onOpen(file):Linking.openURL(uri)}/><Button label="Compartir" variant="outline" icon="share" disabled={!uri} onPress={()=>onShare?onShare(file):globalThis.navigator?.share?globalThis.navigator.share({title:file?.name,url:uri}):Linking.openURL(uri)}/></View></View>;
}
