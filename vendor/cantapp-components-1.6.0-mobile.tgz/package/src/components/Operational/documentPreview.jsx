import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text, Image, Linking, Share } from 'react-native';
import * as Sharing from 'expo-sharing';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
export function documentUri(file){const uri=file?.uri||file?.url||'';return /^(https?:|file:|content:|blob:|data:image\/)/i.test(uri)?uri:null;}
export default function DocumentPreview({file,onOpen,onShare}){
 const t=useCantappTheme();const uri=documentUri(file);const image=/^image\//.test(file?.mimeType||file?.type||'')||/\.(png|jpe?g|webp)(\?|$)/i.test(uri||'');
 return <View style={{gap:12}}><Text style={{color:t.text}}>{file?.name||'Documento'}</Text>{uri&&image?<Image source={{uri}} accessibilityLabel={file?.name||'Vista previa'} resizeMode="contain" style={{width:'100%',height:320}}/>:<Text style={{color:t.muted}}>El PDF se abre con el visor disponible en el dispositivo.</Text>}<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Abrir" icon="external" disabled={!uri} onPress={()=>onOpen?onOpen(file):Linking.openURL(uri)}/><Button label="Compartir" icon="share" variant="outline" disabled={!uri} onPress={async()=>{if(onShare)return onShare(file);if(await Sharing.isAvailableAsync()&&/^file:/.test(uri))return Sharing.shareAsync(uri);return Share.share({message:uri,url:uri});}}/></View></View>;
}
