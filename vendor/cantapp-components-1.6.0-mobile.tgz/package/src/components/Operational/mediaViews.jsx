import { tokens } from '../../theme/tokens';
import React, { useRef, useState } from 'react';
import { View, Text, Image, Share } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import FileInput from '../Input/fileInput';
import Button from '../Button/button';
import { ErrorState } from '../Functional/states';
import { capturePhoto, pickImage } from './media';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import DocumentPreview from './documentPreview';
export function ImageUpload({onPick,onCapture,...props}){return <FileInput {...props} label={props.label||'Imágenes'} onPick={onPick||pickImage} onCapture={onCapture||capturePhoto}/>;}
export function QRViewer({value='',identifier=value,onShare,onDownload,onPrint,downloadLabel='Descargar PNG',size=180}){
 const t=useCantappTheme();const qr=useRef(null);const lock=useRef(false);
 const [busy,setBusy]=useState(false);const [error,setError]=useState('');
 const run=async(action)=>{
  if(lock.current)return;lock.current=true;setBusy(true);setError('');
  try{
   if(!action){await Share.share({message:String(value)});return;}
   if(!qr.current?.toDataURL)throw new Error('El QR todavía no está listo');
   const data=await new Promise((resolve,reject)=>{
    const timeout=setTimeout(()=>reject(new Error('No se pudo generar la imagen QR')),10000);
    try{qr.current.toDataURL(result=>{clearTimeout(timeout);resolve(result);});}
    catch(cause){clearTimeout(timeout);reject(cause);}
   });
   await action({value,identifier,dataUrl:'data:image/png;base64,'+data});
  }catch(cause){setError(cause.message||'No se pudo exportar el QR');}
  finally{lock.current=false;setBusy(false);}
 };
 return <View style={{gap:12,alignItems:'center'}}>
  {value?<View accessibilityLabel={`Código QR: ${identifier}`} style={{backgroundColor:'#ffffff',padding:tokens.padding,borderRadius:tokens.radius}}><QRCode value={String(value)} size={size} color="#172033" backgroundColor="#ffffff" getRef={ref=>{qr.current=ref;}}/></View>:<Text style={{fontFamily,color:t.muted}}>Sin código para mostrar</Text>}
  <Text selectable style={{fontFamily:dataFontFamily,color:t.text}}>{identifier}</Text>
  <View style={{flexDirection:'row',flexWrap:'wrap',justifyContent:'center',gap:12}}>
   <Button icon="share" label="Compartir" disabled={!value||busy} onPress={()=>run(onShare)}/>
   {!!onDownload&&<Button label={downloadLabel} variant="outline" disabled={!value||busy} onPress={()=>run(onDownload)}/>}
   {!!onPrint&&<Button label="Imprimir" variant="outline" disabled={!value||busy} onPress={()=>run(onPrint)}/>}
  </View>
  {!!error&&<ErrorState description={error}/>}
 </View>;
}
export function PhotoCapture({onUse,onError,onCapture=capturePhoto,onGallery=pickImage,disabled=false}){
 const t=useCantappTheme();const [photo,setPhoto]=useState(null);const [error,setError]=useState('');
 const select=async adapter=>{setError('');try{const result=await adapter();if(result&&!result.canceled)setPhoto(result.assets?.[0]||result);}catch(e){setError(e.message);onError?.(e);}};
 return <View style={{gap:12}}>{photo?<><Image source={{uri:photo.uri}} accessibilityLabel="Foto seleccionada" resizeMode="contain" style={{width:'100%',height:260}}/><View style={{flexDirection:'row',gap:tokens.space}}><Button label="Usar foto" disabled={disabled} onPress={async()=>{await onUse?.(photo);setPhoto(null);}}/><Button label="Repetir" variant="outline" disabled={disabled} onPress={()=>setPhoto(null)}/></View></>:<View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}><Button icon="camera" label="Cámara" disabled={disabled} onPress={()=>select(onCapture)}/><Button icon="upload" label="Galería" variant="outline" disabled={disabled} onPress={()=>select(onGallery)}/></View>}{error&&<ErrorState description={error}/>}<Text style={{fontFamily,color:t.muted,fontSize:12}}>La fotografía se entrega a la aplicación; no se sube automáticamente.</Text></View>;
}
export function AttachmentViewer({attachments=[],selected=0,onSelect,onShare}){const t=useCantappTheme();return <View style={{gap:12}}><View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{attachments.map((file,index)=><Button key={file.id||index} label={file.name||`Adjunto ${index+1}`} variant={index===selected?'secondary':'ghost'} onPress={()=>onSelect?.(index)}/>)}</View>{attachments[selected]?<DocumentPreview file={attachments[selected]} onShare={onShare}/>:<Text style={{fontFamily,color:t.muted}}>Sin adjuntos</Text>}</View>;}
