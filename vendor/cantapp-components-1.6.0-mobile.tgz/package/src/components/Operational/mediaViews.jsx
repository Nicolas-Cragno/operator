import { tokens } from '../../theme/tokens';
import React, { useRef, useState } from 'react';
import { View, Text, Image, Share } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import FileInput from '../Input/fileInput';
import Button from '../Button/button';
import { ErrorState } from '../Functional/states';
import { capturePhoto, pickImage } from './media';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import DocumentPreview from './documentPreview';
export function ImageUpload({onPick,onCapture,...props}){return <FileInput {...props} label={props.label||'Imágenes'} onPick={onPick||pickImage} onCapture={onCapture||capturePhoto}/>;}
export function QRViewer({value='',identifier=value,onShare,size=180}){
 const t=useCantappTheme();const qr=useRef(null);return <View style={{gap:12,alignItems:'center'}}>{value?<View accessibilityLabel={`Código QR: ${identifier}`} style={{backgroundColor:'#ffffff',padding:tokens.padding,borderRadius:tokens.radius}}><QRCode value={String(value)} size={size} color="#172033" backgroundColor="#ffffff" getRef={ref=>{qr.current=ref;}}/></View>:<Text style={{fontFamily,color:t.muted}}>Sin código para mostrar</Text>}<Text selectable style={{fontFamily:dataFontFamily,color:t.text}}>{identifier}</Text><Button icon="share" label="Compartir" disabled={!value} onPress={()=>onShare?new Promise((resolve,reject)=>{if(!qr.current?.toDataURL){reject(new Error('El QR todavía no está listo'));return;}qr.current.toDataURL(data=>Promise.resolve(onShare({value,identifier,dataUrl:'data:image/png;base64,'+data})).then(resolve,reject));}):Share.share({message:String(value)})}/></View>;
}
export function PhotoCapture({onUse,onError,onCapture=capturePhoto,onGallery=pickImage,disabled=false}){
 const t=useCantappTheme();const [photo,setPhoto]=useState(null);const [error,setError]=useState('');
 const select=async adapter=>{setError('');try{const result=await adapter();if(result&&!result.canceled)setPhoto(result.assets?.[0]||result);}catch(e){setError(e.message);onError?.(e);}};
 return <View style={{gap:12}}>{photo?<><Image source={{uri:photo.uri}} accessibilityLabel="Foto seleccionada" resizeMode="contain" style={{width:'100%',height:260}}/><View style={{flexDirection:'row',gap:tokens.space}}><Button label="Usar foto" disabled={disabled} onPress={async()=>{await onUse?.(photo);setPhoto(null);}}/><Button label="Repetir" variant="outline" disabled={disabled} onPress={()=>setPhoto(null)}/></View></>:<View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}><Button icon="camera" label="Cámara" disabled={disabled} onPress={()=>select(onCapture)}/><Button icon="upload" label="Galería" variant="outline" disabled={disabled} onPress={()=>select(onGallery)}/></View>}{error&&<ErrorState description={error}/>}<Text style={{fontFamily,color:t.muted,fontSize:12}}>La fotografía se entrega a la aplicación; no se sube automáticamente.</Text></View>;
}
export function AttachmentViewer({attachments=[],selected=0,onSelect,onShare}){const t=useCantappTheme();return <View style={{gap:12}}><View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{attachments.map((file,index)=><Button key={file.id||index} label={file.name||`Adjunto ${index+1}`} variant={index===selected?'secondary':'ghost'} onPress={()=>onSelect?.(index)}/>)}</View>{attachments[selected]?<DocumentPreview file={attachments[selected]} onShare={onShare}/>:<Text style={{fontFamily,color:t.muted}}>Sin adjuntos</Text>}</View>;}
