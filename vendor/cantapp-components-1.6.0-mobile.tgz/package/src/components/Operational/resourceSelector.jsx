import { tokens } from '../../theme/tokens';
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import Modal from '../Modal/modal';
import { SearchInput, NumberInput } from '../Input/controls';
import Checkbox from '../Input/checkbox';
import Button from '../Button/button';
import { EmptyState, ErrorState, LoadingState } from '../Functional/states';
import { useCantappTheme } from '../../theme/themeContext';
export default function ResourceSelector({visible=false,onClose,title='Seleccionar recurso',items=[],data=items,multiple=false,value,onSelectionChange,onSelect,onSearch,loading=false,error,stock=false,hasMore=false,onLoadMore}){
 const t=useCantappTheme();const [query,setQuery]=useState('');const [applied,setApplied]=useState('');const [keys,setKeys]=useState([]);const [quantities,setQuantities]=useState({});
 const rows=onSearch?data:data.filter(item=>[item.label,item.nombre,item.id,item.dominio,item.interno].some(text=>String(text??'').toLowerCase().includes(applied.toLowerCase())));
 const cache=useRef(new Map());
 useEffect(()=>{data.forEach(item=>cache.current.set(String(item.id),item));},[data]);
 const selected=value??keys;
 const choose=item=>{const key=String(item.id);if(multiple||stock){const next=selected.includes(key)?selected.filter(id=>id!==key):[...(multiple?selected:[]),key];if(value===undefined)setKeys(next);onSelectionChange?.(next);}else{onSelect?.(item);onClose?.();}};
 const confirm=()=>{const result=selected.map(key=>cache.current.get(key)).filter(Boolean).map(item=>stock?{...item,quantity:Number(quantities[item.id]??1)}:item);onSelect?.(multiple?result:result[0]);onClose?.();};
 return <Modal visible={visible} onClose={onClose} title={title} footer={(multiple||stock)&&<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Seleccionar" disabled={!selected.length||loading||(stock&&selected.some(key=>!Number.isFinite(Number(quantities[key]??1))||Number(quantities[key]??1)<0))} onPress={confirm}/><Button label="Cancelar" variant="outline" onPress={onClose}/></View>}><SearchInput value={query} onChange={setQuery} onSearch={next=>{setApplied(next);onSearch?.(next);}} loading={loading}/>{loading?<LoadingState/>:error?<ErrorState description={String(error.message||error)}/>:rows.length?<ScrollView style={{maxHeight:400}}>{rows.map(item=><View key={item.id} style={{paddingVertical:8,borderBottomWidth:1,borderColor:t.border,gap:tokens.space}}>{multiple||stock?<Checkbox label={item.label||item.nombre||item.dominio||String(item.id)} value={selected.includes(String(item.id))} onChange={()=>choose(item)}/>:<Button label={item.label||item.nombre||item.dominio||String(item.id)} variant="ghost" onPress={()=>choose(item)}/>}<Text style={{color:t.muted}}>{item.id}{stock?` · Existencia: ${item.existencia??item.cantidad??'—'} ${item.unidad||''}`:''}</Text>{stock&&selected.includes(String(item.id))&&<NumberInput label={`Cantidad (${item.unidad||'unidades'})`} value={quantities[item.id]??'1'} onChange={quantity=>setQuantities(old=>({...old,[item.id]:quantity}))} min={0} steppers/>}</View>)}</ScrollView>:<EmptyState/>}{hasMore&&<Button label="Cargar más" variant="outline" disabled={loading} onPress={onLoadMore}/>}</Modal>;
}
export function VehicleSelector(props){return <ResourceSelector title="Seleccionar vehículo" {...props}/>;}
export function PersonSelector(props){return <ResourceSelector title="Seleccionar persona" {...props}/>;}
export function StockSelector(props){return <ResourceSelector title="Seleccionar stock" {...props} stock/>;}
