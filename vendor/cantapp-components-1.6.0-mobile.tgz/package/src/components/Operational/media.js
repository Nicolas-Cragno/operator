import { Platform } from 'react-native';
export async function pickDocuments(){const picker=await import('expo-document-picker');return picker.getDocumentAsync({multiple:true,copyToCacheDirectory:true});}
export async function pickImage(){const picker=await import('expo-image-picker');return picker.launchImageLibraryAsync({mediaTypes:['images'],quality:0.9});}
export async function capturePhoto(){const picker=await import('expo-image-picker');if(Platform.OS!=='web'){const permission=await picker.requestCameraPermissionsAsync();if(!permission.granted)throw new Error('Permiso de cámara denegado. Podés habilitarlo en ajustes.');}return picker.launchCameraAsync({mediaTypes:['images'],quality:0.9});}
