import React, { useRef, useState } from 'react';
import { View, Text, Linking, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import Button from '../Button/button';
import { ErrorState } from '../Functional/states';
import { useCantappTheme } from '../../theme/themeContext';
export default function QRScanner({onScan,onError,disabled=false}){
 const t=useCantappTheme();const [permission,requestPermission]=useCameraPermissions();const [active,setActive]=useState(false);const [error,setError]=useState('');const scanned=useRef(false);
 const start=async()=>{setError('');try{const result=permission?.granted?permission:await requestPermission();if(!result.granted)throw new Error('Permiso de cámara denegado');scanned.current=false;setActive(true);}catch(e){setError(e.message);onError?.(e);}};
 return <View style={{gap:12}}>{active&&!disabled?<><CameraView style={{width:'100%',height:300}} facing="back" barcodeScannerSettings={{barcodeTypes:['qr']}} onMountError={event=>{setActive(false);setError(event.message);onError?.(event);}} onBarcodeScanned={result=>{if(scanned.current)return;scanned.current=true;setActive(false);onScan?.(result.data,result);}}/><Button label="Detener cámara" variant="outline" onPress={()=>setActive(false)}/></>:<Button icon="qr" label="Escanear QR" disabled={disabled} onPress={start}/>} {error&&<ErrorState description={error}/>} {permission?.canAskAgain===false&&Platform.OS!=='web'&&<Button label="Abrir ajustes" variant="outline" onPress={()=>Linking.openSettings()}/>}<Text style={{color:t.muted,fontSize:12}}>La cámara Web necesita HTTPS o localhost. El resultado se entrega por callback.</Text></View>;
}
