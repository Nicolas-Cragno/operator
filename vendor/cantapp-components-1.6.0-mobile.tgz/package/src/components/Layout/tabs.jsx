import React from 'react';
import { ScrollView } from 'react-native';
import Button from '../Button/button';
export default function Tabs({items=[],value,selected=value,onChange,onSelect}){return <ScrollView horizontal contentContainerStyle={{gap:4}}>{items.map(item=><Button key={item.key} label={item.label} variant={selected===item.key?'secondary':'ghost'} accessibilityRole="tab" accessibilityState={{selected:selected===item.key}} onPress={()=>{onChange?.(item.key);onSelect?.(item);}}/>)}</ScrollView>;}
