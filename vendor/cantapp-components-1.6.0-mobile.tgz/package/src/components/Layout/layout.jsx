import React from "react";
import { View } from "react-native";
import Header from "./header";
import { useCantappTheme } from "../../theme/themeContext";
import styles from "./styles/layout.styles";
function Layout({ children, title = "CANTAPP", header = true }) {
  const t = useCantappTheme();
  return (
    <View style={[styles.root, { flex: 1, backgroundColor: t.background }]}>
      {header ? <Header title={title} /> : null}
      {children}
    </View>
  );
}
export default Layout;
