import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { StatCard } from '../Card/kpiCard';
export default function SummaryPanel({items=[],children}){const viewport=useWindowDimensions().width;const [width,setWidth]=useState(viewport);return <View onLayout={event=>setWidth(event.nativeEvent.layout.width)} style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{items.map((item,index)=><View key={item.key||index} style={{width:width>=1024?'24%':width>=340?'48%':'100%'}}><StatCard {...item}/></View>)}{children}</View>;}
