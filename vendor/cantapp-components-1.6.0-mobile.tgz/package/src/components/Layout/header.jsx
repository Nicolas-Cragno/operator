import BrandLogo from './brandLogo';
import React, { useContext } from 'react';
import { View, Text } from 'react-native';
import { SafeAreaInsetsContext } from 'react-native-safe-area-context';
import Button from '../Button/button';
import { fontFamily } from '../../theme/typography';
import { tokens } from '../../theme/tokens';
const logo=require('../../../assets/logos/logo.png');
export default function Header({title='CANTAPP',moduleName,user,onLogout,onUser,onNotifications,onMenu,appLogo=logo}){
 const insets=useContext(SafeAreaInsetsContext);
 return <View style={{backgroundColor:tokens.colors.primary,paddingTop:insets?.top||0,paddingLeft:insets?.left||0,paddingRight:insets?.right||0}}><View style={{height:tokens.headerHeight,flexDirection:'row',alignItems:'center',gap:12,paddingHorizontal:tokens.padding}}>{onMenu&&<Button iconOnly variant="ghost" accessibilityLabel="Abrir navegación" onPress={onMenu} icon="menu" style={{backgroundColor:'#e8edff'}}/>}<BrandLogo source={appLogo} width={100} height={32}/><Text numberOfLines={1} style={{fontFamily,color:'#ffffff',fontSize:16,fontWeight:'600',flex:1}}>{moduleName||title}</Text>{onNotifications&&<Button iconOnly accessibilityLabel="Notificaciones" variant="secondary" icon="bell" onPress={onNotifications}/>} {onUser&&<Button iconOnly accessibilityLabel={user?.nombre||'Usuario'} variant="secondary" icon="user" onPress={onUser}/>} {onLogout&&<Button label="Salir" variant="secondary" onPress={onLogout}/>}</View></View>;
}
