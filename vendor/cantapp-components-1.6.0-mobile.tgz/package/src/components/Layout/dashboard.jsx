import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
export function Dashboard({ children }) { return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap:tokens.padding }}>{React.Children.map(children, child => <View style={{ flexGrow: 1, flexBasis: 260, minWidth: 0 }}>{child}</View>)}</View>; }
export function ChartPanel({ title = 'Indicadores', description, children, legend = [] }) { const t = useCantappTheme(); return <View style={{ padding:tokens.padding, gap: 12, backgroundColor: t.surface, borderRadius:tokens.radius, borderWidth: 1, borderColor: t.border }}><Text accessibilityRole="header" style={{ color: t.special, fontWeight: '700' }}>{title}</Text>{description && <Text style={{ color: t.muted }}>{description}</Text>}{children}{legend.map(item => <Text key={item.label} style={{ color: t.text }}>{item.symbol || '■'} {item.label}</Text>)}</View>; }
