import { tokens } from "../../theme/tokens";
import BrandLogo from "./brandLogo";
import React, { useEffect, useState } from "react";
import { View, Text, ScrollView } from "react-native";
import Button from "../Button/button";
import { useCantappTheme } from "../../theme/themeContext";
import { fontFamily } from "../../theme/typography";
const logo = require("../../../assets/logos/logo.png");
export default function Sidebar({
  items = [],
  groups,
  selected,
  onSelect,
  appLogo = logo,
  expanded: controlled,
  onToggle,
  preferences,
  preferenceKey = "cantapp.sidebar.expanded",
  onPreferenceError,
}) {
  const t = useCantappTheme();
  const [local, setLocal] = useState(true);
  const expanded = controlled ?? local;
  useEffect(() => {
    let active = true;
    if (preferences?.get)
      Promise.resolve(preferences.get(preferenceKey))
        .then((value) => {
          if (active && typeof value === "boolean") setLocal(value);
        })
        .catch((error) => onPreferenceError?.(error));
    return () => {
      active = false;
    };
  }, [preferences, preferenceKey, onPreferenceError]);
  const toggle = () => {
    const next = !expanded;
    if (controlled === undefined) setLocal(next);
    onToggle?.(next);
    if (preferences?.set)
      Promise.resolve(preferences.set(preferenceKey, next)).catch((error) =>
        onPreferenceError?.(error),
      );
  };
  return (
    <View
      style={{
        width: expanded ? tokens.sidebarWidth : tokens.sidebarCollapsed,
        backgroundColor: t.surface,
        borderRightWidth: 1,
        borderColor: t.border,
        padding: 8,
        gap: tokens.space,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {expanded && <BrandLogo source={appLogo} width={140} height={40} />}
        <Button
          iconOnly
          variant="ghost"
          icon="menu"
          accessibilityLabel={
            expanded ? "Contraer navegación" : "Expandir navegación"
          }
          onPress={toggle}
        />
      </View>
      <ScrollView>
        {(groups || [{ items }]).map((group, index) => (
          <View key={group.key || index} style={{ gap: 4, paddingVertical: 8 }}>
            {expanded && group.title && (
              <Text
                style={{ fontFamily, fontSize: 12, color: t.muted, padding: 8 }}
              >
                {group.title}
              </Text>
            )}
            {group.items?.map((item, i) => (
              <Button
                key={item.key || i}
                label={item.label}
                icon={item.icon || "access"}
                iconOnly={!expanded}
                accessibilityLabel={item.label}
                accessibilityState={{ selected: item.key === selected }}
                variant={item.key === selected ? "secondary" : "ghost"}
                disabled={item.disabled}
                onPress={() => onSelect?.(item)}
                style={{ alignItems: "flex-start" }}
              />
            ))}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
