import React from 'react';
import { Image } from 'react-native';
import { SvgUri } from 'react-native-svg';
export default function BrandLogo({ source, width = 120, height = 32, label = 'Logo de aplicación' }) {
  if (React.isValidElement(source)) return source;
  const uri = typeof source === 'string' ? source : source?.uri || Image.resolveAssetSource?.(source)?.uri;
  if (uri && /\.svg(?:\?|$)/i.test(uri)) return <SvgUri uri={uri} width={width} height={height} accessibilityLabel={label} />;
  return <Image source={typeof source === 'string' ? { uri: source } : source} resizeMode="contain" accessibilityLabel={label} style={{ width, height }} />;
}
