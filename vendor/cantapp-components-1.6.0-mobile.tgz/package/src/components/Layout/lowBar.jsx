import React, { useContext, useState } from 'react';
import { View, Text, Pressable, useWindowDimensions } from 'react-native';
import { SafeAreaInsetsContext } from 'react-native-safe-area-context';
import Modal from '../Modal/modal';
import Sidebar from './sidebar';
import Icon from '../Functional/icon';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily } from '../../theme/typography';
export default function LowBar({items=[],selected,onSelect,appLogo,mobileOnly=false}){
 const t=useCantappTheme();const [more,setMore]=useState(false);const compact=useWindowDimensions().width<768;const insets=useContext(SafeAreaInsetsContext);if(mobileOnly&&!compact)return null;
 const primary=items.slice(0,4);return <><View style={{flexDirection:'row',backgroundColor:t.surface,borderTopWidth:1,borderColor:t.border,paddingBottom:insets?.bottom||0,paddingLeft:insets?.left||0,paddingRight:insets?.right||0}}>{[...primary,{key:'__more',label:'Más',icon:'more'}].map(item=><Pressable key={item.key} accessibilityRole="button" accessibilityState={{selected:item.key===selected}} accessibilityLabel={item.label||item.key} onPress={()=>item.key==='__more'?setMore(true):onSelect?.(item)} style={{flex:1,minHeight:56,alignItems:'center',justifyContent:'center',gap:4,backgroundColor:item.key===selected?t.selection:undefined}}><Icon name={item.icon||'access'} color={item.key===selected?t.primary:t.muted}/><Text numberOfLines={1} style={{fontFamily,fontSize:11,color:item.key===selected?t.primary:t.muted}}>{item.label||item.key}</Text></Pressable>)}</View><Modal visible={more} presentation="drawer" title="Más opciones" onClose={()=>setMore(false)}><Sidebar items={items.slice(4)} selected={selected} appLogo={appLogo} onSelect={item=>{setMore(false);onSelect?.(item);}}/></Modal></>;
}
export function BottomNavigation(props){return <LowBar {...props} mobileOnly/>;}
