import { PAGE } from './documentSchema';
export default async function webPdf(pages, filename, action) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  pages.forEach((page, index) => {
    if (index) doc.addPage();
    if (page.image) {
      const format = /^data:image\/png/i.test(page.image) ? 'PNG' : 'JPEG';
      doc.addImage(page.image, format, 0, 0, PAGE.width, PAGE.height);
    }
    const header = page.header?.title || (typeof page.header === 'string' ? page.header : '');
    if (header) { doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.text(header, 15, 18); }
    const positioned = page.fields.some(field => Number.isFinite(field.x) && Number.isFinite(field.y));
    if (positioned) {
      page.fields.forEach(field => { doc.setFont('helvetica', 'normal'); doc.setFontSize(field.fontSize || 10); doc.text(String(field.value), Number(field.x || 15), Number(field.y || 30), { maxWidth: field.maxWidth || 180 }); });
    } else {
      doc.setFont('helvetica', 'bold'); doc.setFontSize(16); doc.text(page.title || 'Documento', 15, header ? 35 : 24);
      let y = header ? 47 : 37;
      page.fields.forEach(field => {
        const value = doc.splitTextToSize(String(field.value), 112);
        const lines = Math.max(1, value.length);
        if (y + lines * 5 > 282) { doc.addPage(); y = 22; }
        doc.setFontSize(10); doc.setFont('helvetica', 'bold'); doc.text(String(field.label), 15, y);
        doc.setFont('helvetica', 'normal'); doc.text(value, 75, y);
        y += Math.max(9, lines * 5 + 3);
      });
    }
  });
  if (action === 'print') { doc.autoPrint(); window.open(doc.output('bloburl'), '_blank'); return { platform: 'web', printed: true }; }
  doc.save(filename || 'documento.pdf');
  return { platform: 'web', downloaded: true };
}

