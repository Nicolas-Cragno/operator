// Native PDF generation uses expo-print; keep browser-only dependencies out of native bundles.
export default function webPdf() { throw new Error('PDF web renderer is only available on Web.'); }
