export const PAGE = { width: 210, height: 297 };

export function normalizeText(value) {
  if (value === null || value === undefined || value === '') return '-';
  if (Array.isArray(value)) return value.map(normalizeText).join(', ');
  if (typeof value === 'object') return value.nombre || value.name || value.id || JSON.stringify(value);
  return String(value);
}

export function getPath(data, path) {
  return String(path || '').split('.').reduce((current, key) => current?.[key], data);
}

export function createDocument({ title = 'Documento', data = {}, header = null, fields = [], template = null, filename = 'documento.pdf', pages = null } = {}) {
  const normalized = fields.length ? fields : Object.keys(data).map(key => ({ key, label: key }));
  const page = { title, header, template, fields: normalized.map(field => ({ label: field.label || field.key, value: normalizeText(getPath(data, field.key)), x: field.x, y: field.y, fontSize: field.fontSize, maxWidth: field.maxWidth })) };
  return { filename, pages: pages?.length ? pages : [page] };
}

export const VIAJE_FIELDS = [
  { key: 'viaje', label: 'Viaje' }, { key: 'chofer', label: 'Chofer' },
  { key: 'tractor', label: 'Tractor' }, { key: 'furgones', label: 'Furgones' },
  { key: 'cliente', label: 'Cliente' }, { key: 'salida', label: 'Salida' },
  { key: 'arribo', label: 'Arribo' }, { key: 'duracion', label: 'Duración' },
  { key: 'litros', label: 'Litros' }, { key: 'promedio', label: 'Promedio' },
  { key: 'diferencia', label: 'Diferencia' }, { key: 'estado', label: 'Estado' }
];
