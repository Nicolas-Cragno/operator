import { Platform } from 'react-native';
import { Asset } from 'expo-asset';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import webPdf from './webPdf';

const escapeHtml = value => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

async function imageDataUri(source) {
  if (!source) return null;
  if (typeof source === 'string' && source.startsWith('data:image/')) return source;
  let uri = typeof source === 'string' ? source : source.uri;
  if (typeof source === 'number') {
    const asset = Asset.fromModule(source);
    await asset.downloadAsync();
    uri = asset.localUri || asset.uri;
  }
  if (!uri) return null;
  if (Platform.OS === 'web') {
    const response = await fetch(uri);
    if (!response.ok) throw new Error('No se pudo leer la imagen de plantilla');
    const blob = await response.blob();
    return await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(blob); });
  }
  if (/^https?:/i.test(uri)) {
    const local = FileSystem.cacheDirectory + `cantapp-pdf-${Date.now()}.jpg`;
    await FileSystem.downloadAsync(uri, local);
    uri = local;
  }
  const b64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  const mime = /\.png(?:$|\?)/i.test(uri) ? 'image/png' : 'image/jpeg';
  return `data:${mime};base64,${b64}`;
}

async function resolvePages(document) {
  return Promise.all(document.pages.map(async page => ({ ...page, image: await imageDataUri(page.template) })));
}

function pageHtml(page) {
  const heading = page.header?.title || (typeof page.header === 'string' ? page.header : '');
  const subheading = page.header?.subtitle || '';
  const background = page.image ? `<img class="template" src="${page.image}" />` : '';
  const header = heading ? `<header><strong>${escapeHtml(heading)}</strong><small>${escapeHtml(subheading)}</small></header>` : '';
  const positioned = page.fields.some(field => Number.isFinite(field.x) && Number.isFinite(field.y));
  const fields = positioned ? page.fields.map(field => `<div class="positioned" style="left:${Number(field.x || 0)}mm;top:${Number(field.y || 0)}mm;font-size:${Number(field.fontSize || 10)}pt">${escapeHtml(field.value)}</div>`).join('') : `<h2>${escapeHtml(page.title || '')}</h2><table>${page.fields.map(field => `<tr><th>${escapeHtml(field.label)}</th><td>${escapeHtml(field.value)}</td></tr>`).join('')}</table>`;
  return `<section class="page">${background}${header}<div class="content${positioned ? ' absolute-content' : ''}">${fields}</div></section>`;
}

function toHtml(pages) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;color:#111;background:#fff}.page{width:210mm;height:297mm;position:relative;overflow:hidden;page-break-after:always;background:white}.page:last-child{page-break-after:auto}.template{position:absolute;inset:0;width:100%;height:100%;object-fit:fill}.content{position:relative;padding:23mm 15mm}header{position:relative;margin:12mm 15mm 0;border-bottom:1px solid #999;padding-bottom:4mm;display:flex;justify-content:space-between;font-size:14pt}header small{font-size:9pt}header+.content{padding-top:12mm}h2{font-size:16pt;margin:0 0 10mm}table{border-collapse:collapse;width:100%;font-size:10pt}th,td{text-align:left;padding:3mm;border-bottom:1px solid #ddd;overflow-wrap:anywhere}th{width:38%;color:#555}.absolute-content{position:absolute;inset:0;padding:0}.positioned{position:absolute;white-space:pre-wrap;max-width:180mm}</style></head><body>${pages.map(pageHtml).join('')}</body></html>`;
}

export async function generatePDF(document, { action = 'save' } = {}) {
  if (!document?.pages?.length) throw new Error('El documento necesita al menos una página');
  const pages = await resolvePages(document);
  if (Platform.OS === 'web') return webPdf(pages, document.filename, action);
  const html = toHtml(pages);
  if (action === 'print') { await Print.printAsync({ html }); return { platform: Platform.OS, printed: true }; }
  const result = await Print.printToFileAsync({ html, base64: false });
  if (action === 'share' || action === 'save') {
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(result.uri, { mimeType: 'application/pdf', dialogTitle: document.filename || 'Documento PDF' });
  }
  return { platform: Platform.OS, uri: result.uri };
}

export { toHtml as buildPdfHtml };
