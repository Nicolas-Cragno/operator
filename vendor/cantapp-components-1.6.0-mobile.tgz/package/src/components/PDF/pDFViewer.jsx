import React,{useState} from 'react';
import {View,Text,Image,Pressable} from 'react-native';import Modal from '../Modal/modal';
function PDFViewer({visible=false,onClose,title='Vista previa de documento',pages=[],images=pages}) {
 const [page,setPage]=useState(0);const items=images;const shownPage=Math.min(page,Math.max(0,items.length-1));
 return <Modal visible={visible} onClose={onClose} title={title}><View style={{alignItems:'center',gap:12}}>{items.length?<Image source={items[shownPage]} resizeMode="contain" style={{width:'100%',height:440}}/>:<Text style={{color:'#333'}}>Agregá imágenes de las páginas mediante pages.</Text>}<View style={{flexDirection:'row',alignItems:'center',gap:20}}><Pressable disabled={shownPage===0} onPress={()=>setPage(Math.max(0,shownPage-1))}><Text style={{color:'#0d1f7f'}}>◀ Anterior</Text></Pressable><Text style={{color:'#222'}}>{items.length?shownPage+1:0} / {items.length}</Text><Pressable disabled={shownPage>=items.length-1} onPress={()=>setPage(shownPage+1)}><Text style={{color:'#0d1f7f'}}>Siguiente ▶</Text></Pressable></View></View></Modal>;
}
export default PDFViewer;
