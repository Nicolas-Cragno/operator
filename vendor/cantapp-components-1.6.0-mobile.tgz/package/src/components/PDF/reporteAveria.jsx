import React from 'react';
import PDFDocument from './pDFDocument';
import { createDocument } from './engine/documentSchema';

export function createReporteAveria({ data = {}, header, template, fields, filename = 'reporte-averia.pdf' } = {}) {
  return createDocument({ title: 'REPORTE DE AVERÍA', data, header, template, fields, filename });
}

function ReporteAveria({ data = {}, header, template, fields, onGenerated, onError }) {
  const document = createReporteAveria({ data, header, template, fields });
  return <PDFDocument document={document} title="Reporte de avería" onGenerated={onGenerated} onError={onError} />;
}
export default ReporteAveria;
