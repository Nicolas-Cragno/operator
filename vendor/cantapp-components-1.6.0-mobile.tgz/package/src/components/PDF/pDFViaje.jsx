import { tokens } from '../../theme/tokens';
import React from 'react';
import { View, Text } from 'react-native';
import { createDocument, VIAJE_FIELDS } from './engine/documentSchema';

export function createPDFViaje({ data = {}, header = null, template = null, fields = VIAJE_FIELDS, filename = 'viaje.pdf' } = {}) {
  return createDocument({ title: 'HOJA DE RUTA', data, header, template, fields, filename });
}

function PDFViaje({ data = {}, header, template, style }) {
  const document = createPDFViaje({ data, header, template });
  return <View style={[{ backgroundColor: '#fff', padding: 20, gap:tokens.space, width: '100%' }, style]}>
    <Text style={{ color: '#111', fontSize: 17, fontWeight: '700' }}>{typeof header === 'string' ? header : header?.title || 'HOJA DE RUTA'}</Text>
    {document.pages[0].fields.map(field => <View key={field.label} style={{ flexDirection: 'row', paddingVertical: 5, borderBottomWidth: 1, borderColor: '#ddd' }}><Text style={{ width: '38%', color: '#555' }}>{field.label}</Text><Text style={{ flex: 1, color: '#111' }}>{field.value}</Text></View>)}
  </View>;
}
export default PDFViaje;
