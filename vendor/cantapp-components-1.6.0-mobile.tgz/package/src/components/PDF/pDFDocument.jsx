import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import { createDocument } from './engine/documentSchema';
import { generatePDF } from './engine/pdfEngine';

function PDFDocument({ document, data = {}, title = 'Documento', header, template, fields = [], onGenerated, onError }) {
  const [busy, setBusy] = useState(false);
  const definition = document || createDocument({ title, header, template, fields, data });
  const execute = async action => {
    setBusy(true);
    try { const result = await generatePDF(definition, { action }); onGenerated?.(result); }
    catch (error) { onError?.(error); }
    finally { setBusy(false); }
  };
  return <View style={{ padding: 14, backgroundColor: '#fff', gap: 12 }}>
    <Text style={{ fontSize: 16, color: '#111', fontWeight: '700' }}>{title}</Text>
    {busy ? <ActivityIndicator /> : <View style={{ flexDirection: 'row', gap: 12 }}>
      <Pressable accessibilityRole="button" onPress={() => execute('save')} style={{ padding: 12, backgroundColor: '#0d1f7f', borderRadius:tokens.radius }}><Text style={{ color: '#fff' }}>Guardar / compartir PDF</Text></Pressable>
      <Pressable accessibilityRole="button" onPress={() => execute('print')} style={{ padding: 12, backgroundColor: '#5c0624', borderRadius:tokens.radius }}><Text style={{ color: '#fff' }}>Imprimir</Text></Pressable>
    </View>}
  </View>;
}
export default PDFDocument;
