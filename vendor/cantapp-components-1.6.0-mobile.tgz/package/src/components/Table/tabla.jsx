import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable, FlatList, useWindowDimensions } from 'react-native';
import { persona, tractor, furgon } from '../../data/examples';
import { formatValue, toDate } from '../../utils/data';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import Input from '../Input/input';
import Checkbox from '../Input/checkbox';
import Pagination from './pagination';
import { LoadingState, EmptyState, ErrorState } from '../Functional/states';
import DataValue from '../Data/dataValue';
import { SearchInput } from '../Input/controls';
import { controlHeight, focusStyle } from '../../theme/controls';
import { DataCard } from './dataViews';
const defaults = [{ key: 'id', label: 'ID' }, { key: 'nombre', label: 'Nombre' }, { key: 'estado', label: 'Estado' }];
export default function Tabla({ data = [persona, tractor, furgon], columns = defaults, onRowPress, loading = false, error, onRetry, emptyMessage = 'No hay registros', searchable = false, search, onSearchChange, filters, sort, onSortChange, page, pageSize = 25, total, hasMore, onChangePage, serverSide = false, selectedKeys = [], onSelectionChange, rowKey = 'id', renderActions, cellStyle, height = 440, fill = false, v2 = false }) {
 const t = useCantappTheme(); const compact = useWindowDimensions().width < (v2 ? 768 : 600) && !fill;
 const [query, setQuery] = useState(''); const [draft,setDraft]=useState(search??'');
 useEffect(()=>{if(search!==undefined)setDraft(search);},[search]); const [localSort, setLocalSort] = useState(null); const [localPage, setLocalPage] = useState(1);
 const q = search ?? query; const ordering = sort === undefined ? localSort : sort;
 const current = page ?? localPage; const size = Math.max(1, pageSize);
 const rows = useMemo(() => {
  if (serverSide) return data;
  let result = searchable && q ? data.filter(row => columns.some(c => formatValue(row[c.key]).toLocaleLowerCase().includes(q.toLocaleLowerCase()))) : data;
  if (ordering) result = [...result].sort((a, b) => {
   const column = columns.find(c => c.key === ordering.key);
   const av = a[ordering.key], bv = b[ordering.key];
   const ad = toDate(av, column?.type === 'date' || column?.type === 'datetime'), bd = toDate(bv, column?.type === 'date' || column?.type === 'datetime');
   return (ad && bd ? ad - bd : formatValue(av).localeCompare(formatValue(bv), 'es', { numeric: true })) * (ordering.direction === 'desc' ? -1 : 1);
  });
  return result;
 }, [data, columns, searchable, q, ordering, serverSide]);
 const count = serverSide ? total : rows.length;
 const pages = count == null ? undefined : Math.max(1, Math.ceil(count / size));
 const activePage = serverSide ? current : Math.min(current, pages);
 const visibleRows = serverSide ? rows : rows.slice((activePage - 1) * size, activePage * size);
 const changePage = next => { if (page === undefined) setLocalPage(next); onChangePage?.(next); };
 const keyOf = (row, index) => String(typeof rowKey === 'function' ? rowKey(row) : row[rowKey] ?? index);
 const toggleSort = c => { const next = { key: c.key, direction: ordering?.key === c.key && ordering.direction === 'asc' ? 'desc' : 'asc' }; if (sort === undefined) setLocalSort(next); onSortChange?.(next); changePage(1); };
 const renderRow = ({ item: row, index }) => v2 && compact ? <DataCard title={formatValue(row[columns.find(c=>c.key!=='id'&&c.key!=='estado')?.key]??row.id)} identifier={keyOf(row,index)} status={row.estado} details={columns.filter(c=>!['id','estado',columns.find(c=>c.key!=='id'&&c.key!=='estado')?.key].includes(c.key)).slice(0,2).map(c=>({...c,value:row[c.key]}))} onPress={onRowPress?()=>onRowPress(row):undefined}/> : <Pressable disabled={!v2||!onRowPress} accessibilityRole={v2&&onRowPress?'button':undefined} accessibilityLabel={v2?`Abrir ${keyOf(row,index)}`:undefined} onPress={()=>onRowPress?.(row)} style={({focused})=>[{ minHeight:v2?controlHeight:undefined, flexDirection: compact ? 'column' : 'row', gap: compact ? 8 : 0, padding: compact ? 12 : 0, borderBottomWidth: 1, borderColor: t.border, backgroundColor: index % 2 ? t.surfaceElevated : t.surface },focused&&focusStyle(t.focus)]}>
  {onSelectionChange && <View style={{ width: compact ? undefined : 160 }}><Checkbox label={`Seleccionar ${keyOf(row, index)}`} value={selectedKeys.includes(keyOf(row, index))} onChange={() => { const key = keyOf(row, index); onSelectionChange(selectedKeys.includes(key) ? selectedKeys.filter(k => k !== key) : [...selectedKeys, key]); }} /></View>}
  {columns.map(c => <View key={c.key} style={{ width: compact ? undefined : c.width || 160, flexGrow: compact ? 0 : 1, padding: compact ? 0 : v2 ? 8 : 12 }}>{compact && <Text style={{ color: t.muted, fontFamily }}>{c.label}</Text>}{c.render ? c.render(row[c.key], row) : <Text style={[{ color: t.text, fontSize:14, fontFamily:typeof row[c.key]==='number'||['id','dni','dominio','interno'].includes(c.key)?dataFontFamily:fontFamily }, cellStyle?.(c.key, row[c.key], row)]}>{c.type === 'date' || c.type === 'datetime' ? <DataValue value={row[c.key]} type={c.type} /> : formatValue(row[c.key])}</Text>}</View>)}
  {!v2 && onRowPress && <Pressable accessibilityRole="button" accessibilityLabel={`Abrir ${keyOf(row, index)}`} onPress={() => onRowPress(row)} style={{ minHeight: 44, padding: 12, justifyContent: 'center' }}><Text style={{ color: t.special, fontFamily }}>Ver ficha</Text></Pressable>}
  {!v2 && renderActions && <View style={{ padding: 8 }}>{renderActions(row)}</View>}
 </Pressable>;
 const header = <View style={{ flexDirection: 'row', backgroundColor: t.hover }}>{onSelectionChange && <View style={{ width: 160 }} />}{columns.map(c => <Pressable key={c.key} accessibilityRole="button" accessibilityLabel={`Ordenar por ${c.label}`} disabled={c.sortable === false} onPress={() => toggleSort(c)} style={{ width: c.width || 160, flexGrow: compact ? 0 : 1, padding: v2?8:12, minHeight: v2?controlHeight:44 }}><Text style={{ color: t.special, fontFamily, fontWeight: '700' }}>{c.label} {ordering?.key === c.key ? ordering.direction === 'asc' ? 'ASC' : 'DESC' : ''}</Text></Pressable>)}</View>;
 const list = <FlatList data={visibleRows} keyExtractor={keyOf} renderItem={renderRow} extraData={selectedKeys} ListHeaderComponent={compact ? null : header} stickyHeaderIndices={compact ? undefined : [0]} style={{ ...(fill ? { flex: 1, minHeight: 0 } : { height }), minWidth: '100%', flexGrow: 1, width: compact ? '100%' : Math.max(620, columns.reduce((sum, c) => sum + (c.width || 160), 0) + (onSelectionChange ? 160 : 0) + (!v2&&onRowPress ? 150 : 0) + (!v2&&renderActions ? 180 : 0)) }} keyboardShouldPersistTaps="handled" />;
 return <View style={{ width: '100%', minWidth: 0, alignSelf: 'stretch', ...(fill ? { flex: 1, minHeight: 0, width: '100%', overflow: 'hidden' } : {}), gap: 12, borderRadius: t.radius, borderWidth: 1, borderColor: t.border, backgroundColor: t.surface, padding: 8 }}>
  {searchable && v2 && <SearchInput value={draft} onChange={setDraft} onSearch={value=>{if(search===undefined)setQuery(value);onSearchChange?.(value);changePage(1);}} loading={loading}/>}
  {searchable && !v2 && <Input label="Buscar registros" value={q} onChange={value => { if (search === undefined) setQuery(value); onSearchChange?.(value); changePage(1); }} />}{filters}
  {loading ? <LoadingState /> : error ? <ErrorState description={typeof error === 'string' ? error : error.message} onRetry={onRetry} /> : !visibleRows.length ? <EmptyState title={emptyMessage} /> : compact ? list : <ScrollView horizontal style={fill ? { flex: 1, minHeight: 0 } : undefined} contentContainerStyle={{ flexGrow: 1 }}>{list}</ScrollView>}
  <Pagination page={activePage} totalPages={pages} hasMore={hasMore} loading={loading} onChange={changePage} />
 </View>;
}
