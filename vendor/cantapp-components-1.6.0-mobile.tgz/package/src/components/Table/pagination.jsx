import React from 'react';
import { View, Text } from 'react-native';
import Button from '../Button/button';
import { useCantappTheme } from '../../theme/themeContext';
export default function Pagination({page=1,totalPages,hasMore=false,loading=false,onChange}){
 const t=useCantappTheme();const pages=totalPages==null?[]:Array.from({length:Math.min(5,Math.max(1,totalPages))},(_,index)=>Math.max(1,Math.min(page-2,Math.max(1,totalPages-4)))+index);
 return <View style={{flexDirection:'row',flexWrap:'wrap',alignItems:'center',justifyContent:'center',gap:4}}><Button label="Anterior" variant="ghost" disabled={loading||page<=1} onPress={()=>onChange?.(page-1)}/>{pages.length?pages.map(number=><Button key={number} label={String(number)} accessibilityLabel={`Página ${number}`} accessibilityState={{selected:page===number}} variant={number===page?'primary':'ghost'} disabled={loading} onPress={()=>onChange?.(number)}/>):<Text style={{color:t.text}}>Página {page}</Text>}{totalPages>pages[pages.length-1]&&<Text style={{color:t.muted}}>?</Text>}<Button label="Siguiente" variant="ghost" disabled={loading||(totalPages!=null?page>=totalPages:!hasMore)} onPress={()=>onChange?.(page+1)}/></View>;
}
