import React from 'react';
import Tabla from './tabla';
function TablaFicha({data=[{id:'EV-001',tipo:'SALIDA',fecha:'26/10/2026'},{id:'EV-002',tipo:'ENTRADA',fecha:'28/10/2026'}],onOpenFicha,onRowPress,...props}) {return <Tabla columns={[{key:"id",label:"ID"},{key:"tipo",label:"Tipo"},{key:"fecha",label:"Fecha",type:"date"}]} data={data} onRowPress={row=>{onOpenFicha?.(row);onRowPress?.(row)}} {...props}/>;}
export default TablaFicha;
