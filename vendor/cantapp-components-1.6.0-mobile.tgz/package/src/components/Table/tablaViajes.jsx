import React from 'react';
import Tabla from './tabla';

const columns=[['viaje','VIAJE'],['chofer','CHOFER'],['tractor','TRACTOR'],['furgon','FURGÃ“N'],['cliente','CLIENTE'],['salida','SALIDA'],['arribo','ARRIBO'],['duracion','DURACIÃ“N'],['litros','LITROS'],['promedio','PROMEDIO'],['diferencia','DIFERENCIA'],['estado','ESTADO']];
const demo=[{viaje:'001-00001412',chofer:'ARASCO, WALTER OMAR',tractor:'745',furgon:'450',cliente:'RADIO VICTORIA',salida:'26/10/2026',arribo:'-',duracion:'2 d 7 h',litros:'820',promedio:'40.25',diferencia:'22',estado:'ACTIVO'},{viaje:'001-00001408',chofer:'MARTINEZ, ALEJANDRO',tractor:'744',furgon:'785',cliente:'RADIO VICTORIA',salida:'26/10/2026',arribo:'-',duracion:'2 d 8 h',litros:'700',promedio:'39.8',diferencia:'-12',estado:'ACTIVO'}];
function TablaViajes({data=demo,...props}) { return <Tabla data={data} rowKey="viaje" columns={columns.map(([key,label])=>({key,label,width:key==='chofer'?220:140,type:['salida','arribo'].includes(key)?'date':undefined}))} {...props}/>; }
export default TablaViajes;
