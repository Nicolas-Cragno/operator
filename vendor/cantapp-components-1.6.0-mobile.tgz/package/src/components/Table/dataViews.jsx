import { tokens } from '../../theme/tokens';
import React, { useState } from 'react';
import { View, Text, Pressable, useWindowDimensions } from 'react-native';
import { useCantappTheme } from '../../theme/themeContext';
import { fontFamily, dataFontFamily } from '../../theme/typography';
import { formatValue } from '../../utils/data';
import { StatusBadge } from '../Functional/states';
import Input from '../Input/input';
import DateRangeFilter from '../Input/dateRangeFilter';
import Button from '../Button/button';
import DataValue from '../Data/dataValue';
export function DataCard({title='Registro',identifier,status,details=[],onPress}){
 const t=useCantappTheme();const content=<View style={{padding:tokens.padding,gap:tokens.space,borderWidth:1,borderColor:t.border,borderRadius:tokens.radius,backgroundColor:t.surface}}><Text style={{fontFamily,color:t.text,fontWeight:'600'}}>{title}</Text>{identifier!=null&&<Text style={{fontFamily:dataFontFamily,color:t.muted}}>{formatValue(identifier)}</Text>}{status&&<StatusBadge label={status}/>} {details.slice(0,2).map((field,i)=><Text key={field.key||i} style={{fontFamily,color:t.muted}}>{field.label}: {formatValue(field.value)}</Text>)}</View>;
 return onPress?<Pressable accessibilityRole="button" accessibilityLabel={`Abrir ${identifier??title}`} onPress={onPress}>{content}</Pressable>:content;
}
export function KeyValueList({data={},fields}){const t=useCantappTheme();const wide=useWindowDimensions().width>=768;return <View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.padding}}>{(fields||Object.keys(data).map(key=>({key,label:key}))).map(field=><View key={field.key} style={{width:wide?'47%':'100%',gap:4,paddingVertical:8,borderBottomWidth:1,borderColor:t.border}}><Text style={{fontFamily,color:t.muted,fontSize:12}}>{field.label}</Text><DataValue value={data[field.key]} type={field.type}/></View>)}</View>;}
export function SortControl({label='Ordenar',value,onChange,options=[]}){return <View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}>{options.map(option=><Button key={option.key} label={option.label} icon={value?.key===option.key?'down':undefined} variant={value?.key===option.key?'secondary':'ghost'} accessibilityLabel={`${label} por ${option.label}`} onPress={()=>onChange?.({key:option.key,direction:value?.key===option.key&&value.direction==='asc'?'desc':'asc'})}/>)}</View>;}
export function FilterPanel({fields=[],value={},onChange,onApply,onClear,activeFilters=[],onRemoveFilter,children,dates=true,loading=false}){
 const t=useCantappTheme();const [open,setOpen]=useState(false);
 return <View style={{gap:tokens.space}}><View style={{flexDirection:'row',flexWrap:'wrap',gap:tokens.space}}><Button label={open?'Ocultar filtros':'Filtros'} variant="ghost" icon="down" accessibilityState={{expanded:open}} onPress={()=>setOpen(v=>!v)}/>{activeFilters.map((filter,i)=><Button key={filter.key||i} label={filter.label} icon="close" variant="secondary" accessibilityLabel={`Quitar filtro ${filter.label}`} onPress={()=>onRemoveFilter?.(filter)}/>)}</View>{open&&<View style={{padding:tokens.padding,borderWidth:1,borderColor:t.border,borderRadius:tokens.radius,gap:12}}>{fields.map(field=><Input key={field.key} label={field.label} value={value[field.key]||''} onChange={next=>onChange?.({...value,[field.key]:next})}/>)}{children}{dates?<DateRangeFilter value={{from:value.from||'',to:value.to||''}} onChange={range=>onChange?.({...value,...range})} onApply={()=>onApply?.(value)} onClear={onClear} loading={loading}/>:<View style={{flexDirection:'row',gap:tokens.space}}><Button label="Aplicar filtros" loading={loading} onPress={()=>onApply?.(value)}/><Button label="Limpiar" variant="outline" disabled={loading} onPress={onClear}/></View>}</View>}</View>;
}
