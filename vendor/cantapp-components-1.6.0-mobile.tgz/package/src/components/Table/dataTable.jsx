import React from 'react';
import Tabla from './tabla';
export default function DataTable({data=[],pageSize=50,...props}){return <Tabla data={data} pageSize={pageSize} v2 {...props}/>;}
