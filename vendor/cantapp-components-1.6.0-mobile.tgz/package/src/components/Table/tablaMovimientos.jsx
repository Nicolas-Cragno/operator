import React from 'react';
import Tabla from './tabla';
function TablaMovimientos(props) { return <Tabla {...props} />; }
export default TablaMovimientos;
