export { formatValue as readable } from './data';
export function fieldsFrom(data) { return Object.keys(data || {}).map(key => ({ key, label: key.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase()) })); }
