// Dates are recognized by shape, never by coercing arbitrary identifiers.
export function toDate(value, explicit = false) {
  let date;
  if (value instanceof Date) date = value;
  else if (value && typeof value === 'object' && Number.isInteger(value.seconds) && Number.isInteger(value.nanoseconds ?? 0) && (value.nanoseconds ?? 0) >= 0 && (value.nanoseconds ?? 0) < 1e9) date = new Date(value.seconds * 1000 + (value.nanoseconds ?? 0) / 1e6);
  else if (explicit && typeof value === 'string') {
    const datetime = /^(\d{2}\/\d{2}\/\d{4}) (\d{2}):(\d{2})$/.exec(value);
    if (datetime) {
      const day = toDate(datetime[1], true);
      if (!day || +datetime[2] > 23 || +datetime[3] > 59) return null;
      day.setHours(+datetime[2], +datetime[3]);
      return day;
    }
    const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value);
    if (match) {
      date = new Date(+match[3], +match[2] - 1, +match[1]);
      if (date.getFullYear() !== +match[3] || date.getMonth() !== +match[2] - 1 || date.getDate() !== +match[1]) return null;
    } else if (/^\d{4}-\d{2}-\d{2}(T.*)?$/.test(value)) {
      const [year, month, day] = value.slice(0, 10).split('-').map(Number);
      const check = new Date(year, month - 1, day);
      if (check.getFullYear() !== year || check.getMonth() !== month - 1 || check.getDate() !== day) return null;
      date = value.length === 10 ? check : new Date(value);
    }
  }
  return date && Number.isFinite(date.getTime()) ? date : null;
}
/** @param {*} value @param {{withTime?: boolean, timeZone?: string}} [options] */
export function formatDate(value, { withTime = false, timeZone } = {}) {
  const date = toDate(value, true);
  if (!date) return '—';
  return new Intl.DateTimeFormat('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric', ...(withTime ? { hour: '2-digit', minute: '2-digit', hour12: false } : {}), ...(timeZone ? { timeZone } : {}) }).format(date);
}
export function formatValue(value, seen = new Set()) {
  if (value === undefined || value === null || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'Sí' : 'No';
  if (toDate(value)) return formatDate(value);
  if (typeof value !== 'object') return String(value);
  if (seen.has(value)) return '[Referencia circular]';
  const next = new Set(seen).add(value);
  return Array.isArray(value) ? value.map(v => formatValue(v, next)).join(' · ') || 'Sin elementos' : Object.entries(value).map(([k, v]) => `${k}: ${formatValue(v, next)}`).join(' · ') || 'Sin datos';
}
export function validateDateRange(from, to) {
  const start = from ? toDate(from, true) : null;
  const end = to ? toDate(to, true) : null;
  if ((from && !start) || (to && !end)) return 'Ingresá fechas válidas (dd/mm/aaaa).';
  return start && end && start > end ? 'Desde debe ser anterior o igual a Hasta.' : '';
}
