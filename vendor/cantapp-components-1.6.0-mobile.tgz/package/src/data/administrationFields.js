import localidades from './localidades.json';
const localityOptions = localidades.map(row => ({ value: row.key, label: `${row.nombre} - ${row.provincia}` }));
// Productive fields, shared by CANTAPP clients. Persistence rules remain in the backend.
const text = (key, label, required = false) => ({ key, label, type: 'text', required });
const relation = (key, label, source, required = false, multiple = false) => ({ key, label, type: multiple ? 'multiSelect' : 'searchSelect', relation: source, required });
const detail = { key: 'detalle', label: 'Detalle', type: 'textarea' };
const state = { key: 'estado', label: 'Activo', type: 'switch', defaultValue: true };
const ownCompany = relation('empresa', 'Empresa', 'empresas');
const satellite = relation('satelital', 'Empresa satelital', 'empresas');
const person = relation('persona', 'Persona', 'personas');
const types = values => values.map(value => ({ value, label: value }));

export function administrationFields(type, { editing = false, inventory = false, modality = 'interna', rules = {}, documentType = 'REMITO', movement = '', administrativeOnly = false } = {}) {
  if (type === 'documento') {
    if (editing && administrativeOnly) return [
      { key: 'fechaEmision', label: 'Fecha de emisión', type: 'date' }, relation('sucursal', 'Sucursal', 'ubicaciones'), detail,
    ];
    const moves = movement === 'ALTA' || movement === 'BAJA';
    return [
      { key: 'tipo', label: 'Tipo de documento', type: 'select', required: true, disabled: editing, defaultValue: 'REMITO', options: types(['REMITO', 'FACTURA']) },
      { key: 'movimientoStock', label: 'Movimiento de stock', type: 'select', required: true, disabled: editing, options: types(['ALTA', 'BAJA', 'SIN MOVIMIENTO']) },
      { ...relation('area', 'Área', 'sectores', true), valueField: 'nombre', lowercaseValue: true, disabled: editing },
      relation('proveedor', 'Proveedor', 'proveedores', true),
      { key: 'fechaEmision', label: 'Fecha de emisión', type: 'date' },
      text('remito', documentType === 'REMITO' ? 'Número de Remito' : 'Remito relacionado (número comercial)', documentType === 'REMITO'),
      text('factura', documentType === 'FACTURA' ? 'Número de Factura' : 'Factura relacionada (número comercial)', documentType === 'FACTURA'),
      relation('sucursal', 'Sucursal', 'ubicaciones'), relation('deposito', moves ? 'Depósito de movimiento' : 'Depósito de referencia (opcional)', 'depositos', moves),
      { key: 'moneda', label: 'Moneda del documento', type: 'select', required: true, defaultValue: 'pesos', options: [{ value: 'pesos', label: 'ARS' }, { value: 'dolares', label: 'USD' }] },
      { key: 'ingresos', label: 'Artículos del documento', type: 'articleLines', relation: 'stock', includeUnit: true, includeMoney: true, required: moves, quantityRules: rules, defaultValue: [] },
      { key: 'descuento', label: 'Descuento (%)', type: 'number', defaultValue: 0, validate: value => Number(value) < 0 || Number(value) > 100 ? 'Indicá un porcentaje entre 0 y 100' : '' },
      { key: '_totales', label: 'Importes', type: 'documentTotals', transient: true }, detail,
    ];
  }
  if (type === 'detalle') return [detail];
  if (type === 'asignacion') return [
    relation('persona', 'Persona', 'personas', true),
    { ...relation('area', 'Área', 'sectores', true), valueField: 'nombre', lowercaseValue: true },
    { key: 'ingresos', label: 'Artículos asignados', type: 'articleLines', relation: 'stock', required: true, quantityRules: rules, defaultValue: [] }, detail,
  ];
  if (['tallerTractor', 'tallerFurgon'].includes(type)) return [
    {
      key: 'modalidad', label: 'Modalidad', type: 'select', transient: true, required: true, defaultValue: 'interna', options: [
        { value: 'interna', label: 'Taller interno' }, { value: 'externa', label: 'Reparación externa' }, { value: 'ruta', label: 'Reparación en ruta' },
      ]
    },
    { key: 'tipo', label: 'Operación', type: 'select', required: true, options: types(['SERVICE', 'CAMBIO', 'REPARACION', 'REVISION']) },
    relation(type === 'tallerTractor' ? 'tractor' : 'furgon', type === 'tallerTractor' ? 'Tractores' : 'Furgones', type === 'tallerTractor' ? 'tractores' : 'furgones', true, true),
    relation('sucursal', 'Sucursal', 'ubicaciones', true),
    ...(modality === 'interna' ? [relation('mecanico', 'Mecánicos / responsables', 'personas', true, true)] : []),
    ...(modality === 'externa' ? [relation('proveedor', 'Proveedores', 'proveedores', true, true)] : []),
    relation('chofer', 'Chofer', 'personas'),
    ...(modality === 'ruta' ? [{ key: 'ubicacion', label: 'Ubicación / localidad', type: 'searchSelect', options: [{ value: '', label: 'Sin asignar' }, ...localityOptions] }] : []),
    ...(type === 'tallerTractor' ? [{ key: 'kilometraje', label: 'Kilometraje del evento', type: 'number', validate: value => value !== '' && value != null && (!Number.isSafeInteger(Number(value)) || Number(value) < 0) ? 'Ingresá un entero no negativo' : '' }] : []),
    { key: 'repuestos', label: 'Repuestos consumidos (total del evento)', type: 'articleLines', relation: 'stock', includeUnit: true, quantityRules: rules, defaultValue: [] },
    relation('deposito', 'Depósito de origen (obligatorio con repuestos)', 'depositos'),
    ...(type === 'tallerTractor' && modality === 'interna' ? [{ key: 'chequeos', label: 'Chequeos del evento', type: 'checks', items: rules.workshopChecks || [], defaultValue: {} }] : []), detail,
  ];
  if (type === 'llaves') return [
    { key: 'tipo', label: 'Operación', type: 'select', required: true, options: types(['ENTREGA', 'RETIRA', 'INVENTARIO']) },
    relation('operador', 'Operador', 'personas', true),
    relation('persona', 'Persona', 'personas', !inventory),
    relation('tractor', 'Tractores', 'tractores', true, true),
    { key: 'parteTr', label: 'Deja parte de tractor', type: 'switch', defaultValue: false }, detail,
  ];
  const id = text('id', type === 'personas' ? 'DNI' : type === 'empresas' ? 'CUIT' : ['tractores', 'furgones'].includes(type) ? 'Interno' : type === 'vehiculos' ? 'Dominio / identificador' : 'Código', true);
  id.disabled = editing;
  const vehicles = [text('dominio', 'Dominio', true), text('marca', 'Marca'), text('modelo', 'Modelo'), ownCompany];
  let fields;
  switch (type) {
    case 'personas': fields = [text('apellido', 'Apellido', true), text('nombres', 'Nombres', true), { key: 'legajo', label: 'Legajo', type: 'number' }, ownCompany, text('tipo', 'Tipo de empleado'), text('puesto', 'Puesto'), text('especializacion', 'Especialización'), text('ubicacion', 'Ubicación'), relation('sucursal', 'Sucursal', 'ubicaciones'), state, detail]; break;
    case 'tractores': fields = [...vehicles, satellite, person, state, detail]; break;
    case 'furgones': fields = [...vehicles, state, detail]; break;
    case 'vehiculos': fields = [...vehicles.map(field => field.key === 'dominio' ? { ...field, disabled: editing } : field), satellite, person, state, detail]; break;
    case 'empresas': fields = [text('nombre', 'Nombre', true), text('razonSocial', 'Razón social'), { key: 'tipo', label: 'Tipo', type: 'select', required: true, options: types(['propia', 'cliente', 'proveedor']) }, detail]; break;
    case 'stock': fields = [
      { key: 'tipo', label: 'Tipo', type: 'select', required: true, disabled: editing, options: types(['ACCESORIO', 'CARROCERIA', 'COMBUSTIBLE', 'ELECTRICIDAD', 'FLUIDO', 'FRENOS', 'HIDRAULICA', 'HERRAMIENTA', 'INSUMO', 'MOTOR', 'RECUPERADO', 'REFRIGERACION', 'RODADO', 'SUSPENSION', 'TRANSMISION', 'SERVICIO']) },
      text('descripcion', 'Descripción', true),
      { key: 'unidad', label: 'Unidad', type: 'select', required: true, disabled: editing, options: types(['UN', 'LT', 'MT', 'KG', 'GR', 'ML', 'CM', 'MM', 'RL', 'M3', 'TN']) },
      text('marca', 'Marca', true), relation('proveedor', 'Proveedor', 'proveedores'), text('codigoProveedor', 'Código del proveedor'), detail,
    ]; break;
    case 'depositos': fields = [text('nombre', 'Nombre', true), text('descripcion', 'Descripción')]; break;
    default: throw new Error(`Formulario no disponible: ${type}`);
  }
  // Identity is displayed but never edited. Existing optional historical fields stay untouched.
  return [id, ...fields.map(field => editing && field.disabled ? { ...field, required: false } : field)];
}

// ARS/USD: decimal arithmetic, half-up, prices/discount 2 decimals,
// each line rounded to cents before summing; final discount rounded to cents.
function decimalFraction(value) {
  const text = String(value ?? '').trim().replace(/^\./, '0.').replace(/\.$/, '.0');
  if (!/^\d+(\.\d+)?(e[+-]?\d+)?$/i.test(text) || text.length > 80) throw new Error('Importe decimal inválido');
  const [mantissa, exponent = '0'] = text.toLowerCase().split('e');
  const [whole, fraction = ''] = mantissa.split('.');
  const scale = fraction.length - Number(exponent);
  if (Math.abs(scale) > 400) throw new Error('Precisión decimal fuera de rango');
  const numerator = BigInt(whole + fraction);
  return scale >= 0 ? [numerator, 10n ** BigInt(scale)] : [numerator * 10n ** BigInt(-scale), 1n];
}
const roundRatio = (n, d) => (n * 2n + d) / (d * 2n);
const centsText = cents => `${cents / 100n}.${String(cents % 100n).padStart(2, '0')}`;
export function calculateDocumentAmounts(lines = [], discount = 0) {
  const [dn, dd] = decimalFraction(discount || 0);
  const basisPoints = roundRatio(dn * 100n, dd);
  if (dn > 100n * dd) throw new Error('Descuento fuera de 0–100');
  let subtotalCents = 0n;
  const prices = lines.map(line => {
    const [pn, pd] = decimalFraction(line.valor ?? 0);
    const priceCents = roundRatio(pn * 100n, pd);
    const [qn, qd] = decimalFraction(line.cantidad);
    subtotalCents += roundRatio(qn * priceCents, qd);
    // Bound compatible numeric fields to a range that preserves individual cents.
    if (priceCents > 99999999999999n) throw new Error('Precio fuera de rango');
    return Number(centsText(priceCents));
  });
  const totalCents = roundRatio(subtotalCents * (10000n - basisPoints), 10000n);
  if (subtotalCents > 99999999999999n) throw new Error('Subtotal fuera de rango');
  return {
    prices, descuento: Number(centsText(basisPoints)), subtotal: Number(centsText(subtotalCents)), total: Number(centsText(totalCents)),
    importesDecimales: { subtotal: centsText(subtotalCents), total: centsText(totalCents), politica: 'DECIMAL_HALF_UP_LINEA_2_V1' }
  };
}
