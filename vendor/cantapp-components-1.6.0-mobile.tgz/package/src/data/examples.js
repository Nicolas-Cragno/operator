export const persona = { id: '30123456', nombre: 'ROSAS MEDINA, CLAUDIO HECTOR', dni: '30123456', telefono: '11 4567-8901', estado: 'ACTIVO', sucursal: 'DON TORCUATO' };
export const tractor = { id: '222', interno: '222', dominio: 'AB123CD', marca: 'SCANIA', estado: 'DISPONIBLE' };
export const furgon = { id: '1015', interno: '1015', dominio: 'AE456FG', tipo: 'SEMIRREMOLQUE', estado: 'DISPONIBLE' };
export const vehiculo = { id: '94', interno: '94', dominio: 'AF789HI', tipo: 'UTILITARIO' };
export const stock = { id: 'ST-0021', nombre: 'Filtro de aceite', unidad: 'un.', cantidad: 12, proveedor: 'PROVEEDOR DEMO' };
export const asignacion = { id: 'AS-0001', persona: 'GOMEZ, JORGE', articulo: 'Llave torx', cantidad: 1, usuario: 'CRAGNO, NICOLAS LAUTARO' };
export const proveedor = { id: 'PV-001', nombre: 'REPUESTOS DEL NORTE', cuit: '30-12345678-9', telefono: '11 4321-1234' };
export const cliente = { id: 'CL-001', nombre: 'CLIENTE DEMOSTRACIÓN', cuit: '30-87654321-0', estado: 'ACTIVO' };
export const viaje = { id: 'V-000125', inicio: '15/10/2026 08:05:23', final: '28/10/2026 17:25:22', persona: persona.nombre, tractor: '222', furgones: '1015 - 1016 - 768', estado: 'FINALIZADO', distancia: '6200 KM' };
export const movimiento = { id: 'M-00051', inicio: '13/10/2026 20:10:45', final: '14/10/2026 08:35:02', persona: persona.nombre, distancia: '768 KM' };
export const relaciones = [
  { id: 'EV-0001', tipo: 'evento', fecha: '15/10/2026 08:05:22', label: 'Fecha: 15/10/2026 08:05:22, Persona: ROSAS MEDINA, CLAUDIO HECTOR, Tipo: SALIDA, ubicación: DON TORCUATO' },
  { id: 'V-000125', tipo: 'viaje', fecha: '15/10/2026 08:05:23', label: 'Inicio: 15/10/2026 08:05:23, Final: 28/10/2026 17:25:22 - Persona: ROSAS MEDINA, CLAUDIO HECTOR, Tractor/es: 222, Furgon/es: 1015 - 1016 - 768 - Estado: FINALIZADO, Distancia: 6200 KM, Promedio: 40.25, Diferencia: 22 lts.' },
  { id: 'M-00051', tipo: 'movimiento', fecha: '13/10/2026 20:10:45', label: 'Inicio: 13/10/2026 20:10:45, Final: 14/10/2026 08:35:02, Persona: ROSAS MEDINA, CLAUDIO HECTOR, Distancia: 768 KM' },
  { id: 'AS-0001', tipo: 'asignacion', fecha: '25/10/2026 08:05:02', label: 'Fecha: 25/10/2026 08:05:02, Persona: GOMEZ, JORGE, Articulo: Llave torx (1 un.), Usuario: CRAGNO, NICOLAS LAUTARO' },
];
