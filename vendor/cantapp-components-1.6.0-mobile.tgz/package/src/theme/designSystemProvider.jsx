import React from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ThemeProvider } from './themeContext';
import { ToastProvider } from '../components/Modal/notifications';
export default function DesignSystemProvider({ children, mode = 'claro', palette, onFontError }) {
  return <SafeAreaProvider><ThemeProvider mode={mode} palette={palette} onFontError={onFontError}><ToastProvider>{children}</ToastProvider></ThemeProvider></SafeAreaProvider>;
}
