import { useMemo } from 'react';
import { useCantappTheme } from './themeContext';
// Legacy card variants keep their layout styles and share semantic colors.
export default function useComponentStyles(base) {
  const t = useCantappTheme();
  return useMemo(() => ({
    ...base,
    root: [base.root, { backgroundColor: t.surface, borderColor: t.border }],
    title: [base.title, { color: t.special }],
    text: [base.text, { color: t.text }],
    muted: [base.muted, { color: t.muted }],
    button: [base.button, { backgroundColor: t.special, minHeight: 44 }],
    buttonText: [base.buttonText, { color: t.onAccent }],
  }), [base, t]);
}
