import { Platform } from 'react-native';
export const fontFamily = Platform.select({ web: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', default: 'Inter' });
export const dataFontFamily = Platform.select({ web: 'Consolas, "Courier New", monospace', ios: 'Menlo', default: 'monospace' });
