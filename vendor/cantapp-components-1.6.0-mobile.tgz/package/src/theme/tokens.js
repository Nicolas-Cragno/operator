export const tokens = Object.freeze({
  colors: {
    primary: '#0d1f7f', primaryHover: '#243b9a', selection: '#e8edff',
    background: '#f3f5f8', surface: '#ffffff', border: '#dce2eb',
    text: '#172033', muted: '#64748b', details: '#730f21',
    success: '#16794a', successBg: '#e6f6ed', danger: '#b42318', dangerBg: '#fff0ee',
    warning: '#a96808', warningText: '#8c5706', warningBg: '#fff5db', info: '#175cd3', infoBg: '#eaf2ff',
  },
  radius: 4, space: 8, padding: 16, controlHeight: 36, touchHeight: 44,
  rowHeight: 36, headerHeight: 48, sidebarWidth: 240, sidebarCollapsed: 64,
  breakpoint: 768, duration: 150, focusWidth: 2,
  fontSize: { body: 14, label: 12, title: 20 },
});
