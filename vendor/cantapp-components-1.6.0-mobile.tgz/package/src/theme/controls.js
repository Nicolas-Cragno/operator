import { Platform } from 'react-native';
import { tokens } from './tokens';
export const controlHeight = Platform.OS === 'web' ? tokens.controlHeight : tokens.touchHeight;
export const focusStyle = color => Platform.OS === 'web' ? { outlineStyle: 'solid', outlineWidth: 2, outlineColor: color, outlineOffset: 2 } : { borderColor: color };
