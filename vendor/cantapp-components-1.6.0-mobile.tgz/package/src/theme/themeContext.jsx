import React, { createContext, useContext, useMemo } from 'react';
import { makeTheme } from './theme';
import { useFonts } from 'expo-font';
import { Inter_400Regular } from '@expo-google-fonts/inter/400Regular';
import { ActivityIndicator, View } from 'react-native';
import { SafeAreaProvider, SafeAreaInsetsContext, initialWindowMetrics } from 'react-native-safe-area-context';
const Context = createContext(makeTheme());
export function ThemeProvider({ children, mode = 'claro', palette, onFontError }) {
  const [loaded, error] = useFonts({ Inter: Inter_400Regular });
  const safeArea = useContext(SafeAreaInsetsContext);
  React.useEffect(() => { if (error) onFontError?.(error); }, [error, onFontError]);
  const theme = useMemo(() => makeTheme(mode, palette), [mode, palette]);
  const content = <Context.Provider value={theme}>{loaded || error ? children : <View style={{ padding: 24 }}><ActivityIndicator color={theme.primary} /></View>}</Context.Provider>;
  return safeArea ? content : <SafeAreaProvider initialMetrics={initialWindowMetrics}>{content}</SafeAreaProvider>;
}
export function useCantappTheme() { return useContext(Context); }
