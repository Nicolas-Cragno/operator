import { tokens } from './tokens';
export const defaultPalettes = {
  oscuro: { colorA: '#fdd255', colorB: '#ffffff', colorC: '#730f21', colorD: '#101a38', colorE: '#354263' },
  claro: { colorA: '#0d1f7f', colorB: '#730f21', colorC: '#fdd255', colorD: '#ffffff', colorE: '#b9c1d1' },
};
export function makeTheme(mode = 'claro', palette) {
  const dark = mode === 'oscuro' || mode === 'dark';
  const p = { ...defaultPalettes[dark ? 'oscuro' : 'claro'], ...(palette || {}) };
  if (!dark) {
    const primary = palette?.primary ?? palette?.colorA ?? tokens.colors.primary;
    const surface = palette?.surface ?? palette?.colorD ?? tokens.colors.surface;
    const border = palette?.border ?? palette?.colorE ?? tokens.colors.border;
    return { ...tokens, ...tokens.colors, mode: 'claro', version: 2, darkApproved: false,
      colorA: primary, colorB: tokens.colors.text, colorC: tokens.colors.details,
      colorD: surface, colorE: border,
      special: primary, surfaceElevated: surface, focus: primary,
      hover: tokens.colors.selection, disabled: '#94a3b8', onAccent: '#ffffff',
      spacing: { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 }, ...(palette || {}), primary, surface, border };
  }
  return { ...p, mode: dark ? 'oscuro' : 'claro', primary: dark ? '#0d1f7f' : '#ffffff', special: dark ? '#fdd255' : '#0d1f7f', details: dark ? '#730f21' : '#fdd255', background: dark ? '#080e20' : '#f3f5f9', surface: p.colorD, surfaceElevated: dark ? '#1a294a' : '#ffffff', border: p.colorE, text: dark ? '#ffffff' : '#000000', muted: dark ? '#b7c3db' : '#45506b', focus: dark ? '#fdd255' : '#0d1f7f', hover: dark ? '#243456' : '#e7ecf5', disabled: dark ? '#64708a' : '#67738a', danger: dark ? '#ff9da9' : '#ac2035', success: dark ? '#78dfb6' : '#08734e', warning: dark ? '#fdd255' : '#805c00', info: dark ? '#9ac4ff' : '#174b94', onAccent: dark ? '#080e20' : '#ffffff', radius: 4, spacing: { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 }, controlHeight: 44 };
}
